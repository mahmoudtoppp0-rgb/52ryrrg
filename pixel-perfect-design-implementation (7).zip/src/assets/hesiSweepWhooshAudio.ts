/**
 * Builds the 340ms gentle airy whoosh RIFF/WAVE audio asset (22.05kHz 16-bit mono PCM)
 * with a raised-cosine onset/decay envelope and a smooth state-variable bandpass sweep
 * (260 Hz -> 680 Hz -> 290 Hz) at low perceived loudness (-18 dBFS peak).
 */
function createHesiSweepWhooshWavDataUri(): string {
  const sampleRate = 22050;
  const durationSec = 0.34; // 340 ms
  const numSamples = Math.floor(sampleRate * durationSec);
  const totalBytes = 44 + numSamples * 2;
  const buffer = new ArrayBuffer(totalBytes);
  const view = new DataView(buffer);

  const writeAscii = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  // Standard 44-byte RIFF WAVE header
  writeAscii(0, "RIFF");
  view.setUint32(4, 36 + numSamples * 2, true);
  writeAscii(8, "WAVE");
  writeAscii(12, "fmt ");
  view.setUint32(16, 16, true); // PCM chunk size
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // Mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeAscii(36, "data");
  view.setUint32(40, numSamples * 2, true);

  // Deterministic PRNG & state-variable bandpass filter for soft air sweep
  let seed = 133742;
  const nextRand = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return (seed / 4294967296) * 2 - 1;
  };

  let low = 0;
  let band = 0;
  let b0 = 0;
  let b1 = 0;
  let b2 = 0;

  for (let i = 0; i < numSamples; i++) {
    const t = i / numSamples; // 0..1

    // Smooth raised-cosine onset (0..0.32) and soft exponential/cosine decay (0.32..1.0)
    let env = 0;
    if (t < 0.32) {
      env = 0.5 * (1 - Math.cos(Math.PI * (t / 0.32)));
    } else {
      const d = (t - 0.32) / 0.68;
      env = 0.5 * (1 + Math.cos(Math.PI * d)) * Math.exp(-1.4 * d);
    }

    const white = nextRand();
    b0 = 0.997 * b0 + white * 0.029;
    b1 = 0.985 * b1 + white * 0.032;
    b2 = 0.95 * b2 + white * 0.048;
    const pink = b0 + b1 + b2 + white * 0.018;

    const sweepShape = Math.sin(Math.PI * Math.pow(t, 0.85));
    const cutoffHz = 260 + 420 * sweepShape;
    const f = 2 * Math.sin((Math.PI * cutoffHz) / sampleRate);
    const q = 0.42;

    low = low + f * band;
    const high = pink - low - q * band;
    band = f * high + band;

    const signal = Math.max(-1, Math.min(1, band * env * 0.22));
    const pcm16 = Math.round(signal * 32767);
    view.setInt16(44 + i * 2, pcm16, true);
  }

  // Convert ArrayBuffer to base64 data URI
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    binary += String.fromCharCode(...slice);
  }

  const base64 =
    typeof btoa === "function"
      ? btoa(binary)
      : Buffer.from(buffer).toString("base64");

  return `data:audio/wav;base64,${base64}`;
}

export const HESI_SWEEP_WHOOSH_WAV_URI = createHesiSweepWhooshWavDataUri();
export default HESI_SWEEP_WHOOSH_WAV_URI;
