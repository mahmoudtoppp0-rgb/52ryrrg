import hesiSweepWhooshAsset from "../assets/hesiSweepWhooshAudio";

const SOUND_STORAGE_KEY = "hesi-sound-enabled";

export interface SweepSoundConfig {
  /** Path or data URI to the short airy whoosh audio asset (~340ms) */
  assetUrl: string;
  /** Subtle playback volume (0.0 to 1.0, default 0.34) */
  volume: number;
  /** Whether transition sound effects are enabled */
  enabled: boolean;
}

function getInitialSoundEnabled(): boolean {
  try {
    const saved = window.localStorage.getItem(SOUND_STORAGE_KEY);
    if (saved === "false") return false;
    if (saved === "true") return true;
  } catch {
    // Ignore storage errors
  }
  return true;
}

const currentConfig: SweepSoundConfig = {
  assetUrl: hesiSweepWhooshAsset,
  volume: 0.34,
  enabled: typeof window !== "undefined" ? getInitialSoundEnabled() : true,
};

let cachedAudio: HTMLAudioElement | null = null;
let lastPlayedTransitionId = -1;

/**
 * Allows configuring a custom audio asset URL, volume, or enabled state.
 */
export function configureSweepSound(partial: Partial<SweepSoundConfig>): void {
  if (partial.assetUrl !== undefined && partial.assetUrl !== currentConfig.assetUrl) {
    currentConfig.assetUrl = partial.assetUrl;
    cachedAudio = null;
  }
  if (partial.volume !== undefined) {
    currentConfig.volume = Math.max(0, Math.min(1, partial.volume));
    if (cachedAudio) cachedAudio.volume = currentConfig.volume;
  }
  if (partial.enabled !== undefined) {
    setSweepSoundEnabled(partial.enabled);
  }
}

export function getSweepSoundEnabled(): boolean {
  return currentConfig.enabled;
}

export function setSweepSoundEnabled(enabled: boolean): void {
  currentConfig.enabled = enabled;
  try {
    window.localStorage.setItem(SOUND_STORAGE_KEY, String(enabled));
  } catch {
    // Ignore storage errors
  }
  if (!enabled) {
    stopSweepWhoosh();
  }
}

/**
 * Plays the subtle 340ms airy whoosh once per valid user-initiated navigation ID.
 * Synchronized with the start of Hesi's curtain sweep.
 * Fails silently if blocked by browser autoplay restrictions or if audio fails to load.
 */
export function playSweepWhoosh(transitionId: number, reducedMotion = false): void {
  if (reducedMotion || !currentConfig.enabled) return;
  if (transitionId <= 0 || transitionId === lastPlayedTransitionId) return;

  lastPlayedTransitionId = transitionId;

  try {
    if (!cachedAudio) {
      cachedAudio = new Audio(currentConfig.assetUrl);
      cachedAudio.preload = "auto";
    }
    cachedAudio.volume = currentConfig.volume;
    cachedAudio.currentTime = 0;

    const playPromise = cachedAudio.play();
    if (playPromise && typeof playPromise.catch === "function") {
      playPromise.catch(() => {
        // Respect browser autoplay policies silently without interrupting navigation
      });
    }
  } catch {
    // Never allow audio errors to interrupt lesson navigation
  }
}

/**
 * Stops and resets any active sweep audio instance on cancellation or unmount.
 */
export function stopSweepWhoosh(): void {
  try {
    if (cachedAudio) {
      cachedAudio.pause();
      cachedAudio.currentTime = 0;
    }
  } catch {
    // Ignore cleanup errors
  }
}
