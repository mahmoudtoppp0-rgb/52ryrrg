import { ALL_MASCOTS, type MascotId, type MascotItem } from "./mascots";

export interface LessonQuestion {
  promptEn: string;
  promptAr: string;
  options: {
    id: string;
    textEn: string;
    textAr: string;
    isCorrect: boolean;
    feedbackEn: string;
    feedbackAr: string;
  }[];
}

export interface HesiLessonModule {
  id: MascotId;
  unitCode: string;
  durationEn: string;
  durationAr: string;
  titleEn: string;
  titleAr: string;
  summaryEn: string;
  summaryAr: string;
  keyTakeawaysEn: string[];
  keyTakeawaysAr: string[];
  question: LessonQuestion;
}

export const LESSON_MODULES: Record<MascotId, HesiLessonModule> = {
  individual: {
    id: "individual",
    unitCode: "UNIT 01 • SOLO PATH",
    durationEn: "12 min interactive lesson",
    durationAr: "درس تفاعلي • ١٢ دقيقة",
    titleEn: "Foundations of Self-Paced Mastery",
    titleAr: "أساسيات الإتقان الذاتي المركّز",
    summaryEn:
      "Learn how to structure focused 15-minute personal study blocks using active recall and spaced repetition with your Hesi companion.",
    summaryAr:
      "تعلّم كيفية تنظيم جلسات دراسة شخصية مدتها ١٥ دقيقة باستخدام الاستدعاء النشط والتكرار المتباعد مع رفيقك هيسي.",
    keyTakeawaysEn: [
      "Break complex topics into single-concept study cards.",
      "Test yourself before re-reading notes to strengthen memory pathways.",
      "Review at expanding intervals (1 day, 3 days, 7 days).",
    ],
    keyTakeawaysAr: [
      "قسّم المفاهيم المركبة إلى بطاقات تعلّم صغيرة ومركّزة.",
      "اختبر نفسك قبل إعادة القراءة لتقوية مسارات الذاكرة.",
      "راجع على فترات متباعدة (يوم، ٣ أيام، ٧ أيام).",
    ],
    question: {
      promptEn: "Which study method produces the strongest long-term retention during solo learning?",
      promptAr: "أي أسلوب دراسي يحقق أقوى تثبيت للمعلومات في الذاكرة طويلة المدى؟",
      options: [
        {
          id: "a",
          textEn: "Active recall with spaced self-quizzing",
          textAr: "الاستدعاء النشط مع الاختبار الذاتي المتباعد",
          isCorrect: true,
          feedbackEn: "Spot on! Retrieving knowledge actively strengthens neural pathways.",
          feedbackAr: "إجابة صحيحة! استرجاع المعلومة بنشاط يقوّي الروابط العصبية.",
        },
        {
          id: "b",
          textEn: "Passively re-reading the same chapter four times",
          textAr: "إعادة قراءة الفصل نفسه بشكل سلبي أربع مرات",
          isCorrect: false,
          feedbackEn: "Re-reading feels familiar, but active recall builds much deeper mastery.",
          feedbackAr: "القراءة المتكررة تعطي شعوراً بالألفة، لكن الاختبار النشط يبني إتقاناً أعمق.",
        },
        {
          id: "c",
          textEn: "Highlighting every sentence in the textbook",
          textAr: "تظليل كل جملة في الكتاب المدرسي",
          isCorrect: false,
          feedbackEn: "Try selective synthesis and self-testing instead of heavy highlighting.",
          feedbackAr: "جرّب التلخيص الانتقائي والاختبار الذاتي بدلاً من التظليل الكثيف.",
        },
      ],
    },
  },
  pro: {
    id: "pro",
    unitCode: "UNIT 02 • PRO LAB",
    durationEn: "18 min advanced lab",
    durationAr: "مختبر متقدم • ١٨ دقيقة",
    titleEn: "Analytical Problem Solving & First Principles",
    titleAr: "حل المسائل التحليلية والتفكير من المبادئ الأولى",
    summaryEn:
      "Deconstruct unfamiliar exam problems into fundamental building blocks and verify solutions with Pro-level diagnostic checks.",
    summaryAr:
      "فكّك المسائل غير المألوفة إلى مبادئها الأساسية وتحقق من صحة الحلول باستخدام أدوات التشخيص المتقدمة.",
    keyTakeawaysEn: [
      "Identify invariants and core constraints before applying formulas.",
      "Validate edge cases to catch subtle logical traps early.",
      "Use error logs to turn every mistake into a targeted micro-drill.",
    ],
    keyTakeawaysAr: [
      "حدّد المعطيات الثابتة والقيود الأساسية قبل تطبيق القوانين.",
      "تحقق من الحالات الحدية لاكتشاف الأخطاء المنطقية الدقيقة مبكراً.",
      "استثمر سجل الأخطاء لتحويل كلثغرة إلى تدريب موجّه.",
    ],
    question: {
      promptEn: "When facing an unfamiliar multi-step problem, what is the best first step?",
      promptAr: "عند مواجهة مسألة متعددة الخطوات غير مألوفة، ما هي أفضل خطوة أولى؟",
      options: [
        {
          id: "a",
          textEn: "Break the problem down into known first principles and constraints",
          textAr: "تفكيك المسألة إلى مبادئها الأساسية والمعطيات المعلومة",
          isCorrect: true,
          feedbackEn: "Excellent! First-principles decomposition turns complex problems into solvable steps.",
          feedbackAr: "ممتاز! التفكيك إلى المبادئ الأولى يحوّل المسائل المعقدة إلى خطوات واضحة.",
        },
        {
          id: "b",
          textEn: "Guess a formula immediately and plug in numbers",
          textAr: "تخمين قانون فوراً والتعويض بالأرقام عشوائياً",
          isCorrect: false,
          feedbackEn: "Map the relationships first so you choose the right model with confidence.",
          feedbackAr: "ارسم العلاقة بين المعطيات أولاً لتختار النموذج الصحيح بثقة.",
        },
        {
          id: "c",
          textEn: "Skip checking units until the final exam",
          textAr: "تجاهل وحدات القياس حتى يوم الامتحان النهائي",
          isCorrect: false,
          feedbackEn: "Dimensional analysis is one of the fastest ways to verify your setup!",
          feedbackAr: "تحليل الوحدات من أسرع الطرق للتحقق من صحة خطواتك!",
        },
      ],
    },
  },
  family: {
    id: "family",
    unitCode: "UNIT 03 • FAMILY CIRCLE",
    durationEn: "10 min guided activity",
    durationAr: "نشاط عائلي • ١٠ دقائق",
    titleEn: " Co-Learning & Supportive Study Habits at Home",
    titleAr: "التعلّم التشاركي وبناء عادات الدراسة الداعمة في المنزل",
    summaryEn:
      "Discover how parents and younger learners can celebrate daily curiosity together and build confidence through positive reinforcement.",
    summaryAr:
      "اكتشف كيف يمكن للوالدين والأبناء الاحتفاء بالفضول اليومي معاً وبناء الثقة من خلال التشجيع الإيجابي الدافئ.",
    keyTakeawaysEn: [
      "Ask 'What was the most interesting thing you discovered today?'",
      "Celebrate effort and strategy rather than only final scores.",
      "Keep shared family study check-ins short, warm, and consistent.",
    ],
    keyTakeawaysAr: [
      "اسأل: «ما أكثر فكرة مثيرة للاهتمام اكتشفتها اليوم؟»",
      "احتفِ بالجهد وطريقة التفكير وليس بالدرجة النهائية فقط.",
      "اجعل لقاءات المراجعة العائلية قصيرة ودافئة ومنتظمة.",
    ],
    question: {
      promptEn: "How can families best encourage a young learner after a challenging lesson?",
      promptAr: "كيف يمكن للعائلة دعم المتعلم الصغير بأفضل طريقة بعد درس صعب؟",
      options: [
        {
          id: "a",
          textEn: "Praise their persistence and explore the tricky step together",
          textAr: "الإشادة بمثابرته واستكشاف الخطوة الصعبة معاً بهدوء",
          isCorrect: true,
          feedbackEn: "Wonderful! Warm encouragement builds lasting curiosity and resilience.",
          feedbackAr: "رائع! التشجيع الدافئ يبني الفضول المستمر والثقة بالنفس.",
        },
        {
          id: "b",
          textEn: "Compare their speed to other learners",
          textAr: "مقارنة سرعته بسرعة الآخرين",
          isCorrect: false,
          feedbackEn: "Every learner grows at their own pace — focus on personal progress!",
          feedbackAr: "كل متعلم ينمو بسرعته الخاصة — ركّز دائماً على تقدمه الشخصي!",
        },
      ],
    },
  },
  group: {
    id: "group",
    unitCode: "UNIT 04 • TEAM STUDIO",
    durationEn: "15 min peer workshop",
    durationAr: "ورشة جماعية • ١٥ دقيقة",
    titleEn: "The Feynman Technique & Peer Teaching",
    titleAr: "تقنية فاينمان والتعلّم عبر شرح الأقران",
    summaryEn:
      "Master complex subjects faster by explaining concepts clearly to study teammates and comparing problem-solving perspectives.",
    summaryAr:
      "أتقن الموضوعات المركبة بشكل أسرع من خلال شرح المفاهيم بوضوح لزملاء المجموعة ومقارنة زوايا الحل المختلفة.",
    keyTakeawaysEn: [
      "If you can explain a concept simply to a teammate, you truly understand it.",
      "Spot knowledge gaps immediately when a step feels hard to articulate.",
      "Combine diverse problem-solving approaches from your study group.",
    ],
    keyTakeawaysAr: [
      "إذا استطعت شرح الفكرة ببساطة لزميلك، فأنت تفهمها بعمق.",
      "اكتشف فجوات الفهم فوراً عندما يصعب عليك صياغة خطوة معينة.",
      "اجمع بين طرق الحل المتنوعة لدى أعضاء مجموعتك الدراسية.",
    ],
    question: {
      promptEn: "What is the core idea of the Feynman peer-teaching technique?",
      promptAr: "ما الفكرة الجوهرية لتقنية فاينمان في التعلم التشاركي؟",
      options: [
        {
          id: "a",
          textEn: "Explain the concept in simple language as if teaching a peer",
          textAr: "شرح المفهوم بلغة بسيطة وواضحة وكأنك تعلّمه لزميلك",
          isCorrect: true,
          feedbackEn: "Exactly! Teaching others reveals and cements true understanding.",
          feedbackAr: "بالضبط! شرح الفكرة للآخرين يكشف الفهم الحقيقي ويثبّته.",
        },
        {
          id: "b",
          textEn: "Memorize jargon definitions word-for-word without examples",
          textAr: "حفظ المصطلحات المعقدة حرفياً دون أمثلة تطبيقية",
          isCorrect: false,
          feedbackEn: "Simple explanations and real examples beat memorized jargon every time.",
          feedbackAr: "الشرح البسيط والأمثلة الواقعية يتفوقان دائماً على الحفظ الآلي.",
        },
      ],
    },
  },
  focused: {
    id: "focused",
    unitCode: "UNIT 05 • DEEP FOCUS",
    durationEn: "15 min deep-focus session",
    durationAr: "جلسة تركيز عميق • ١٥ دقيقة",
    titleEn: "Entering Flow State & Distraction-Free Study",
    titleAr: "الدخول في حالة التدفق الذهني والدراسة عالية التركيز",
    summaryEn:
      "Set up your calm study desk with Hesi, silence background noise, and immerse yourself in single-task deep learning.",
    summaryAr:
      "جهّز بيئة دراستك الهادئة مع هيسي، وقلّل المشتتات للاندماج الكامل في مهمة تعليمية واحدة بتركيز عميق.",
    keyTakeawaysEn: [
      "Clear visual clutter and keep only your current book or problem open.",
      "Use a 20-minute focus timer followed by a 5-minute rest recharge.",
      "Let your optical gaze follow one step at a time without multitasking.",
    ],
    keyTakeawaysAr: [
      "رتّب مساحة الدراسة وأبقِ فقط الكتاب أو المسألة الحالية أمامك.",
      "استخدم مؤقت تركيز لمدة ٢٠ دقيقة يتبعه استراحة قصيرة لتجديد النشاط.",
      "ركّز انتباهك على خطوة واحدة في كل مرة دون تعدد مهام.",
    ],
    question: {
      promptEn: "What helps your brain enter a calm, productive flow state fastest?",
      promptAr: "ما الذي يساعد ذهنك على الدخول في حالة التركيز العميق بأسرع وقت؟",
      options: [
        {
          id: "a",
          textEn: "Single-tasking on one clear learning goal with notifications muted",
          textAr: "التركيز على هدف تعليمي واحد واضح مع كتم الإشعارات المشتتة",
          isCorrect: true,
          feedbackEn: "Brilliant! Single-task focus lets your attention settle deeply.",
          feedbackAr: "أحسنت! التركيز الأحادي يمنح ذهنك هدوءاً وعمقاً في الفهم.",
        },
        {
          id: "b",
          textEn: "Switching between five browser tabs every two minutes",
          textAr: "التنقل بين خمس نوافذ مختلفة كل دقيقتين",
          isCorrect: false,
          feedbackEn: "Context switching drains mental energy — stay with one concept at a time.",
          feedbackAr: "تشتيت الانتباه يستهلك الطاقة الذهنية — ابقَ مع مفهوم واحد حتى تتقنه.",
        },
      ],
    },
  },
  happy: {
    id: "happy",
    unitCode: "UNIT 06 • QUICK QUIZ",
    durationEn: "8 min victory drill",
    durationAr: "تدريب سريع • ٨ دقائق",
    titleEn: "Momentum Building & Instant Feedback Loops",
    titleAr: "بناء الزخم الإيجابي وحلقات التغذية الراجعة الفورية",
    summaryEn:
      "Experience how immediate verification and celebrating small correct steps turn challenging subjects into an enjoyable daily habit.",
    summaryAr:
      "اختبر كيف يسهم التحقق الفوري والاحتفاء بالخطوات الصحيحة الصغيرة في تحويل الموضوعات الصعبة إلى عادة يومية ممتعة.",
    keyTakeawaysEn: [
      "Verify each reasoning step immediately while the logic is fresh.",
      "Celebrate progress streaks to build lasting problem-solving confidence.",
      "Use correct answers as anchors to connect related concepts.",
    ],
    keyTakeawaysAr: [
      "تحقق من كل خطوة استنتاجية فوراً بينما الفكرة حاضرة في ذهنك.",
      "احتفِ بسلسلة التقدم لبناء ثقة مستدامة في حل المسائل.",
      "استخدم الإجابات الصحيحة كنقاط ارتكاز لربط المفاهيم المتقاربة.",
    ],
    question: {
      promptEn: "Why is immediate feedback so effective when practicing new skills?",
      promptAr: "لماذا تعد التغذية الراجعة الفورية فعالة جداً عند التدرب على مهارة جديدة؟",
      options: [
        {
          id: "a",
          textEn: "It reinforces correct reasoning while your thought process is still active",
          textAr: "لأنها تعزز الاستنتاج الصحيح بينما خطوات التفكير لا تزال نشطة في الذهن",
          isCorrect: true,
          feedbackEn: "Yes! Hesi is cheering for you — that's a verified correct answer!",
          feedbackAr: "نعم! هيسي يحتفل معك — إجابة صحيحة وموثقة!",
        },
        {
          id: "b",
          textEn: "It replaces the need to understand why an answer works",
          textAr: "لأنها تغني عن فهم سبب صحة الإجابة",
          isCorrect: false,
          feedbackEn: "Feedback works best when paired with understanding the 'why'!",
          feedbackAr: "التغذية الراجعة تكون أقوى عندما تقترن بفهم «لماذا» كانت الإجابة صحيحة!",
        },
      ],
    },
  },
  proud: {
    id: "proud",
    unitCode: "UNIT 07 • CAPSTONE",
    durationEn: "20 min mastery review",
    durationAr: "مراجعة الإتقان • ٢٠ دقيقة",
    titleEn: "Capstone Synthesis & Milestone Mastery",
    titleAr: "التكامل المعرفي وإتمام محطات الإنجاز",
    summaryEn:
      "Bring together everything you have learned in this unit, complete the capstone synthesis check, and claim your Golden Mastery Trophy.",
    summaryAr:
      "اجمع كل ما تعلمته في هذه الوحدة، وأكمل التحدي الختامي الشامل لتحقيق كأس التفوق الذهبي مع هيسي.",
    keyTakeawaysEn: [
      "Connect core concepts across chapters into a unified mental map.",
      "Reflect on how far your problem-solving speed and accuracy have grown.",
      "Archive your completed unit summary for effortless pre-exam review.",
    ],
    keyTakeawaysAr: [
      "اربط المفاهيم الأساسية عبر الفصول في خريطة ذهنية متكاملة.",
      "تأمل مدى تطور سرعتك ودقتك في تحليل المسائل.",
      "احفظ ملخص الوحدة المكتملة للمراجعة السريعة قبل الاختبارات.",
    ],
    question: {
      promptEn: "What is the best way to consolidate a completed learning module?",
      promptAr: "ما هي أفضل طريقة لتثبيت وحدة تعليمية بعد إتمامها بنجاح؟",
      options: [
        {
          id: "a",
          textEn: "Create a one-page concept map linking the unit's key ideas",
          textAr: "إنشاء خريطة مفاهيم في صفحة واحدة تربط الأفكار الرئيسية للوحدة",
          isCorrect: true,
          feedbackEn: "Trophy unlocked! Synthesizing connections cements long-term mastery 🏆",
          feedbackAr: "استحققت الكأس الذهبي! ربط المفاهيم يرسّخ الإتقان طويل المدى 🏆",
        },
        {
          id: "b",
          textEn: "Discard all notes and never review the topic again",
          textAr: "إهمال الملخصات وعدم مراجعة الموضوع مرة أخرى",
          isCorrect: false,
          feedbackEn: "A brief concept map keeps your hard-earned mastery sharp!",
          feedbackAr: "خريطة مفاهيم مختصرة تحافظ على إتقانك الذي تعبت من أجله!",
        },
      ],
    },
  },
  sleepy: {
    id: "sleepy",
    unitCode: "UNIT 08 • MINDFUL REST",
    durationEn: "7 min restorative guide",
    durationAr: "دليل الراحة الذهنية • ٧ دقائق",
    titleEn: "Sleep Consolidation & Guilt-Free Recharge",
    titleAr: "تثبيت الذاكرة أثناء النوم والراحة دون شعور بالذنب",
    summaryEn:
      "Understand why quality sleep is essential for memory consolidation and how Hesi welcomes you back warmly even if a streak pauses.",
    summaryAr:
      "تعرّف على دور النوم العميق في تثبيت المعلومات في الذاكرة، وكيف يدعمك هيسي بلطف ودون أي لوم عند الحاجة للاستراحة.",
    keyTakeawaysEn: [
      "During deep sleep, your brain replays and locks in what you studied.",
      "Resting when exhausted is a smart learning strategy, never a failure.",
      "A 5-minute light review before bed boosts overnight recall.",
    ],
    keyTakeawaysAr: [
      "أثناء النوم العميق، يعيد الدماغ تنظيم وتثبيت ما درسته خلال اليوم.",
      "أخذ قسط من الراحة عند الإرهاق خطوة ذكية للتعلم وليس تقصيراً.",
      "مراجعة هادئة لمدة ٥ دقائق قبل النوم تعزز تذكر المعلومات صباحاً.",
    ],
    question: {
      promptEn: "What happens in your brain when you get quality sleep after studying?",
      promptAr: "ماذا يحدث في الدماغ عندما تحصل على نوم جيد بعد المذاكرة؟",
      options: [
        {
          id: "a",
          textEn: "Memory consolidation transfers new knowledge into long-term storage",
          textAr: "تتم عملية تثبيت الذاكرة ونقل المعلومات الجديدة إلى الذاكرة طويلة المدى",
          isCorrect: true,
          feedbackEn: "Rest well! Sleep is where hard study turns into permanent knowledge 🌙",
          feedbackAr: "نوم العوافي! النوم الصحي يحوّل جهد المذاكرة إلى معرفة راسخة 🌙",
        },
        {
          id: "b",
          textEn: "All-night cramming with zero sleep improves analytical accuracy",
          textAr: "السهر طوال الليل دون نوم يزيد من الدقة التحليلية",
          isCorrect: false,
          feedbackEn: "Sleep deprivation hurts recall and focus — restful sleep is your superpower!",
          feedbackAr: "الإرهاق يضعف التركيز والاسترجاع — الراحة المتوازنة هي سر تفوقك!",
        },
      ],
    },
  },
  anxious: {
    id: "anxious",
    unitCode: "UNIT 09 • EXAM CALM",
    durationEn: "10 min calm prep",
    durationAr: "تهيئة هادئة للاختبار • ١٠ دقائق",
    titleEn: "Calming Pre-Exam Nerves & Structured Triage",
    titleAr: "تهدئة توتر ما قبل الامتحان والتخطيط المرحلي الواثق",
    summaryEn:
      "Transform pre-exam tension into calm readiness using box breathing and a clear 3-step review checklist alongside Hesi.",
    summaryAr:
      "حوّل توتر ما قبل الاختبار إلى استعداد هادئ وواثق باستخدام التنفس المتوازن وخطة مراجعة مقسّمة إلى ٣ خطوات بسيطة.",
    keyTakeawaysEn: [
      "Take a slow 4-second inhale and 4-second exhale to settle exam jitters.",
      "Triage exam topics into 3 bite-sized priority blocks.",
      "Start the exam with two familiar warm-up questions to build rhythm.",
    ],
    keyTakeawaysAr: [
      "خذ شهيقاً هادئاً لمدة ٤ ثوانٍ وزفيراً لمدة ٤ ثوانٍ لتهدئة التوتر.",
      "قسّم موضوعات الاختبار إلى ٣ محطات صغيرة وواضحة الأولوية.",
      "ابدأ ورقة الامتحان بسؤالين مألوفين لبناء الثقة والتركيز.",
    ],
    question: {
      promptEn: "What is the most effective way to handle pre-exam tension?",
      promptAr: "ما هي الطريقة الأكثر فعالية للتعامل مع توتر قرب الامتحان؟",
      options: [
        {
          id: "a",
          textEn: "Slow your breathing and break review into 3 small, manageable steps",
          textAr: "تهدئة التنفس وتقسيم المراجعة إلى ٣ خطوات صغيرة وقابلة للإنجاز",
          isCorrect: true,
          feedbackEn: "Deep breath — notice how Hesi's calming mint aura is glowing! You've got this.",
          feedbackAr: "نفس عميق — لاحظ هالة هيسي الخضراء المهدئة! أنت مستعد وبإمكانك التفوق.",
        },
        {
          id: "b",
          textEn: "Panic-read ten chapters at once while watching the alarm clock",
          textAr: "قراءة عشرة فصول دفعة واحدة بتوتر مع مراقبة عقارب الساعة",
          isCorrect: false,
          feedbackEn: "One small step at a time calms the mind and sharpens recall.",
          feedbackAr: "خطوة صغيرة واحدة في كل مرة تهدّئ الذهن وتزيد قوة التذكر.",
        },
      ],
    },
  },
  "welcome-back": {
    id: "welcome-back",
    unitCode: "UNIT 10 • FRESH START",
    durationEn: "6 min warm-up",
    durationAr: "تهيئة ترحيبية • ٦ دقائق",
    titleEn: "Seamless Return & Momentum Reboot",
    titleAr: "العودة السلسة واستئناف الرحلة التعليمية بحماس",
    summaryEn:
      "Step back through Hesi's sunlit doorway after time away with a quick 3-minute refresher that reconnects you to your learning path.",
    summaryAr:
      "اعبر بوابة هيسي المضيئة بعد فترة غياب مع مراجعة تنشيطية سريعة لمدة ٣ دقائق تعيد ربطك بمسارك التعليمي بكل سلاسة.",
    keyTakeawaysEn: [
      "Returning after a break is a victory — start with a 3-minute warm-up.",
      "Review your last completed milestone before starting new material.",
      "Set a gentle, achievable goal for today's return session.",
    ],
    keyTakeawaysAr: [
      "العودة بعد الانقطاع خطوة رائعة — ابدأ بإحماء بسيط لمدة ٣ دقائق.",
      "راجع آخر محطة أنجزتها قبل البدء في درس جديد.",
      "ضع هدفاً لطيفاً وقابلاً للتحقيق لجلسة عودتك اليوم.",
    ],
    question: {
      promptEn: "What is the best way to restart your learning habit after time away?",
      promptAr: "ما أفضل طريقة لاستئناف عادة التعلم بعد فترة غياب؟",
      options: [
        {
          id: "a",
          textEn: "Begin with a welcoming 5-minute refresher on your last completed topic",
          textAr: "البدء بمراجعة تنشيطية خفيفة لمدة ٥ دقائق لآخر موضوع أتممته",
          isCorrect: true,
          feedbackEn: "Welcome back! We missed you — let's build fresh momentum together 💚",
          feedbackAr: "نورتنا من جديد! مستنيك دائماً — لننطلق معاً بحماس متجدد 💚",
        },
        {
          id: "b",
          textEn: "Try to make up for two weeks of lessons in a single exhausting sitting",
          textAr: "محاولة تعويض أسبوعين كاملين في جلسة واحدة مرهقة",
          isCorrect: false,
          feedbackEn: "A warm, steady 5-minute start is much more sustainable and enjoyable!",
          feedbackAr: "بداية دافئة ومتدرجة لمدة ٥ دقائق أكثر استدامة ومتعة!",
        },
      ],
    },
  },
};

const VALID_MASCOT_IDS = new Set<string>(ALL_MASCOTS.map((m) => m.id));

export function isValidMascotId(value: string | null | undefined): value is MascotId {
  return Boolean(value && VALID_MASCOT_IDS.has(value));
}

export function getMascotById(id: MascotId): MascotItem {
  return ALL_MASCOTS.find((m) => m.id === id) || ALL_MASCOTS[0];
}

/**
 * Reads the current route from the browser URL (`?lesson=<id>` or `#/lesson/<id>` or `/lesson/<id>`).
 */
export function parseLessonRouteFromLocation(): MascotId | null {
  if (typeof window === "undefined") return null;

  try {
    const params = new URLSearchParams(window.location.search);
    const fromQuery = params.get("lesson");
    if (isValidMascotId(fromQuery)) {
      return fromQuery;
    }

    const hashMatch = window.location.hash.match(/^#\/?lesson\/([a-z-]+)$/i);
    if (hashMatch && isValidMascotId(hashMatch[1])) {
      return hashMatch[1];
    }

    const pathMatch = window.location.pathname.match(/\/lesson\/([a-z-]+)\/?$/i);
    if (pathMatch && isValidMascotId(pathMatch[1])) {
      return pathMatch[1];
    }
  } catch {
    // Ignore URL parsing errors in restricted environments
  }

  return null;
}

/**
 * Builds the canonical URL for a lesson or home dashboard while preserving unrelated query parameters.
 */
export function buildLessonUrl(lessonId: MascotId | null): string {
  if (typeof window === "undefined") {
    return lessonId ? `?lesson=${lessonId}` : "/";
  }
  const url = new URL(window.location.href);
  if (lessonId) {
    url.searchParams.set("lesson", lessonId);
    url.hash = "";
  } else {
    url.searchParams.delete("lesson");
    if (url.hash.startsWith("#/lesson/") || url.hash.startsWith("#lesson/")) {
      url.hash = "";
    }
  }
  return `${url.pathname}${url.search}${url.hash}`;
}
