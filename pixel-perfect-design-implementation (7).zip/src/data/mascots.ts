export type MascotId =
  | "individual"
  | "pro"
  | "family"
  | "group"
  | "focused"
  | "happy"
  | "proud"
  | "sleepy"
  | "anxious"
  | "welcome-back";

export type MascotCategory = "subscription" | "emotional";

export interface LayerSpec {
  id: "body" | "face" | "props" | "particles" | "pedestal";
  label: string;
  description: string;
}

export interface MascotItem {
  id: MascotId;
  category: MascotCategory;
  nameEn: string;
  subtitleEn: string;
  nameAr: string;
  subtitleAr: string;
  badgeTextEn: string;
  badgeTextAr: string;
  accentColor: string;
  accentBg: string;
  descriptionEn: string;
  descriptionAr: string;
  learnerToastEn: string;
  learnerToastAr: string;
  motionProfile: string;
  reactionCue: string;
  iconType:
    | "book"
    | "cap"
    | "heart-group"
    | "team"
    | "target"
    | "smile"
    | "trophy"
    | "moon"
    | "worried"
    | "person";
  layers: LayerSpec[];
  planHighlight?: string;
}

export const SUBSCRIPTION_MASCOTS: MascotItem[] = [
  {
    id: "individual",
    category: "subscription",
    nameEn: "Individual",
    subtitleEn: "Personal Learning",
    nameAr: "فردي",
    subtitleAr: "تعلّم شخصي مركّز",
    badgeTextEn: "Solo Learner Plan",
    badgeTextAr: "باقة المتعلم الفردي",
    accentColor: "#16A34A",
    accentBg: "#ECFDF3",
    descriptionEn:
      "A single Hesi companion focused on self-paced study, holding an open dark-navy textbook above a glowing lime-green holographic ring surrounded by floating study particles.",
    descriptionAr:
      "رفيق هيسي الفردي يركز على التعلم الذاتي، ممسكاً بكتاب مفتوح فوق قاعدة هولوغرام خضراء مع جزيئات دراسة طافية.",
    learnerToastEn: "Your personal study session is ready — 15 minutes at your own pace.",
    learnerToastAr: "جلسة دراستك الشخصية جاهزة — ١٥ دقيقة بالسرعة التي تناسبك.",
    motionProfile: "4.6s gentle vertical float + holographic ring pulse + drifting rhombus study particles",
    reactionCue: "Page-check nod & holographic ring flare",
    iconType: "book",
    planHighlight: "1 Learner • Adaptive Path",
    layers: [
      { id: "pedestal", label: "Green Holo Base & Beam", description: "Segmented lime-green pedestal & vertical light cone" },
      { id: "body", label: "Faceted Hesi Body", description: "3D emerald shield silhouette with bottom yellow LED crystal" },
      { id: "face", label: "White Visor & Eye Sensor", description: "Arched white face panel and central black optical sensor" },
      { id: "props", label: "Open Navy Textbook & Hands", description: "Hardcover navy book with layered white pages and spherical hands" },
      { id: "particles", label: "Study Rhombuses & Swooshes", description: "Floating emerald study tiles and orbital energy arcs" },
    ],
  },
  {
    id: "pro",
    category: "subscription",
    nameEn: "Pro",
    subtitleEn: "Advanced Mastery",
    nameAr: "برو",
    subtitleAr: "إتقان متقدم واحترافي",
    badgeTextEn: "Pro Mastery Plan",
    badgeTextAr: "الباقة الاحترافية",
    accentColor: "#D97706",
    accentBg: "#FEFCE8",
    descriptionEn:
      "Confident advanced Hesi wearing the dark-navy mortarboard cap with a gold tassel, holding a sleek navy laptop in one hand and giving a thumbs-up above a navy-and-gold pedestal.",
    descriptionAr:
      "هيسي المتقدم بثقة عالية مع قبعة التخرج الكحلية والشرشوبة الذهبية وحاسوب محمول وإشارة إعجاب فوق قاعدة ذهبية وكحلية.",
    learnerToastEn: "Pro analytics unlocked — you're in the top 5% of problem solvers this week!",
    learnerToastAr: "تم تفعيل تحليلات برو — أنت ضمن أفضل ٥٪ في حل المسائل هذا الأسبوع!",
    motionProfile: "5.0s dignified hover + gold tassel sway + 4-point star sparkle twinkle + thumbs-up lift",
    reactionCue: "Confident thumbs-up salute & golden orbital shimmer",
    iconType: "cap",
    planHighlight: "1 Learner • Unlimited Labs & AI Coach",
    layers: [
      { id: "pedestal", label: "Navy & Gold Holo Base", description: "Dark-navy ring pedestal with glowing golden segments & amber beam" },
      { id: "body", label: "Faceted Hesi Body", description: "Glossy 3D emerald crystal body with bottom gold diamond LED" },
      { id: "face", label: "Confident Eye Sensor", description: "Crisp white visor panel with focused black sensor and specular glint" },
      { id: "props", label: "Mortarboard Cap, Laptop & Thumbs-Up", description: "Navy graduation cap with animated gold tassel, laptop & thumbs-up hand" },
      { id: "particles", label: "Golden Orbital Ring & Sparkles", description: "Sweeping gold ribbon arc and twinkling four-point achievement stars" },
    ],
  },
  {
    id: "family",
    category: "subscription",
    nameEn: "Family",
    subtitleEn: "Parents & Kids Together",
    nameAr: "عائلي",
    subtitleAr: "تعلّم العائلة معاً",
    badgeTextEn: "Family Circle Plan",
    badgeTextAr: "باقة العائلة",
    accentColor: "#16A34A",
    accentBg: "#ECFDF3",
    descriptionEn:
      "Warm parent-and-child quartet preserving distinct character sizes: parents with sculpted green hair waves embracing two smaller kids (one in a blue cap, one with a pink bow) beneath a pulsing green heart.",
    descriptionAr:
      "مجموعة عائلية دافئة تضم الوالدين والأطفال بأحجام متمايزة وهوية هيسي الخضراء المتناغمة مع نبضة قلب دافئة.",
    learnerToastEn: "Family milestone! Everyone completed their daily learning goal together 💚",
    learnerToastAr: "إنجاز عائلي رائع! أكمل جميع أفراد العائلة هدفهم اليومي معاً 💚",
    motionProfile: "4.4s synchronized parent-and-child bob with gentle phase offset + warm heart pulse",
    reactionCue: "Warm family hug bounce & floating heart pulse",
    iconType: "heart-group",
    planHighlight: "Up to 4 Family Members • Parent Dashboard",
    layers: [
      { id: "pedestal", label: "Shared Green Holo Base", description: "Wide emerald holographic pedestal supporting the whole family" },
      { id: "body", label: "Parent & Child Mascot Group", description: "Two large parent mascots and two smaller child mascots with distinct silhouettes" },
      { id: "face", label: "Expressive Family Visors", description: "Four distinct visors including eyelashes on mother and daughter mascots" },
      { id: "props", label: "Hair Waves, Blue Cap & Pink Bow", description: "Sculpted green hair tufts, child's blue cap, pink ribbon bow & embracing arms" },
      { id: "particles", label: "Floating Heart & Embrace Arcs", description: "Pulsing green heart emblem and protective side aura swooshes" },
    ],
  },
  {
    id: "group",
    category: "subscription",
    nameEn: "Group",
    subtitleEn: "Collaborative Study",
    nameAr: "مجموعات",
    subtitleAr: "تعلّم تشاركي وتعاوني",
    badgeTextEn: "Study Group & Classroom",
    badgeTextAr: "باقة المجموعات والفصول",
    accentColor: "#2563EB",
    accentBg: "#EFF6FF",
    descriptionEn:
      "Four mascots collaborating around a navy laptop and open blue textbooks — one wearing a purple beret and another cheering from above — over a vibrant cyan-blue holographic pedestal.",
    descriptionAr:
      "أربعة من رفاق هيسي يتعاونون حول الحاسوب والكتب الدراسية بتناغم حركي متدرج ولمسات زرقاء مميزة.",
    learnerToastEn: "3 study teammates are online in your group room — join the live review!",
    learnerToastAr: "٣ من زملاء المجموعة متصلون الآن — انضم إلى المراجعة التفاعلية!",
    motionProfile: "4.2s staggered 4-member wave choreography + floating blue/indigo tiles + cyan ring pulse",
    reactionCue: "Coordinated team wave & blue study tile orbit",
    iconType: "team",
    planHighlight: "5+ Learners • Shared Study Rooms",
    layers: [
      { id: "pedestal", label: "Cyan-Blue Holo Base", description: "Cobalt and sky-blue holographic ring base with glowing blue segments" },
      { id: "body", label: "4 Staggered Collaborator Mascots", description: "Four independently phased Hesi mascots arranged in a collaborative cluster" },
      { id: "face", label: "Coordinated Team Sensors", description: "Four attentive white visors angled toward shared learning materials" },
      { id: "props", label: "Laptop, Textbooks & Purple Beret", description: "Navy laptop, two open blue textbooks, purple beret, and cheering hand" },
      { id: "particles", label: "Blue & Violet Study Tiles", description: "Floating cyan, cobalt, and violet rounded squares and orbital arcs" },
    ],
  },
];

export const EMOTIONAL_MASCOTS: MascotItem[] = [
  {
    id: "focused",
    category: "emotional",
    nameEn: "Focused",
    subtitleEn: "Lesson Time",
    nameAr: "مركز",
    subtitleAr: "وقت الدرس",
    badgeTextEn: "Deep Study State",
    badgeTextAr: "حالة التركيز العميق",
    accentColor: "#0D9488",
    accentBg: "#F0FDFA",
    descriptionEn:
      "Hesi wearing cushioned navy-and-blue headphones, tilted slightly downward in deep concentration over an open blue book beside a laptop, glowing desk lamp, wall clock, and stacked books.",
    descriptionAr:
      "هيسي يرتدي سماعات الرأس ومنهمك في قراءة الكتاب وسط مكتب الدراسة مع المصباح والساعة والحاسوب المحمول.",
    learnerToastEn: "Deep focus mode active — notifications muted while you master this concept.",
    learnerToastAr: "وضع التركيز مفعل — هيسي يرافقك بهدوء حتى تكمل درسك بتركيز.",
    motionProfile: "5.2s calm breathing rhythm + slight downward attention tilt + periodic page movement & lamp glow",
    reactionCue: "Attentive page turn & warm desk-lamp illumination",
    iconType: "target",
    layers: [
      { id: "pedestal", label: "Study Desk, Lamp & Books", description: "Teal desk lamp with light cone, navy laptop, and stacked yellow/blue books" },
      { id: "body", label: "Breathing Hesi Body", description: "Faceted green crystal body with subtle downward study inclination" },
      { id: "face", label: "Attentive Reading Eye", description: "Focused black optical sensor directed toward the open book pages" },
      { id: "props", label: "Headphones & Open Book", description: "Over-ear navy/blue headphones and open hardcover book with animated pages" },
      { id: "particles", label: "Wall Clock, Note & Checklist UI", description: "Teal wall clock, green message icon, and floating task card" },
    ],
  },
  {
    id: "happy",
    category: "emotional",
    nameEn: "Happy",
    subtitleEn: "Correct Answer",
    nameAr: "فرحان",
    subtitleAr: "إجابة صح",
    badgeTextEn: "Correct Answer Celebration",
    badgeTextAr: "احتفال بالإجابة الصحيحة",
    accentColor: "#16A34A",
    accentBg: "#ECFDF3",
    descriptionEn:
      "Hesi bouncing joyfully with happy curved squinting eyes and a raised hand gesture beside a quiz card showing a highlighted green correct answer and a glossy checkmark badge.",
    descriptionAr:
      "هيسي يحتفل بالإجابة الصحيحة بعيون مبتسمة ويد مرفوعة مع علامة الصح الخضراء ونجوم الاحتفال.",
    learnerToastEn: "Spot on! That's 5 correct answers in a row — keep that momentum going!",
    learnerToastAr: "إجابة صحيحة ومميزة! أحسنت التفكير، استمر بهذا الحماس!",
    motionProfile: "3.2s joyful bounce + raised-hand celebration wave + checkmark pop + confetti burst",
    reactionCue: "Joyful celebration jump & confetti particle burst",
    iconType: "smile",
    layers: [
      { id: "pedestal", label: "Quiz Answer UI Card", description: "Floating white interface card highlighting the green verified answer row" },
      { id: "body", label: "Joyfully Tilted Hesi Body", description: "Dynamic tilted green crystal silhouette with glowing lime bottom tip" },
      { id: "face", label: "Happy Curved Eyes (^ ^)", description: "White visor displaying joyful curved eye arcs" },
      { id: "props", label: "Raised Celebration Hand & Check Badge", description: "Cheering left hand and glossy 3D green checkmark medallion" },
      { id: "particles", label: "Stars & Confetti Ribbons", description: "Burst of golden stars, blue confetti tags, and emerald motion swooshes" },
    ],
  },
  {
    id: "proud",
    category: "emotional",
    nameEn: "Proud",
    subtitleEn: "Module / Result Complete",
    nameAr: "فخور",
    subtitleAr: "إنهاء وعاء / نتيجة",
    badgeTextEn: "Achievement Unlocked",
    badgeTextAr: "إنجاز وإتمام النتيجة",
    accentColor: "#EAB308",
    accentBg: "#FEFCE8",
    descriptionEn:
      "Hesi standing tall on a green star-emblazoned achievement pedestal, wearing a billowing navy cape and holding aloft a gleaming golden trophy cup surrounded by rising golden arrows.",
    descriptionAr:
      "هيسي يقف بفخر فوق منصة الإنجاز مرتدياً الوشاح الكحلي ورافعاً كأس التفوق الذهبي وسط نجوم وأسهم الصعود.",
    learnerToastEn: "Unit complete! You earned the Golden Mastery Cup with a 96% score 🏆",
    learnerToastAr: "فخورون بك! أتممت الوحدة بنجاح وحققت كأس التفوق الذهبي 🏆",
    motionProfile: "4.4s heroic upward lift + billowing navy cape + golden trophy shimmer & rising arrows",
    reactionCue: "Heroic trophy hoist & golden star shimmer",
    iconType: "trophy",
    layers: [
      { id: "pedestal", label: "Star Achievement Pedestal", description: "3D tiered emerald podium with a golden five-point front star" },
      { id: "body", label: "Heroic Hesi Body", description: "Elevated green crystal body with glowing golden-lime chest/tip flare" },
      { id: "face", label: "Proud Upward Eye Sensor", description: "Confident white visor looking proudly toward the golden trophy" },
      { id: "props", label: "Golden Trophy & Flowing Navy Cape", description: "Star-crested gold trophy cup and animated dark-navy hero cape" },
      { id: "particles", label: "Rising Gold Arrows & Sparkles", description: "Upward golden achievement arrows and restrained four-point sparkles" },
    ],
  },
  {
    id: "sleepy",
    category: "emotional",
    nameEn: "Sleepy",
    subtitleEn: "Streak Rest / Recharge",
    nameAr: "نايم",
    subtitleAr: "كسر السلسلة",
    badgeTextEn: "Rest & Recharge",
    badgeTextAr: "استراحة وتجديد النشاط",
    accentColor: "#3B82F6",
    accentBg: "#EFF6FF",
    descriptionEn:
      "Hesi resting peacefully on a plush periwinkle pillow under a cozy navy blanket with a gently closed eye arc, crescent moon badge, and drifting Z symbols — warm and reassuring, never shaming.",
    descriptionAr:
      "هيسي يستريح بهدوء على وسادته مع الهلال ورموز النوم الطافية — تذكير لطيف ودافئ بأن الراحة جزء من التعلم دون أي لوم.",
    learnerToastEn: "Rest well! Great minds need sleep too — we'll pick right back up whenever you're ready 🌙",
    learnerToastAr: "نوم العوافي! الراحة تجدد الذهن — سنكمل رحلتنا معاً عندما تستعد بكل هدوء 🌙",
    motionProfile: "5.6s slow sleepy breathing bob + peacefully closed eye + drifting Z particles",
    reactionCue: "Cozy pillow snuggle & dreamy floating Z stream",
    iconType: "moon",
    layers: [
      { id: "pedestal", label: "Plush Pillow, Blanket & Resting Phone", description: "Soft periwinkle pillow, tucked navy blanket, and resting smartphone" },
      { id: "body", label: "Reclining Hesi Body", description: "Gently tilted green mascot nestled comfortably on the pillow" },
      { id: "face", label: "Peacefully Closed Eye Visor", description: "White visor with a calm sleeping crescent eye curve" },
      { id: "props", label: "Tucked Hands & Crescent Moon Badge", description: "Cozy hands tucked by the cheek and night-sky crescent moon icon" },
      { id: "particles", label: "Drifting 'Z' Symbols & Dream Tiles", description: "Floating blue Z letters and soft dreamy rounded squares" },
    ],
  },
  {
    id: "anxious",
    category: "emotional",
    nameEn: "Anxious",
    subtitleEn: "Exam Approaching",
    nameAr: "قلقان",
    subtitleAr: "قرب الامتحان",
    badgeTextEn: "Pre-Exam Support",
    badgeTextAr: "دعم ما قبل الامتحان",
    accentColor: "#2563EB",
    accentBg: "#F0F9FF",
    descriptionEn:
      "Hesi facing an upcoming EXAM sheet, yellow pencil, and twin-bell clock with gentle nervous ticks — paired with a soothing mint calming aura that settles the nerves and reassures the learner.",
    descriptionAr:
      "هيسي أمام ورقة الامتحان والقلم والمنبه مع حركة قلق خفيفة تتبعها هالة خضراء مهدئة تطمئن المتعلم وتخفف التوتر.",
    learnerToastEn: "Take a slow breath — we broke your exam prep into 3 bite-sized steps. You've got this!",
    learnerToastAr: "خذ نفساً عميقاً — قسّمنا المراجعة إلى خطوات بسيطة وهادئة، أنت مستعد وبإمكانك التفوق!",
    motionProfile: "Gentle nervous tremor & clock-hand tick -> transitions into a soothing mint calming aura",
    reactionCue: "Calming breath aura & reassuring composure",
    iconType: "worried",
    layers: [
      { id: "pedestal", label: "Calming Reassurance Aura", description: "Soothing mint-emerald breathing ring that calms pre-exam tension" },
      { id: "body", label: "Hesi Body with Calming Cycle", description: "Green mascot that transitions from a small tremor into calm steadiness" },
      { id: "face", label: "Expressive Brow & Sensor Visor", description: "Tilted worried brows and small sweat drops that soften with the calm cue" },
      { id: "props", label: "EXAM Sheet, Pencil & Twin-Bell Clock", description: "Printed EXAM paper, yellow pencil with pink eraser, and animated clock hand" },
      { id: "particles", label: "Alert Ticks & Calming Breath Waves", description: "Soft blue exclamation ticks balanced by reassuring mint glow" },
    ],
  },
  {
    id: "welcome-back",
    category: "emotional",
    nameEn: "Welcome Back",
    subtitleEn: "Absence & Return",
    nameAr: "مستنيك",
    subtitleAr: "غياب ورجوع",
    badgeTextEn: "Warm Return Greeting",
    badgeTextAr: "ترحيب دافئ بعودتك",
    accentColor: "#16A34A",
    accentBg: "#ECFDF3",
    descriptionEn:
      "Hesi waving warmly beside a sunlit open doorway and potted plant, topped with a pulsing green heart notification bubble to welcome the learner back with zero guilt.",
    descriptionAr:
      "هيسي يلوّح بترحيب دافئ بجانب بوابة مضيئة ونبتة خضراء مع نبضة قلب ترحيبية احتفاءً بعودة المتعلم.",
    learnerToastEn: "We missed you! Welcome back — let's pick up right where you left off 💚",
    learnerToastAr: "نورتنا من جديد! مستنيك دائماً — لنكمل من حيث توقفنا بكل حماس 💚",
    motionProfile: "4.5s warm float + friendly waving hand + sunlit doorway glow + heart notification pulse",
    reactionCue: "Warm welcoming wave & heart notification pulse",
    iconType: "person",
    layers: [
      { id: "pedestal", label: "Sunlit Doorway & Potted Plant", description: "Sky-blue portal frame with warm golden doorway light and leafy green plant" },
      { id: "body", label: "Welcoming Hesi Body", description: "Cheerful angled green crystal body stepping out to greet you" },
      { id: "face", label: "Warm Attentive Eye Sensor", description: "Bright white visor and friendly black sensor angled toward the learner" },
      { id: "props", label: "Friendly Waving Hand", description: "Independently animated raised left hand waving in greeting" },
      { id: "particles", label: "Heart Notification Bubble & Rays", description: "Pulsing green speech bubble with white heart and welcoming light rays" },
    ],
  },
];

export const ALL_MASCOTS: MascotItem[] = [...SUBSCRIPTION_MASCOTS, ...EMOTIONAL_MASCOTS];
