import {
  DEFAULT_LAYERS,
  HesiBody,
  HesiHand,
  HesiVisor,
  HoloPedestal,
  type LayerVisibility,
} from "./HesiCoreParts";

export interface MascotArtworkProps {
  layers?: LayerVisibility;
  className?: string;
}

/* ============================================================================
   1. INDIVIDUAL MASCOT (Personal Learning — Full Eye Reading Sweep + Page Turn + Articulated Arms)
   ============================================================================ */
export function IndividualMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 400"
      className={`mascot-individual h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Individual subscription mascot reading an open navy textbook above a green holographic ring"
    >
      {/* Layer 1: Pedestal & Holographic Ring */}
      {vis.pedestal && <HoloPedestal theme="green" cx={200} cy={342} scale={1.02} />}

      {/* Layer 2: Ambient Study Particles & Anime Wind Swooshes */}
      {vis.particles && (
        <g>
          {/* Left curved light-green wind swoosh */}
          <g transform="translate(94, 244)">
            <g data-rig="wind-arc-l" data-origin="center">
              <path
                d="M 10 -42 C -20 -16 -16 34 18 42 C -2 28 -4 -8 18 -32 Z"
                fill="#86EFAC"
                opacity="0.88"
              />
            </g>
          </g>
          {/* Right curved emerald wind swoosh */}
          <g transform="translate(308, 190)">
            <g data-rig="wind-arc-r" data-origin="center">
              <path
                d="M -8 -34 C 20 -22 22 22 -10 34 C 8 18 6 -14 -14 -26 Z"
                fill="#4ADE80"
                opacity="0.88"
              />
            </g>
          </g>
          {/* Left tilted mint rhombus */}
          <g transform="translate(88, 190) rotate(-28)">
            <g data-rig="particle" data-origin="center">
              <rect x="-10" y="-10" width="20" height="20" rx="4" fill="#6EE7B7" />
            </g>
          </g>
          {/* Top-right emerald study tile */}
          <g transform="translate(301, 135) rotate(18)">
            <g data-rig="particle" data-origin="center">
              <rect x="-7.5" y="-7.5" width="15" height="15" rx="3.5" fill="#34D399" />
            </g>
          </g>
          {/* Bottom-right tilted study rhombus */}
          <g transform="translate(297, 255) rotate(32)">
            <g data-rig="particle" data-origin="center">
              <rect x="-9.5" y="-9.5" width="19" height="19" rx="4" fill="#4ADE80" />
            </g>
          </g>
        </g>
      )}

      {/* Layer 3, 4 & 5: Floating Mascot Body + Full-Range Reading Eye + Book & Articulated Arms */}
      <g data-rig="main-float" data-origin="center">
        {vis.body && <HesiBody angle="front" transform="translate(200, 178) scale(1.06)" />}

        {vis.face && (
          <HesiVisor
            variant="default"
            lookX={0}
            lookY={2}
            transform="translate(200, 152) scale(1.04)"
          />
        )}

        {/* Layer 5: Open Dark-Navy Book, Flipping Page & Independently Articulated Left/Right Arms */}
        {vis.props && (
          <g transform="translate(200, 224)">
            <g data-rig="book-prop" data-origin="center">
              {/* White fanned book pages */}
              <path
                d="M -68 -36 Q -34 -28 0 -14 Q 34 -28 68 -36 L 64 12 Q 32 4 0 18 Q -32 4 -64 12 Z"
                fill="#F8FAFC"
                stroke="#CBD5E1"
                strokeWidth="1.5"
              />
              <path
                d="M -64 -31 Q -32 -23 0 -9 Q 32 -23 64 -31"
                fill="none"
                stroke="#94A3B8"
                strokeWidth="1.4"
              />
              {/* Animated turning page leaf that flips smoothly across the spine */}
              <g data-rig="flipping-page" data-origin="bottom left">
                <path
                  d="M 0 -12 Q 32 -28 62 -33 L 58 6 Q 28 2 0 15 Z"
                  fill="#FFFFFF"
                  stroke="#94A3B8"
                  strokeWidth="1.2"
                />
              </g>
              {/* Left navy cover */}
              <path
                d="M -72 -32 L -10 -12 L -10 34 L -64 14 Z"
                fill="#172B4D"
                stroke="#264270"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              {/* Right navy cover */}
              <path
                d="M 72 -32 L 10 -12 L 10 34 L 64 14 Z"
                fill="#132340"
                stroke="#264270"
                strokeWidth="1.5"
                strokeLinejoin="round"
              />
              {/* Center book spine */}
              <rect x="-10" y="-13" width="20" height="48" rx="3" fill="#233E6B" />

              {/* Left Articulated Hand & Arm Joint */}
              <g transform="translate(-66, 6)">
                <g data-rig="arm-left" data-origin="center">
                  <HesiHand cx={0} cy={0} r={19} />
                </g>
              </g>

              {/* Right Articulated Hand & Arm Joint (lifts & traces pages smoothly) */}
              <g transform="translate(66, 6)">
                <g data-rig="arm-right" data-origin="center">
                  <HesiHand cx={0} cy={0} r={19} />
                </g>
              </g>
            </g>
          </g>
        )}
      </g>
    </svg>
  );
}

/* ============================================================================
   2. PRO MASCOT (Confident Advanced — Sweeping Hero Thumbs-Up Arm + Laptop Arm + Tassel)
   ============================================================================ */
export function ProMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 400"
      className={`mascot-pro h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Pro subscription mascot wearing a navy graduation cap with gold tassel, holding a laptop and giving a thumbs up above a navy and gold pedestal"
    >
      {/* Layer 1: Navy & Gold Pedestal */}
      {vis.pedestal && <HoloPedestal theme="gold" cx={200} cy={342} scale={1.02} />}

      {/* Layer 2: Golden Orbital Energy Ribbons & 4-Point Sparkles */}
      {vis.particles && (
        <g>
          {/* Left sweeping golden orbital arc */}
          <g transform="translate(92, 226)">
            <g data-rig="wind-arc-l" data-origin="center">
              <path
                d="M 26 -36 C -30 -8 -32 40 26 32 C -10 28 -8 -2 32 -24 Z"
                fill="#FBBF24"
              />
            </g>
          </g>
          {/* Right sweeping golden orbital arc */}
          <g transform="translate(306, 180)">
            <g data-rig="wind-arc-r" data-origin="center">
              <path
                d="M -28 -32 C 32 -38 40 6 -10 34 C 18 8 14 -22 -32 -22 Z"
                fill="#F59E0B"
              />
            </g>
          </g>
          {/* Top-left 4-point gold star */}
          <g transform="translate(102, 138)">
            <g data-rig="particle" data-origin="center">
              <path
                d="M 0 -16 L 4 -4 L 16 0 L 4 4 L 0 16 L -4 4 L -16 0 L -4 -4 Z"
                fill="#FACC15"
              />
            </g>
          </g>
          {/* Bottom-right 4-point gold star */}
          <g transform="translate(304, 260)">
            <g data-rig="particle" data-origin="center">
              <path
                d="M 0 -16 L 4 -4 L 16 0 L 4 4 L 0 16 L -4 4 L -16 0 L -4 -4 Z"
                fill="#FACC15"
              />
            </g>
          </g>
        </g>
      )}

      {/* Layer 3, 4, 5: Mascot Body, Face, Cap, Laptop & Full-Arc Thumbs-up Arm */}
      <g data-rig="main-float" data-origin="center">
        {vis.body && <HesiBody angle="front" transform="translate(200, 184) scale(1.05)" />}

        {vis.face && (
          <HesiVisor
            variant="default"
            lookX={0}
            lookY={-1}
            transform="translate(202, 156) scale(1.03)"
          />
        )}

        {vis.props && (
          <g>
            {/* Dark-Navy Mortarboard Graduation Cap (with secondary tilt & pendulum tassel) */}
            <g transform="translate(200, 82)">
              <g data-rig="grad-cap" data-origin="center">
                {/* Fitted skullcap base */}
                <path
                  d="M -52 14 C -52 -6 52 -6 52 14 L 46 28 Q 0 18 -46 28 Z"
                  fill="#1E2F4D"
                />
                <path
                  d="M 0 -4 L 52 14 L 46 28 Q 24 22 0 22 Z"
                  fill="#15233B"
                />
                {/* Mortarboard diamond top */}
                <polygon
                  points="0,-24 94,4 0,26 -94,4"
                  fill="#16243D"
                  stroke="#2B426B"
                  strokeWidth="1.5"
                />
                {/* Center button */}
                <ellipse cx="0" cy="1" rx="6" ry="3.5" fill="#2B426B" />
                {/* Gold tassel cord & 60fps flowing pendulum tassel */}
                <path
                  d="M 0 1 Q 45 7 68 15"
                  stroke="#FACC15"
                  strokeWidth="3.2"
                  fill="none"
                  strokeLinecap="round"
                />
                <g transform="translate(68, 15)">
                  <g data-rig="tassel" data-origin="top">
                    <path
                      d="M 0 0 L 6 22"
                      stroke="#FACC15"
                      strokeWidth="3.2"
                      strokeLinecap="round"
                    />
                    <circle cx="4" cy="14" r="4.5" fill="#F59E0B" />
                    <polygon points="0,16 8,16 13,38 -2,38" fill="#FACC15" />
                  </g>
                </g>
              </g>
            </g>

            {/* Sleek Dark-Navy Laptop + Articulated Left Hand */}
            <g transform="translate(154, 224) rotate(-8)">
              <g data-rig="laptop-prop" data-origin="center">
                {/* Laptop screen back */}
                <rect
                  x="-48"
                  y="-34"
                  width="92"
                  height="62"
                  rx="7"
                  fill="#1D2E4A"
                  stroke="#334E7A"
                  strokeWidth="2"
                />
                {/* Laptop bottom keyboard lip */}
                <path d="M -38 28 L 58 28 L 68 34 L -44 34 Z" fill="#0F1B2E" />
                {/* Glowing light-blue diamond emblem on lid */}
                <g transform="translate(-2, -3) rotate(45)">
                  <rect x="-6.5" y="-6.5" width="13" height="13" rx="2" fill="#93C5FD" />
                  <rect x="-2.5" y="-2.5" width="5" height="5" rx="1" fill="#1D2E4A" />
                </g>
                {/* Articulated Left Hand clasping & tilting laptop */}
                <g transform="translate(-26, 26)">
                  <g data-rig="arm-left" data-origin="center">
                    <HesiHand cx={0} cy={0} r={19} />
                  </g>
                </g>
              </g>
            </g>

            {/* Articulated Right Shoulder, Arm & Thumbs-Up Hand (Full Anime Hero Salute Arc) */}
            <g transform="translate(264, 206)">
              <g data-rig="thumb-hand" data-origin="bottom left">
                {/* Sculpted green arm bridge from body to hand */}
                <path
                  d="M -14 14 C -4 4 8 -2 18 4 C 24 10 18 22 6 22 C -4 22 -14 18 -14 14 Z"
                  fill="#16A34A"
                />
                {/* Thumb cylinder pointing up */}
                <path
                  d="M 8 -4 C 6 -24 18 -34 24 -24 C 28 -18 26 -4 22 2 Z"
                  fill="#22C55E"
                />
                <HesiHand cx={16} cy={6} r={19} />
              </g>
            </g>
          </g>
        )}
      </g>
    </svg>
  );
}

/* ============================================================================
   3. FAMILY MASCOT (Parent & Child Quartet — Full Hugging Arms + Expressive Family Gaze)
   ============================================================================ */
export function FamilyMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 400"
      className={`mascot-family h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Family subscription mascots showing two parents and two children hugging beneath a green heart"
    >
      {/* Soft green family aura & protective side embrace swooshes */}
      {vis.particles && (
        <g>
          <g data-rig="particle" data-origin="center">
            <ellipse cx="200" cy="200" rx="135" ry="96" fill="#BBF7D0" opacity="0.32" />
          </g>
          <g transform="translate(84, 258)">
            <g data-rig="wind-arc-l" data-origin="center">
              <path
                d="M -20 -40 C -28 -4 -6 30 22 42 C 0 22 -12 -8 -10 -38 Z"
                fill="#22C55E"
              />
            </g>
          </g>
          <g transform="translate(316, 258)">
            <g data-rig="wind-arc-r" data-origin="center">
              <path
                d="M 20 -40 C 28 -4 6 30 -22 42 C 0 22 12 -8 10 -38 Z"
                fill="#22C55E"
              />
            </g>
          </g>
        </g>
      )}

      {/* Layer 1: Shared Green Holographic Pedestal */}
      {vis.pedestal && <HoloPedestal theme="green" cx={200} cy={344} scale={1.02} />}

      {/* Layer 2: Parents (Father & Mother with flowing hair tufts & affectionate gaze) */}
      <g>
        {/* Father Mascot (Top-Left) */}
        <g transform="translate(144, 166) rotate(-7) scale(0.76)">
          <g data-rig="dad" data-origin="center">
            {vis.body && <HesiBody angle="right" showTipGem={false} />}
            {vis.face && <HesiVisor variant="default" lookX={3} lookY={2} />}
            {vis.props && (
              /* Father's sculpted green hair wave on top (secondary anime breeze sway) */
              <g data-rig="hair-wave" data-origin="bottom left">
                <path
                  d="M -38 -68 C -28 -98 18 -96 38 -110 C 44 -82 28 -62 -10 -66 Z"
                  fill="#16A34A"
                />
              </g>
            )}
          </g>
        </g>

        {/* Mother Mascot (Top-Right) */}
        <g transform="translate(256, 170) rotate(8) scale(0.75)">
          <g data-rig="mom" data-origin="center">
            {vis.body && <HesiBody angle="left" showTipGem={false} />}
            {vis.face && <HesiVisor variant="default" lookX={-3} lookY={2} eyelashes />}
            {vis.props && (
              /* Mother's sculpted wavy green hair bun on top */
              <g data-rig="hair-wave" data-origin="bottom center" fill="#16A34A">
                <path d="M -34 -68 C -16 -98 36 -96 52 -64 C 24 -64 -10 -64 -34 -68 Z" />
                <circle cx="34" cy="-74" r="20" fill="#15803D" />
                <circle cx="14" cy="-82" r="18" fill="#22C55E" />
              </g>
            )}
          </g>
        </g>
      </g>

      {/* Layer 3: Children (Boy in Blue Cap & Girl with Pink Bow) + Full Embracing Arms */}
      <g>
        {/* Boy Child (Bottom-Left) */}
        <g transform="translate(162, 246) rotate(-6) scale(0.54)">
          <g data-rig="boy" data-origin="center">
            {vis.body && <HesiBody angle="front" showTipGem />}
            {vis.face && <HesiVisor variant="default" lookX={3} lookY={-2} />}
            {vis.props && (
              /* Cute Blue Baseball Cap with secondary visor bounce */
              <g transform="translate(0, -76)">
                <g data-rig="grad-cap" data-origin="center">
                  <path d="M -52 14 C -52 -24 52 -24 52 14 Z" fill="#1D4ED8" />
                  <path
                    d="M -48 10 Q 8 -6 66 12 Q 24 24 -48 14 Z"
                    fill="#3B82F6"
                  />
                </g>
              </g>
            )}
          </g>
        </g>

        {/* Girl Child (Bottom-Right) */}
        <g transform="translate(238, 248) rotate(7) scale(0.52)">
          <g data-rig="girl" data-origin="center">
            {vis.body && <HesiBody angle="front" showTipGem />}
            {vis.face && <HesiVisor variant="default" lookX={-3} lookY={-2} eyelashes />}
            {vis.props && (
              /* Cute Pink Bow on top (flutters playfully) */
              <g transform="translate(10, -78) rotate(12)">
                <g data-rig="pink-bow" data-origin="center">
                  <path d="M 0 0 L -26 -14 C -32 -6 -32 10 -24 14 Z" fill="#F472B6" />
                  <path d="M 0 0 L 26 -14 C 32 -6 32 10 24 14 Z" fill="#EC4899" />
                  <circle cx="0" cy="0" r="8" fill="#F9A8D4" />
                </g>
              </g>
            )}
          </g>
        </g>

        {/* Parents' Long Articulated Embracing Arms (Left & Right arms wrap in & hug) */}
        {vis.props && (
          <g>
            {/* Father's Left Embracing Arm */}
            <g transform="translate(108, 238)">
              <g data-rig="arm-left" data-origin="top left">
                <path
                  d="M -20 -24 C -26 8 -6 34 18 28 C 32 24 30 2 12 -4 C 0 -8 -4 -20 -10 -30 Z"
                  fill="#22C55E"
                />
                <HesiHand cx={16} cy={14} r={16} />
              </g>
            </g>
            {/* Mother's Right Embracing Arm */}
            <g transform="translate(292, 240)">
              <g data-rig="arm-right" data-origin="top right">
                <path
                  d="M 20 -24 C 26 8 6 34 -18 28 C -32 24 -30 2 -12 -4 C 0 -8 4 -20 10 -30 Z"
                  fill="#16A34A"
                />
                <HesiHand cx={-16} cy={14} r={16} />
              </g>
            </g>
          </g>
        )}
      </g>

      {/* Layer 4: Pulsing Green Heart above the family (60fps double-beat heart pulse) */}
      {vis.particles && (
        <g transform="translate(198, 76)">
          <g data-rig="family-heart" data-origin="center">
            <path
              d="M 0 18 C 0 18 -22 4 -22 -10 C -22 -20 -13 -26 -4 -22 C 0 -20 0 -15 0 -15 C 0 -15 0 -20 4 -22 C 13 -26 22 -20 22 -10 C 22 4 0 18 0 18 Z"
              fill="#22C55E"
            />
            <circle cx="-8" cy="-12" r="4" fill="#86EFAC" opacity="0.65" />
          </g>
        </g>
      )}
    </svg>
  );
}

/* ============================================================================
   4. GROUP MASCOT (Collaborative Quartet — Active Waving & Gesturing Arms + Team Gaze)
   ============================================================================ */
export function GroupMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 400"
      className={`mascot-group h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Group subscription mascots collaborating with a laptop and books above a blue holographic ring"
    >
      {/* Layer 1: Cyan-Blue Holographic Pedestal */}
      {vis.pedestal && <HoloPedestal theme="blue" cx={200} cy={344} scale={1.02} />}

      {/* Layer 2: Coordinated Blue & Violet Orbital Arcs & Study Tiles */}
      {vis.particles && (
        <g>
          <g transform="translate(120, 120)">
            <g data-rig="wind-arc-l" data-origin="center">
              <path
                d="M -32 28 C -18 -6 14 -26 36 -30 C 12 -16 -12 6 -24 34 Z"
                fill="#38BDF8"
              />
            </g>
          </g>
          <g transform="translate(90, 260)">
            <g data-rig="wind-arc-l" data-origin="center">
              <path
                d="M -14 -42 C -18 -6 -4 26 18 42 C 2 20 -6 -10 -4 -42 Z"
                fill="#38BDF8"
              />
            </g>
          </g>
          <g transform="translate(314, 174)">
            <g data-rig="wind-arc-r" data-origin="center">
              <path
                d="M -10 -38 C 10 -18 20 10 16 36 C 10 10 0 -14 -18 -32 Z"
                fill="#818CF8"
              />
            </g>
          </g>
          <g transform="translate(296, 280)">
            <g data-rig="wind-arc-r" data-origin="center">
              <path
                d="M 26 -28 C 16 0 -4 22 -26 32 C -8 16 8 -6 16 -32 Z"
                fill="#3B82F6"
              />
            </g>
          </g>
          {/* Floating study squares */}
          <g transform="translate(76, 184) rotate(-25)">
            <g data-rig="particle" data-origin="center">
              <rect x="-10" y="-10" width="20" height="20" rx="4" fill="#38BDF8" />
            </g>
          </g>
          <g transform="translate(285, 107)">
            <g data-rig="particle" data-origin="center">
              <rect x="-9.5" y="-9.5" width="19" height="19" rx="4" fill="#A5B4FC" />
            </g>
          </g>
          <g transform="translate(321, 225) rotate(28)">
            <g data-rig="particle" data-origin="center">
              <rect x="-11" y="-11" width="22" height="22" rx="4" fill="#3B82F6" />
            </g>
          </g>
        </g>
      )}

      {/* Member 1 (Top-Center cheering mascot with sweeping arm wave) */}
      <g transform="translate(198, 128) scale(0.60)">
        <g data-rig="member-1" data-origin="center">
          {vis.body && <HesiBody angle="front" showTipGem />}
          {vis.face && <HesiVisor variant="default" lookX={0} lookY={1} />}
          {vis.props && (
            <g>
              {/* Left hand resting on teammate's shoulder */}
              <g transform="translate(-58, 42)">
                <g data-rig="arm-left" data-origin="center">
                  <HesiHand cx={0} cy={0} r={18} />
                </g>
              </g>
              {/* Right cheering arm & thumb waving high */}
              <g transform="translate(82, -4)">
                <g data-rig="cheer-hand" data-origin="bottom left">
                  <path
                    d="M -18 14 C -6 2 8 -6 16 4 C 20 12 12 24 -2 22 Z"
                    fill="#16A34A"
                  />
                  <path
                    d="M -2 -2 C -4 -26 12 -36 20 -24 C 24 -16 20 2 14 8 Z"
                    fill="#22C55E"
                  />
                  <HesiHand cx={6} cy={10} r={20} />
                </g>
              </g>
            </g>
          )}
        </g>
      </g>

      {/* Member 2 (Middle-Left mascot with laptop & animated typing/holding hand) */}
      <g transform="translate(136, 198) scale(0.64)">
        <g data-rig="member-2" data-origin="center">
          {vis.body && <HesiBody angle="front" showTipGem={false} />}
          {vis.face && <HesiVisor variant="default" lookX={3} lookY={1} />}
          {vis.props && (
            <g transform="translate(-26, 56)">
              <g data-rig="laptop-prop" data-origin="center">
                <rect
                  x="-52"
                  y="-36"
                  width="98"
                  height="66"
                  rx="7"
                  fill="#1E3150"
                  stroke="#3B598A"
                  strokeWidth="2"
                />
                <g transform="translate(-3, -3) rotate(45)">
                  <rect x="-7" y="-7" width="14" height="14" rx="2" fill="#93C5FD" />
                </g>
                <g transform="translate(-40, 28)">
                  <g data-rig="arm-left" data-origin="center">
                    <HesiHand cx={0} cy={0} r={20} />
                  </g>
                </g>
              </g>
            </g>
          )}
        </g>
      </g>

      {/* Member 3 (Middle-Right mascot in purple beret with open book & gesturing hand) */}
      <g transform="translate(262, 202) rotate(6) scale(0.62)">
        <g data-rig="member-3" data-origin="center">
          {vis.body && <HesiBody angle="front" showTipGem={false} />}
          {vis.face && <HesiVisor variant="default" lookX={-3} lookY={2} />}
          {vis.props && (
            <g>
              {/* Purple beret cap */}
              <g data-rig="grad-cap" data-origin="bottom center">
                <path
                  d="M -36 -70 C -20 -104 64 -92 68 -52 C 42 -48 -14 -58 -36 -70 Z"
                  fill="#4F46E5"
                />
              </g>
              {/* Open blue book on right */}
              <g transform="translate(22, 54) rotate(-10)">
                <g data-rig="book-prop" data-origin="center">
                  <path
                    d="M -48 -24 L 0 -8 L 48 -24 L 42 22 L 0 36 L -42 22 Z"
                    fill="#F8FAFC"
                  />
                  <path d="M -52 -20 L -4 -4 L -4 38 L -46 24 Z" fill="#1D4ED8" />
                  <path d="M 52 -20 L 4 -4 L 4 38 L 46 24 Z" fill="#1E40AF" />
                  <g transform="translate(46, 8)">
                    <g data-rig="arm-right" data-origin="center">
                      <HesiHand cx={0} cy={0} r={19} />
                    </g>
                  </g>
                </g>
              </g>
            </g>
          )}
        </g>
      </g>

      {/* Member 4 (Front-Center smaller mascot reading open book with both hands articulated) */}
      <g transform="translate(200, 250) scale(0.56)">
        <g data-rig="member-4" data-origin="center">
          {vis.body && <HesiBody angle="front" showTipGem />}
          {vis.face && <HesiVisor variant="default" lookX={0} lookY={2} />}
          {vis.props && (
            <g transform="translate(0, 46)">
              <g data-rig="book-prop" data-origin="center">
                <path
                  d="M -56 -26 Q 0 -10 56 -26 L 52 14 Q 0 28 -52 14 Z"
                  fill="#F8FAFC"
                />
                <path d="M -60 -22 L -6 -6 L -6 30 L -54 16 Z" fill="#1E3A8A" />
                <path d="M 60 -22 L 6 -6 L 6 30 L 54 16 Z" fill="#172554" />
                <g transform="translate(-56, 8)">
                  <g data-rig="arm-left" data-origin="center">
                    <HesiHand cx={0} cy={0} r={18} />
                  </g>
                </g>
                <g transform="translate(56, 8)">
                  <g data-rig="arm-right" data-origin="center">
                    <HesiHand cx={0} cy={0} r={18} />
                  </g>
                </g>
              </g>
            </g>
          )}
        </g>
      </g>
    </svg>
  );
}
