import { useEffect, useId, useRef, type MouseEvent } from "react";
import type { MascotId } from "../data/mascots";
import type { LayerVisibility } from "./HesiCoreParts";
import {
  FamilyMascot,
  GroupMascot,
  IndividualMascot,
  ProMascot,
} from "./SubscriptionMascots";
import {
  AnxiousMascot,
  FocusedMascot,
  HappyMascot,
  ProudMascot,
  SleepyMascot,
  WelcomeBackMascot,
} from "./EmotionalMascots";
import { animationEngine60fps } from "../utils/animationEngine60fps";

interface MascotRendererProps {
  id: MascotId;
  layers?: LayerVisibility;
  className?: string;
  /** Phase offset in seconds so cards in a grid have organic staggered motion */
  phaseOffset?: number;
  /** Increment this number to fire a 60fps spring reaction impulse */
  reactionTrigger?: number;
  /** Optional viewport visibility flag from IntersectionObserver */
  inView?: boolean;
}

export default function MascotRenderer({
  id,
  layers,
  className = "",
  phaseOffset = 0,
  reactionTrigger = 0,
  inView = true,
}: MascotRendererProps) {
  const instanceId = useId();
  const containerRef = useRef<HTMLDivElement>(null);

  // Register with the 60fps animation engine on mount or when mascot `id` changes
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    animationEngine60fps.register(instanceId, id, el, phaseOffset);
    return () => {
      animationEngine60fps.unregister(instanceId);
    };
  }, [instanceId, id, phaseOffset]);

  // Re-scan rig nodes if SVG layers are toggled on/off
  useEffect(() => {
    animationEngine60fps.refreshNodes(instanceId);
  }, [
    instanceId,
    layers?.body,
    layers?.face,
    layers?.props,
    layers?.particles,
    layers?.pedestal,
  ]);

  // Update viewport visibility so off-screen mascots pause cleanly
  useEffect(() => {
    animationEngine60fps.setInView(instanceId, inView);
  }, [instanceId, inView]);

  // Fire 60fps spring physics impulse when reactionTrigger increments
  useEffect(() => {
    if (reactionTrigger > 0) {
      animationEngine60fps.triggerReaction(instanceId);
    }
  }, [instanceId, reactionTrigger]);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const nx = ((e.clientX - rect.left) / rect.width - 0.5) * 2; // -1 to +1
    const ny = ((e.clientY - rect.top) / rect.height - 0.5) * 2; // -1 to +1
    animationEngine60fps.setPointer(instanceId, nx, ny, true);
  };

  const handleMouseLeave = () => {
    animationEngine60fps.setPointer(instanceId, 0, 0, false);
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`h-full w-full ${className}`}
    >
      {id === "individual" && <IndividualMascot layers={layers} />}
      {id === "pro" && <ProMascot layers={layers} />}
      {id === "family" && <FamilyMascot layers={layers} />}
      {id === "group" && <GroupMascot layers={layers} />}
      {id === "focused" && <FocusedMascot layers={layers} />}
      {id === "happy" && <HappyMascot layers={layers} />}
      {id === "proud" && <ProudMascot layers={layers} />}
      {id === "sleepy" && <SleepyMascot layers={layers} />}
      {id === "anxious" && <AnxiousMascot layers={layers} />}
      {id === "welcome-back" && <WelcomeBackMascot layers={layers} />}
    </div>
  );
}
