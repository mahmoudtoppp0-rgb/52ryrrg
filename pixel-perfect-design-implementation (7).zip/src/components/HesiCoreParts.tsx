import { useId } from "react";

export interface LayerVisibility {
  body?: boolean;
  face?: boolean;
  props?: boolean;
  particles?: boolean;
  pedestal?: boolean;
}

export const DEFAULT_LAYERS: Required<LayerVisibility> = {
  body: true,
  face: true,
  props: true,
  particles: true,
  pedestal: true,
};

interface HesiBodyProps {
  /** Turn angle: "front" (symmetric) | "right" (3/4 facing right, showing left 3D side facet) | "left" (3/4 facing left) */
  angle?: "front" | "right" | "left";
  /** Show the yellow-lime glowing diamond at the bottom tip */
  showTipGem?: boolean;
  /** Optional scale or transform on the group */
  transform?: string;
  className?: string;
}

/**
 * Authentic 3D faceted green Hesi crystal body with upper bevel planes,
 * dynamic 60fps studio rim/sheen highlights, deep emerald side shading,
 * and bottom yellow-lime LED gem.
 */
export function HesiBody({
  angle = "front",
  showTipGem = true,
  transform,
  className = "",
}: HesiBodyProps) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const id = (name: string) => `hesi-body-${name}-${uid}`;

  // Main front shield-gem path centered at (0,0), height ~164 (-84 to +80), width ~142 (-71 to +71)
  const mainFrontPath =
    "M 0 -84 C 5 -84 10 -82 15 -79 L 61 -48 C 68 -43 72 -35 72 -25 L 72 18 C 72 30 66 41 56 48 L 12 77 C 5 82 -5 82 -12 77 L -56 48 C -66 41 -72 30 -72 18 L -72 -25 C -72 -35 -68 -43 -61 -48 L -15 -79 C -10 -82 -5 -84 0 -84 Z";

  return (
    <g transform={transform} className={className}>
      <defs>
        {/* Main glossy emerald body gradient */}
        <linearGradient id={id("faceGrad")} x1="0.15" y1="0" x2="0.85" y2="1">
          <stop offset="0%" stopColor="#38E06C" />
          <stop offset="42%" stopColor="#17B34A" />
          <stop offset="82%" stopColor="#0C8534" />
          <stop offset="100%" stopColor="#086426" />
        </linearGradient>

        {/* Top-left bright facet gradient */}
        <linearGradient id={id("topLeftFacet")} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#86EFAC" />
          <stop offset="55%" stopColor="#34D368" />
          <stop offset="100%" stopColor="#18A947" />
        </linearGradient>

        {/* Top-center facet gradient */}
        <linearGradient id={id("topCenterFacet")} x1="0.5" y1="0" x2="0.5" y2="1">
          <stop offset="0%" stopColor="#5CE687" />
          <stop offset="100%" stopColor="#1DB950" />
        </linearGradient>

        {/* Top-right facet gradient */}
        <linearGradient id={id("topRightFacet")} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#34D368" />
          <stop offset="100%" stopColor="#108E3B" />
        </linearGradient>

        {/* 3D Side depth facet for 3/4 views */}
        <linearGradient id={id("sideDepth")} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#16A34A" />
          <stop offset="55%" stopColor="#0B6E2E" />
          <stop offset="100%" stopColor="#05421B" />
        </linearGradient>

        {/* Bottom lime-yellow inner glow */}
        <radialGradient id={id("tipGlow")} cx="0.5" cy="0.78" r="0.38">
          <stop offset="0%" stopColor="#D9F99D" stopOpacity="0.95" />
          <stop offset="45%" stopColor="#84CC16" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#16A34A" stopOpacity="0" />
        </radialGradient>

        <clipPath id={id("clipMain")}>
          <path d={mainFrontPath} />
        </clipPath>
      </defs>

      {/* Optional 3D side extrude plane for 3/4 views */}
      {angle === "right" && (
        <path
          d="M 0 -84 L -16 -80 L -78 -44 C -84 -39 -88 -30 -88 -20 L -88 18 C -88 30 -81 40 -70 48 L -14 80 L 0 80 Z"
          fill={`url(#${id("sideDepth")})`}
        />
      )}
      {angle === "left" && (
        <path
          d="M 0 -84 L 16 -80 L 78 -44 C 84 -39 88 -30 88 -20 L 88 18 C 88 30 81 40 70 48 L 14 80 L 0 80 Z"
          fill={`url(#${id("sideDepth")})`}
        />
      )}

      {/* Main crystal body */}
      <path d={mainFrontPath} fill={`url(#${id("faceGrad")})`} />

      {/* Clipped internal facets, dynamic anime gloss, and bottom lime glow */}
      <g clipPath={`url(#${id("clipMain")})`}>
        {/* Top-left bevel facet */}
        <path d="M 0 -86 L -74 -38 L -38 -36 Z" fill={`url(#${id("topLeftFacet")})`} />
        {/* Top-right bevel facet */}
        <path d="M 0 -86 L 74 -38 L 38 -36 Z" fill={`url(#${id("topRightFacet")})`} />
        {/* Top-center triangular bevel facet */}
        <path
          d="M 0 -86 L -42 -36 Q 0 -43 42 -36 Z"
          fill={`url(#${id("topCenterFacet")})`}
        />

        {/* Crisp bevel ridge highlight lines */}
        <path
          d="M 0 -84 L -40 -36 M 0 -84 L 40 -36 M -72 -38 Q 0 -46 72 -38"
          stroke="#A7F3D0"
          strokeWidth="1.6"
          strokeOpacity="0.7"
          fill="none"
          strokeLinecap="round"
        />

        {/* Dynamic 60fps Studio Specular Sheen on upper-left cheek */}
        <g transform="translate(-28, -18) rotate(-18)">
          <g data-rig="body-sheen" data-origin="center">
            <ellipse
              cx="0"
              cy="0"
              rx="36"
              ry="19"
              fill="#FFFFFF"
              opacity="0.16"
            />
          </g>
        </g>

        {/* Deep lower ambient occlusion shade */}
        <path
          d="M -75 26 Q 0 54 75 26 L 75 90 L -75 90 Z"
          fill="#043917"
          opacity="0.28"
        />

        {/* Bottom tip lime-yellow energy aura */}
        {showTipGem && (
          <g transform="translate(0, 64)">
            <g data-rig="tip-aura" data-origin="center">
              <ellipse cx="0" cy="0" rx="36" ry="28" fill={`url(#${id("tipGlow")})`} />
            </g>
          </g>
        )}
      </g>

      {/* Subtle outer rim highlight */}
      <path
        d={mainFrontPath}
        fill="none"
        stroke="#6EE7B7"
        strokeWidth="1.5"
        strokeOpacity="0.48"
      />

      {/* Signature yellow-lime diamond LED at bottom tip (60fps animated) */}
      {showTipGem && (
        <g transform="translate(0, 67)">
          <g data-rig="tip-gem" data-origin="center">
            <polygon
              points="0,-7 6.5,0 0,7 -6.5,0"
              fill="#FACC15"
              stroke="#FEF08A"
              strokeWidth="1"
            />
            <polygon points="0,-3.5 3.2,0 0,3.5 -3.2,0" fill="#FEF9C3" />
          </g>
        </g>
      )}
    </g>
  );
}

export interface HesiVisorProps {
  variant?: "default" | "happy" | "sleepy" | "anxious";
  /** Offset sensor eye horizontally (-8 to +8) */
  lookX?: number;
  /** Offset sensor eye vertically (-4 to +4) */
  lookY?: number;
  /** Add cute eyelashes (for Mother & Daughter in Family) */
  eyelashes?: boolean;
  /** Optional transform for positioning visor on the face */
  transform?: string;
  className?: string;
}

/**
 * The signature Hesi white face panel and central black optical sensor eye.
 * Upgraded for full anime-style expressive movement:
 * - [data-rig="visor-panel"]: 3D head-turn parallax across the face
 * - [data-rig="eye-brow"]: expressive upper brow arch
 * - [data-rig="eye-sensor"]: full-range eye movement across the white visor + smooth blinking
 * - [data-rig="eye-glint"]: shimmering dual anime catchlights inside the optical sensor
 */
export function HesiVisor({
  variant = "default",
  lookX = 0,
  lookY = 0,
  eyelashes = false,
  transform = "translate(0, -16)",
  className = "",
}: HesiVisorProps) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const visorPath =
    "M -40 -14 Q 0 -20 40 -14 C 45 -13 48 -9 48 -4 L 48 12 C 48 17 44 20 39 20 L -39 20 C -44 20 -48 17 -48 12 L -48 -4 C -48 -9 -45 -13 -40 -14 Z";

  return (
    <g transform={transform} className={className}>
      <g data-rig="visor-panel" data-origin="center">
        <defs>
          <linearGradient id={`visor-top-${uid}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0B6E2E" stopOpacity="0.32" />
            <stop offset="35%" stopColor="#0B6E2E" stopOpacity="0" />
          </linearGradient>
          <filter id={`visor-shadow-${uid}`} x="-20%" y="-20%" width="140%" height="150%">
            <feDropShadow dx="0" dy="2.5" stdDeviation="2" floodColor="#064E23" floodOpacity="0.28" />
          </filter>
          <clipPath id={`visor-clip-${uid}`}>
            <path d={visorPath} />
          </clipPath>
        </defs>

        {/* Expressive green brow arch above visor */}
        <g data-rig="eye-brow" data-origin="center">
          <path
            d="M -38 -17 Q 0 -25 38 -17"
            stroke="#A7F3D0"
            strokeWidth="2.2"
            strokeOpacity="0.72"
            fill="none"
            strokeLinecap="round"
          />
        </g>

        {/* White visor plate */}
        <path d={visorPath} fill="#FFFFFF" filter={`url(#visor-shadow-${uid})`} />

        {/* Clipped interior of the visor so the eye sensor can glide all the way across smoothly */}
        <g clipPath={`url(#visor-clip-${uid})`}>
          {/* Variant 1: Default / Focused / Proud / Welcome Back / Anxious rectangular sensor eye */}
          {(variant === "default" || variant === "anxious") && (
            <g transform={`translate(${lookX}, ${lookY})`}>
              <g data-rig="eye-sensor" data-origin="center">
                {/* Optional feminine eyelashes (Mother & Daughter in Family) */}
                {eyelashes && (
                  <g stroke="#0B1320" strokeWidth="2.4" strokeLinecap="round">
                    <line x1="-13" y1="-10" x2="-19" y2="-15" />
                    <line x1="-13" y1="-5" x2="-20" y2="-8" />
                    <line x1="13" y1="-10" x2="19" y2="-15" />
                    <line x1="13" y1="-5" x2="20" y2="-8" />
                  </g>
                )}

                {/* Central rounded-rect black eye sensor */}
                <rect
                  x="-13"
                  y="-16"
                  width="26"
                  height="30"
                  rx="6.5"
                  fill="#0B1320"
                />

                {/* Subtle anime lower-iris emerald glow */}
                <path
                  d="M -10 6 Q 0 13 10 6 L 10 11 C 10 13 8 14 6 14 L -6 14 C -8 14 -10 13 -10 11 Z"
                  fill="#10B981"
                  opacity="0.32"
                />

                {/* Shimmering Anime Catchlights (Primary top-left + Secondary bottom-right) */}
                <g data-rig="eye-glint" data-origin="center">
                  <circle cx="-5.5" cy="-7.5" r="3.6" fill="#FFFFFF" />
                  <circle cx="5.2" cy="5.5" r="1.5" fill="#FFFFFF" opacity="0.85" />
                </g>
              </g>
            </g>
          )}

          {/* Variant 2: Happy (^ ^) curved joyful eyes inside the white visor */}
          {variant === "happy" && (
            <g stroke="#0B1320" strokeWidth="4.5" strokeLinecap="round" fill="none">
              <g transform="translate(-17, 0)">
                <g data-rig="happy-eye-l" data-origin="center">
                  <path d="M -12 6 Q 0 -9 12 6" />
                </g>
              </g>
              <g transform="translate(17, 0)">
                <g data-rig="happy-eye-r" data-origin="center">
                  <path d="M -12 6 Q 0 -9 12 6" />
                </g>
              </g>
            </g>
          )}

          {/* Variant 3: Sleepy peaceful closed eye curve inside the white visor */}
          {variant === "sleepy" && (
            <g data-rig="sleepy-eye" data-origin="center" stroke="#0B1320" strokeWidth="4.5" strokeLinecap="round" fill="none">
              <path d="M -18 -2 Q 2 14 20 -4" />
            </g>
          )}

          {/* Top inner visor shadow */}
          <path d={visorPath} fill={`url(#visor-top-${uid})`} />
        </g>

        {/* Additional articulated worried eyebrows + sweat drops for Anxious state */}
        {variant === "anxious" && (
          <g>
            {/* Left & Right worried eyebrows articulated independently */}
            <g transform="translate(-15, -25)">
              <g data-rig="worried-brow-l" data-origin="center">
                <path
                  d="M -9 2 L 8 -2"
                  stroke="#064E23"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
              </g>
            </g>
            <g transform="translate(15, -25)">
              <g data-rig="worried-brow-r" data-origin="center">
                <path
                  d="M 9 2 L -8 -2"
                  stroke="#064E23"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
              </g>
            </g>
            {/* Animated blue sweat droplets */}
            <g transform="translate(-56, 7)">
              <g data-rig="sweat-drop" data-origin="top center">
                <path
                  d="M 0 -9 C 0 -9 -5 0 -5 4 C -5 7 -2.5 9 0 9 C 2.5 9 5 7 5 4 C 5 0 0 -9 0 -9 Z"
                  fill="#60A5FA"
                />
              </g>
            </g>
            <g transform="translate(55, -6)">
              <g data-rig="sweat-drop" data-origin="top center">
                <path
                  d="M 0 -8 C 0 -8 -4 0 -4 3 C -4 6 -2 8 0 8 C 2 8 4 6 4 3 C 4 0 0 -8 0 -8 Z"
                  fill="#60A5FA"
                />
              </g>
            </g>
          </g>
        )}
      </g>
    </g>
  );
}

/**
 * Glossy 3D spherical green Hesi hand with subtle specular highlight.
 */
export function HesiHand({
  cx = 0,
  cy = 0,
  r = 18,
  className = "",
}: {
  cx?: number;
  cy?: number;
  r?: number;
  className?: string;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  return (
    <g className={className}>
      <defs>
        <radialGradient id={`hand-${uid}`} cx="0.32" cy="0.28" r="0.72">
          <stop offset="0%" stopColor="#86EFAC" />
          <stop offset="42%" stopColor="#22C55E" />
          <stop offset="100%" stopColor="#0B6E2E" />
        </radialGradient>
      </defs>
      <circle cx={cx} cy={cy} r={r} fill={`url(#hand-${uid})`} />
      <circle
        cx={cx - r * 0.28}
        cy={cy - r * 0.28}
        r={r * 0.24}
        fill="#FFFFFF"
        opacity="0.22"
      />
    </g>
  );
}

/**
 * 3D Holographic Pedestal Base used in the 4 Subscription Mascots
 * Themes: "green" (Individual & Family), "gold" (Pro), "blue" (Group)
 */
export function HoloPedestal({
  theme = "green",
  cx = 200,
  cy = 345,
  scale = 1,
  className = "",
}: {
  theme?: "green" | "gold" | "blue";
  cx?: number;
  cy?: number;
  scale?: number;
  className?: string;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");

  const palette = {
    green: {
      beamTop: "#86EFAC",
      beamBottom: "#22C55E",
      floorGlow: "#4ADE80",
      outerRimTop: "#4ADE80",
      outerRimBottom: "#0B6E2E",
      trackBg: "#053B19",
      innerRing: "#A3E635",
      dashColor: "#D9F99D",
      centerFill: "#15803D",
    },
    gold: {
      beamTop: "#FDE68A",
      beamBottom: "#F59E0B",
      floorGlow: "#FBBF24",
      outerRimTop: "#FACC15",
      outerRimBottom: "#1E293B",
      trackBg: "#0F172A",
      innerRing: "#FBBF24",
      dashColor: "#FDE047",
      centerFill: "#1E293B",
    },
    blue: {
      beamTop: "#7DD3FC",
      beamBottom: "#0284C7",
      floorGlow: "#38BDF8",
      outerRimTop: "#38BDF8",
      outerRimBottom: "#0369A1",
      trackBg: "#0C2D57",
      innerRing: "#38BDF8",
      dashColor: "#BAE6FD",
      centerFill: "#075985",
    },
  }[theme];

  // 7 front-arc glowing indicator segments matching the reference pedestals
  const segmentAngles = [-68, -45, -22, 0, 22, 45, 68];

  return (
    <g transform={`translate(${cx}, ${cy}) scale(${scale})`} className={className}>
      <defs>
        <linearGradient id={`beam-${uid}`} x1="0.5" y1="0" x2="0.5" y2="1">
          <stop offset="0%" stopColor={palette.beamTop} stopOpacity="0.0" />
          <stop offset="35%" stopColor={palette.beamTop} stopOpacity="0.42" />
          <stop offset="100%" stopColor={palette.beamBottom} stopOpacity="0.7" />
        </linearGradient>
        <radialGradient id={`floor-${uid}`} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor={palette.floorGlow} stopOpacity="0.58" />
          <stop offset="65%" stopColor={palette.floorGlow} stopOpacity="0.2" />
          <stop offset="100%" stopColor={palette.floorGlow} stopOpacity="0" />
        </radialGradient>
        <linearGradient id={`rim-${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={palette.outerRimTop} />
          <stop offset="100%" stopColor={palette.outerRimBottom} />
        </linearGradient>
      </defs>

      {/* Soft ambient floor glow */}
      <g data-rig="holo-ring" data-origin="center">
        <ellipse cx="0" cy="12" rx="124" ry="27" fill={`url(#floor-${uid})`} />
      </g>

      {/* Vertical holographic light beam (60fps breathing + rising anime light motes) */}
      <g data-rig="holo-beam" data-origin="bottom">
        <path
          d="M -42 -98 L 42 -98 L 68 0 L -68 0 Z"
          fill={`url(#beam-${uid})`}
        />
      </g>

      {/* Rising anime light motes inside the holographic beam */}
      <g transform="translate(-22, -26)">
        <g data-rig="beam-mote" data-origin="center">
          <circle cx="0" cy="0" r="2.8" fill={palette.dashColor} opacity="0.75" />
        </g>
      </g>
      <g transform="translate(18, -42)">
        <g data-rig="beam-mote" data-origin="center">
          <circle cx="0" cy="0" r="2.2" fill={palette.dashColor} opacity="0.7" />
        </g>
      </g>
      <g transform="translate(2, -18)">
        <g data-rig="beam-mote" data-origin="center">
          <circle cx="0" cy="0" r="3.2" fill="#FFFFFF" opacity="0.65" />
        </g>
      </g>

      {/* Pedestal 3D lower lip */}
      <ellipse cx="0" cy="5" rx="95" ry="24" fill={palette.outerRimBottom} />

      {/* Pedestal outer bevel disc */}
      <ellipse cx="0" cy="0" rx="95" ry="23" fill={`url(#rim-${uid})`} />

      {/* Dark recessed track */}
      <ellipse cx="0" cy="-1" rx="82" ry="18.5" fill={palette.trackBg} />

      {/* Glowing inner ring */}
      <g data-rig="holo-ring" data-origin="center">
        <ellipse
          cx="0"
          cy="-3"
          rx="58"
          ry="12.5"
          fill={palette.centerFill}
          stroke={palette.innerRing}
          strokeWidth="3.5"
        />
      </g>

      {/* 7 Glowing diode segments along the front track — each animated in a 60fps wave */}
      {segmentAngles.map((deg) => {
        const rad = ((deg + 90) * Math.PI) / 180;
        const x = Math.cos(rad) * 68;
        const y = Math.sin(rad) * 14.5 - 1;
        return (
          <g key={deg} transform={`translate(${x}, ${y})`}>
            <g data-rig="holo-diode" data-origin="center">
              <rect
                x={-5.5}
                y={-3}
                width="11"
                height="6"
                rx="3"
                fill={palette.dashColor}
              />
            </g>
          </g>
        );
      })}
    </g>
  );
}

/**
 * Circular green badge icons matching the bottom pills of Reference Image 2
 */
export function MascotBadgeIcon({
  type,
  accentColor = "#0D7A4E",
}: {
  type: string;
  accentColor?: string;
}) {
  return (
    <svg viewBox="0 0 44 44" className="h-10 w-10 shrink-0" aria-hidden="true">
      <circle cx="22" cy="22" r="20" fill={accentColor} />
      {type === "target" && (
        <g stroke="#FFFFFF" strokeWidth="2.2" fill="none" strokeLinecap="round">
          <circle cx="22" cy="22" r="11" />
          <circle cx="22" cy="22" r="6" />
          <circle cx="22" cy="22" r="2" fill="#FFFFFF" />
          <path d="M 29 15 L 35 9 M 31 9 L 35 9 L 35 13" />
        </g>
      )}
      {type === "smile" && (
        <g fill="#FFFFFF">
          <circle cx="17" cy="19" r="2.2" />
          <circle cx="27" cy="19" r="2.2" />
          <path d="M 15 25 C 17 30 27 30 29 25 Z" fill="#FFFFFF" />
        </g>
      )}
      {type === "trophy" && (
        <g fill="#FFFFFF">
          <path d="M 15 13 H 29 V 20 C 29 24.5 25.8 27.5 22 27.5 C 18.2 27.5 15 24.5 15 20 Z" />
          <path
            d="M 15 15 H 12 C 12 19 13.5 21 15.5 21.5 M 29 15 H 32 C 32 19 30.5 21 28.5 21.5"
            stroke="#FFFFFF"
            strokeWidth="2.2"
            fill="none"
          />
          <rect x="20" y="27" width="4" height="4" />
          <rect x="16" y="31" width="12" height="2.6" rx="1.3" />
          <circle cx="22" cy="19.5" r="2.1" fill={accentColor} />
        </g>
      )}
      {type === "moon" && (
        <g fill="#FFFFFF">
          <path d="M 25.5 13.5 C 20.5 14.2 17 18.5 17.8 23.8 C 18.5 28.5 22.8 31.5 27.5 30.5 C 23.5 32.8 18 31.2 15.5 27 C 13 22.8 14.5 17 18.8 14.5 C 20.8 13.3 23.2 13 25.5 13.5 Z" />
          <polygon points="28,15 29,17.2 31.2,18 29,18.8 28,21 27,18.8 24.8,18 27,17.2" />
        </g>
      )}
      {type === "worried" && (
        <g fill="#FFFFFF">
          <circle cx="17.5" cy="19.5" r="2.1" />
          <circle cx="26.5" cy="19.5" r="2.1" />
          <path
            d="M 16.5 28.5 C 18.5 25 25.5 25 27.5 28.5"
            stroke="#FFFFFF"
            strokeWidth="2.5"
            strokeLinecap="round"
            fill="none"
          />
        </g>
      )}
      {type === "person" && (
        <g fill="#FFFFFF">
          <circle cx="22" cy="17.5" r="4.5" />
          <path d="M 13.5 31 C 13.5 26.2 17.2 23.8 22 23.8 C 26.8 23.8 30.5 26.2 30.5 31 Z" />
        </g>
      )}
      {type === "book" && (
        <g stroke="#FFFFFF" strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M 12 16 L 22 19 L 32 16 L 32 29 L 22 32 L 12 29 Z" />
          <line x1="22" y1="19" x2="22" y2="32" />
        </g>
      )}
      {type === "cap" && (
        <g fill="#FFFFFF">
          <polygon points="22,12 34,18 22,24 10,18" />
          <path d="M 15 21.5 V 27.5 C 15 30 29 30 29 27.5 V 21.5 L 22 25 Z" />
          <line x1="32" y1="19" x2="32" y2="27" stroke="#FACC15" strokeWidth="2" />
        </g>
      )}
      {type === "heart-group" && (
        <path
          d="M 22 31 C 22 31 12 24.5 12 17.8 C 12 14.5 14.6 12 17.8 12 C 19.8 12 21.2 13 22 14.4 C 22.8 13 24.2 12 26.2 12 C 29.4 12 32 14.5 32 17.8 C 32 24.5 22 31 22 31 Z"
          fill="#FFFFFF"
        />
      )}
      {type === "team" && (
        <g fill="#FFFFFF">
          <circle cx="22" cy="15.5" r="3.5" />
          <circle cx="14.5" cy="18.5" r="2.8" />
          <circle cx="29.5" cy="18.5" r="2.8" />
          <path d="M 16 29 C 16 25 18.6 23 22 23 C 25.4 23 28 25 28 29 Z" />
        </g>
      )}
    </svg>
  );
}
