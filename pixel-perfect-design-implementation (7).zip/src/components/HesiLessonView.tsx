import { useEffect, useRef, useState } from "react";
import { ALL_MASCOTS, type MascotId } from "../data/mascots";
import { getMascotById, LESSON_MODULES } from "../data/lessons";
import { MascotBadgeIcon } from "./HesiCoreParts";
import MascotRenderer from "./MascotRenderer";
import type { LanguageMode } from "./MascotCard";
import type { ThemeMode } from "./HesiThemeCurtainTransition";

interface HesiLessonViewProps {
  lessonId: MascotId;
  lang: LanguageMode;
  theme: ThemeMode;
  isNavigating: boolean;
  onNavigateToLesson: (lessonId: MascotId) => void;
  onReturnToDashboard: () => void;
}

export default function HesiLessonView({
  lessonId,
  lang,
  theme,
  isNavigating,
  onNavigateToLesson,
  onReturnToDashboard,
}: HesiLessonViewProps) {
  const headingRef = useRef<HTMLHeadingElement>(null);
  const lesson = LESSON_MODULES[lessonId] || LESSON_MODULES.focused;
  const baseMascot = getMascotById(lessonId);

  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [lessonCompleted, setLessonCompleted] = useState(false);
  const [reactionTrigger, setReactionTrigger] = useState(0);

  // Reset interactive quiz state when lessonId changes and focus lesson title for accessibility
  useEffect(() => {
    setSelectedOptionId(null);
    setLessonCompleted(false);
    setReactionTrigger(0);
    // Focus heading smoothly without scrolling jump
    headingRef.current?.focus({ preventScroll: true });
  }, [lessonId]);

  const isDark = theme === "dark";
  const selectedOption = lesson.question.options.find((o) => o.id === selectedOptionId) || null;

  // Determine which Hesi emotional state accompanies the learner right now
  const activeCompanionMascotId: MascotId = lessonCompleted
    ? "proud"
    : selectedOption?.isCorrect
    ? "happy"
    : lessonId;

  const activeCompanionMascot = getMascotById(activeCompanionMascotId);

  // Compute Next Lesson in sequence
  const currentIdx = ALL_MASCOTS.findIndex((m) => m.id === lessonId);
  const nextMascot = ALL_MASCOTS[(currentIdx + 1) % ALL_MASCOTS.length];

  const handleSelectOption = (optionId: string) => {
    setSelectedOptionId(optionId);
    setReactionTrigger((c) => c + 1);
  };

  const handleCompleteLesson = () => {
    setLessonCompleted(true);
    setReactionTrigger((c) => c + 1);
  };

  return (
    <div
      data-lesson-ready={lessonId}
      className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8"
    >
      {/* Top Breadcrumb & Return Navigation Bar */}
      <div
        className={`flex flex-wrap items-center justify-between gap-4 border-b pb-5 ${
          isDark ? "border-[#1E3A5F]" : "border-[#DCEEE3]"
        }`}
      >
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onReturnToDashboard}
            disabled={isNavigating}
            className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-bold shadow-2xs transition-all hover:-translate-x-0.5 focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none disabled:cursor-wait disabled:opacity-75 ${
              isDark
                ? "border-[#1E3A5F] bg-[#0B172E] text-[#E2E8F0] hover:border-[#22C55E] hover:text-[#86EFAC]"
                : "border-[#BFE8D1] bg-white text-[#0F1D3A] hover:border-[#16A34A] hover:text-[#16A34A]"
            }`}
          >
            <span aria-hidden="true">←</span>
            <span>
              {lang === "ar" ? "العودة إلى لوحة هيسي" : "Back to Hesi Dashboard"}
            </span>
          </button>

          <span
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider ${
              isDark ? "bg-[#112E28] text-[#86EFAC]" : "bg-[#ECFDF3] text-[#16A34A]"
            }`}
          >
            <span>{lesson.unitCode}</span>
            <span>•</span>
            <span>{lang === "ar" ? lesson.durationAr : lesson.durationEn}</span>
          </span>
        </div>

        {/* Next Lesson Button (Triggers Hesi Forward Sweep) */}
        <button
          type="button"
          onClick={() => onNavigateToLesson(nextMascot.id)}
          disabled={isNavigating}
          className="inline-flex items-center gap-2 rounded-full bg-[#16A34A] px-4 py-2 text-xs font-bold text-white shadow-sm transition-all hover:bg-[#15803D] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none disabled:cursor-wait disabled:opacity-75"
        >
          <span>
            {lang === "ar"
              ? `الدرس التالي: ${nextMascot.nameAr}`
              : `Next Lesson: ${nextMascot.nameEn}`}
          </span>
          <span aria-hidden="true">→</span>
        </button>
      </div>

      {/* Main Lesson Workspace Grid */}
      <div className="mt-8 grid items-start gap-8 lg:grid-cols-12">
        {/* Left Column: Live 60 FPS Hesi Lesson Companion Stage */}
        <div className="lg:sticky lg:top-24 lg:col-span-5">
          <div
            className={`rounded-[30px] border p-6 transition-colors duration-300 ${
              isDark
                ? "border-[#1E3A5F] bg-gradient-to-b from-[#0E1E3A] via-[#0B172E] to-[#092028] shadow-[0_20px_50px_-15px_rgba(2,6,23,0.75)]"
                : "border-[#BFE8D1] bg-gradient-to-b from-[#F4FAFC] via-[#F2F9FB] to-[#E8F7F0] shadow-[0_20px_50px_-15px_rgba(22,163,74,0.14)]"
            }`}
          >
            <div className="flex items-center justify-between">
              <span
                className={`inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider ${
                  isDark ? "text-[#86EFAC]" : "text-[#0D7A3E]"
                }`}
              >
                <span className="h-2 w-2 rounded-full bg-[#22C55E]" />
                {lang === "ar" ? "رفيق الدرس المباشر" : "Live Lesson Companion"}
              </span>
              <button
                type="button"
                onClick={() => setReactionTrigger((c) => c + 1)}
                className={`rounded-full px-3 py-1 text-[11px] font-bold transition-colors ${
                  isDark
                    ? "bg-[#112E28] text-[#86EFAC] hover:bg-[#173F37]"
                    : "bg-white text-[#16A34A] hover:bg-[#DCFCE7]"
                }`}
              >
                ⚡ {lang === "ar" ? "تفاعل مع هيسي" : "High-Five Hesi"}
              </button>
            </div>

            {/* Interactive 60 FPS Mascot Stage */}
            <div
              role="button"
              tabIndex={0}
              onClick={() => setReactionTrigger((c) => c + 1)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  setReactionTrigger((c) => c + 1);
                }
              }}
              aria-label="Click or press Enter to interact with Hesi lesson companion"
              className="mx-auto my-2 flex aspect-square w-full max-w-[300px] cursor-pointer items-center justify-center rounded-2xl outline-none focus-visible:ring-2 focus-visible:ring-[#16A34A]"
            >
              <MascotRenderer
                id={activeCompanionMascotId}
                reactionTrigger={reactionTrigger}
              />
            </div>

            {/* Authentic Reference Image 2 Bottom Pill Badge */}
            <div
              className={`mx-auto flex max-w-[290px] items-center justify-between gap-3 rounded-full border px-3.5 py-2 ${
                isDark
                  ? "border-[#1E4638] bg-[#0F2926]"
                  : "border-[#BDE8D0] bg-white/90"
              }`}
            >
              <MascotBadgeIcon
                type={activeCompanionMascot.iconType}
                accentColor={activeCompanionMascot.accentColor}
              />
              <div className="text-center leading-tight">
                <div className="flex items-center justify-center gap-1.5">
                  <span
                    className={`font-display text-sm font-bold ${
                      isDark ? "text-white" : "text-[#0F1D3A]"
                    }`}
                  >
                    {activeCompanionMascot.nameEn}
                  </span>
                  <span className="text-xs text-[#94A3B8]">•</span>
                  <span
                    className={`font-arabic text-sm font-bold ${
                      isDark ? "text-[#86EFAC]" : "text-[#0F1D3A]"
                    }`}
                    dir="rtl"
                  >
                    {activeCompanionMascot.nameAr}
                  </span>
                </div>
                <p
                  className={`text-[11px] font-medium ${
                    isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
                  }`}
                >
                  {activeCompanionMascot.subtitleEn} /{" "}
                  <span className="font-arabic" dir="rtl">
                    {activeCompanionMascot.subtitleAr}
                  </span>
                </p>
              </div>
              <div className="w-3" aria-hidden="true" />
            </div>

            {/* Companion Speech Bubble */}
            <div
              className={`mt-4 rounded-2xl border p-4 ${
                isDark
                  ? "border-[#1E3A5F] bg-[#081225]"
                  : "border-[#DCEEE3] bg-white"
              }`}
            >
              <p
                dir={lang === "ar" ? "rtl" : "ltr"}
                className={`text-xs font-medium leading-relaxed ${
                  isDark ? "text-[#E2E8F0]" : "text-[#0F1D3A]"
                } ${lang === "ar" ? "font-arabic text-sm" : ""}`}
              >
                {lang === "ar"
                  ? activeCompanionMascot.learnerToastAr
                  : activeCompanionMascot.learnerToastEn}
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Lesson Content & Practice Check */}
        <div className="space-y-6 lg:col-span-7">
          {/* Lesson Header Card */}
          <div
            className={`rounded-[28px] border p-6 sm:p-8 ${
              isDark
                ? "border-[#1E3A5F] bg-[#0B172E]"
                : "border-[#DCEEE3] bg-white shadow-xs"
            }`}
          >
            <div className="flex flex-wrap items-center gap-2">
              <span
                className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold"
                style={
                  isDark
                    ? { backgroundColor: "rgba(34,197,94,0.16)", color: "#86EFAC" }
                    : { backgroundColor: baseMascot.accentBg, color: baseMascot.accentColor }
                }
              >
                {lang === "ar" ? baseMascot.badgeTextAr : baseMascot.badgeTextEn}
              </span>
            </div>

            <h1
              ref={headingRef}
              tabIndex={-1}
              dir={lang === "ar" ? "rtl" : "ltr"}
              className={`mt-3 font-display text-2xl font-extrabold tracking-tight outline-none sm:text-3xl ${
                isDark ? "text-white" : "text-[#0F1D3A]"
              } ${lang === "ar" ? "font-arabic" : ""}`}
            >
              {lang === "ar" ? lesson.titleAr : lesson.titleEn}
            </h1>

            {lang === "bilingual" && (
              <p
                dir="rtl"
                className="mt-1 font-arabic text-lg font-bold text-[#22C55E]"
              >
                {lesson.titleAr}
              </p>
            )}

            <p
              dir={lang === "ar" ? "rtl" : "ltr"}
              className={`mt-3 text-sm leading-relaxed ${
                isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
              } ${lang === "ar" ? "font-arabic text-base" : ""}`}
            >
              {lang === "ar" ? lesson.summaryAr : lesson.summaryEn}
            </p>

            {/* Key Takeaways List */}
            <div
              className={`mt-6 rounded-2xl border p-5 ${
                isDark
                  ? "border-[#1E3A5F] bg-[#081225]"
                  : "border-[#DCEEE3] bg-[#F7FCF9]"
              }`}
            >
              <h2
                dir={lang === "ar" ? "rtl" : "ltr"}
                className={`text-xs font-bold uppercase tracking-wider ${
                  isDark ? "text-[#86EFAC]" : "text-[#16A34A]"
                } ${lang === "ar" ? "font-arabic text-sm" : ""}`}
              >
                {lang === "ar" ? "أهم النقاط الرئيسية في هذا الدرس" : "Key Lesson Takeaways"}
              </h2>

              <ul
                dir={lang === "ar" ? "rtl" : "ltr"}
                className="mt-3 space-y-2.5"
              >
                {(lang === "ar" ? lesson.keyTakeawaysAr : lesson.keyTakeawaysEn).map(
                  (point, idx) => (
                    <li
                      key={idx}
                      className={`flex items-start gap-2.5 text-xs leading-relaxed sm:text-sm ${
                        isDark ? "text-[#E2E8F0]" : "text-[#0F1D3A]"
                      } ${lang === "ar" ? "font-arabic" : ""}`}
                    >
                      <span className="mt-0.5 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#16A34A] text-[11px] font-bold text-white">
                        {idx + 1}
                      </span>
                      <span>{point}</span>
                    </li>
                  )
                )}
              </ul>
            </div>
          </div>

          {/* Interactive Knowledge Check Card */}
          <div
            className={`rounded-[28px] border p-6 sm:p-8 ${
              isDark
                ? "border-[#1E3A5F] bg-[#0B172E]"
                : "border-[#DCEEE3] bg-white shadow-xs"
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#22C55E]">
                {lang === "ar" ? "سؤال التثبيت التفاعلي" : "Interactive Knowledge Check"}
              </span>
              {selectedOption?.isCorrect && (
                <span className="inline-flex items-center gap-1 rounded-full bg-[#16A34A] px-3 py-0.5 text-xs font-bold text-white">
                  ✓ {lang === "ar" ? "إجابة صحيحة!" : "Correct!"}
                </span>
              )}
            </div>

            <h2
              dir={lang === "ar" ? "rtl" : "ltr"}
              className={`mt-2 font-display text-lg font-extrabold ${
                isDark ? "text-white" : "text-[#0F1D3A]"
              } ${lang === "ar" ? "font-arabic text-xl" : ""}`}
            >
              {lang === "ar" ? lesson.question.promptAr : lesson.question.promptEn}
            </h2>

            <div className="mt-4 space-y-3">
              {lesson.question.options.map((opt) => {
                const isSelected = selectedOptionId === opt.id;
                const showCorrect = isSelected && opt.isCorrect;
                const showRetry = isSelected && !opt.isCorrect;

                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleSelectOption(opt.id)}
                    dir={lang === "ar" ? "rtl" : "ltr"}
                    className={`flex w-full items-center justify-between gap-3 rounded-2xl border p-4 text-left transition-all focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none ${
                      showCorrect
                        ? "border-[#22C55E] bg-[#16A34A]/15 text-[#16A34A] dark:text-[#86EFAC]"
                        : showRetry
                        ? "border-[#F59E0B] bg-[#FEFCE8]/20 text-[#D97706]"
                        : isDark
                        ? "border-[#1E3A5F] bg-[#081225] text-[#E2E8F0] hover:border-[#22C55E]/60"
                        : "border-[#DCEEE3] bg-[#F7FCF9] text-[#0F1D3A] hover:border-[#86EFAC]"
                    }`}
                  >
                    <span
                      className={`text-xs font-semibold sm:text-sm ${
                        lang === "ar" ? "font-arabic text-right" : ""
                      }`}
                    >
                      {lang === "ar" ? opt.textAr : opt.textEn}
                    </span>
                    <span
                      className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs font-bold ${
                        showCorrect
                          ? "border-[#16A34A] bg-[#16A34A] text-white"
                          : showRetry
                          ? "border-[#F59E0B] bg-[#F59E0B] text-white"
                          : "border-[#94A3B8]/50"
                      }`}
                    >
                      {showCorrect ? "✓" : showRetry ? "!" : opt.id.toUpperCase()}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Feedback Banner & Lesson Completion Trigger */}
            {selectedOption && (
              <div
                dir={lang === "ar" ? "rtl" : "ltr"}
                className={`mt-4 rounded-2xl border p-4 ${
                  selectedOption.isCorrect
                    ? isDark
                      ? "border-[#22C55E]/50 bg-[#0F2926] text-[#86EFAC]"
                      : "border-[#86EFAC] bg-[#ECFDF3] text-[#0D7A3E]"
                    : isDark
                    ? "border-[#F59E0B]/40 bg-[#261B0A] text-[#FDE68A]"
                    : "border-[#FDE68A] bg-[#FEFCE8] text-[#92400E]"
                }`}
              >
                <p className={`text-xs font-semibold sm:text-sm ${lang === "ar" ? "font-arabic" : ""}`}>
                  {lang === "ar" ? selectedOption.feedbackAr : selectedOption.feedbackEn}
                </p>

                {selectedOption.isCorrect && !lessonCompleted && (
                  <div className="mt-3">
                    <button
                      type="button"
                      onClick={handleCompleteLesson}
                      className="inline-flex items-center gap-2 rounded-full bg-[#16A34A] px-4 py-2 text-xs font-bold text-white shadow-xs transition-all hover:bg-[#15803D]"
                    >
                      <span>🏆</span>
                      <span>
                        {lang === "ar"
                          ? "إتمام الدرس واستلام كأس هيسي الذهبي"
                          : "Complete Lesson & Claim Hesi Trophy"}
                      </span>
                    </button>
                  </div>
                )}

                {lessonCompleted && (
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[#22C55E]/30 pt-3">
                    <span className="text-xs font-extrabold">
                      🎉{" "}
                      {lang === "ar"
                        ? "أحسنت! هيسي فخور بإتمامك هذا الدرس."
                        : "Milestone Complete! Hesi is proud of your mastery."}
                    </span>
                    <button
                      type="button"
                      onClick={() => onNavigateToLesson(nextMascot.id)}
                      disabled={isNavigating}
                      className="inline-flex items-center gap-1.5 rounded-full bg-[#16A34A] px-3.5 py-1.5 text-xs font-bold text-white hover:bg-[#15803D]"
                    >
                      <span>
                        {lang === "ar"
                          ? `الانتقال إلى: ${nextMascot.nameAr}`
                          : `Continue to ${nextMascot.nameEn}`}
                      </span>
                      <span aria-hidden="true">→</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* All 10 Lessons Quick Switcher Bar */}
          <div
            className={`rounded-[24px] border p-5 ${
              isDark
                ? "border-[#1E3A5F] bg-[#0B172E]"
                : "border-[#DCEEE3] bg-white"
            }`}
          >
            <p
              className={`mb-3 text-xs font-bold uppercase tracking-wider ${
                isDark ? "text-[#94A3B8]" : "text-[#475569]"
              }`}
            >
              {lang === "ar"
                ? "التنقل السريع بين دروس هيسي (١٠ وحدات)"
                : "Switch Lesson Module (Triggers Hesi Screen Sweep)"}
            </p>
            <div className="flex flex-wrap gap-2">
              {ALL_MASCOTS.map((m) => {
                const isCurrent = m.id === lessonId;
                return (
                  <button
                    key={m.id}
                    type="button"
                    disabled={isNavigating || isCurrent}
                    onClick={() => onNavigateToLesson(m.id)}
                    className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none ${
                      isCurrent
                        ? "border-[#16A34A] bg-[#16A34A] text-white shadow-xs"
                        : isDark
                        ? "border-[#1E3A5F] bg-[#081225] text-[#CBD5E1] hover:border-[#22C55E]"
                        : "border-[#DCEEE3] bg-[#F7FCF9] text-[#0F1D3A] hover:border-[#86EFAC]"
                    }`}
                  >
                    <span>{m.nameEn}</span>
                    <span className="font-arabic opacity-85" dir="rtl">
                      ({m.nameAr})
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
