import { useEffect, useRef, useState } from "react";
import { HesiBody, HesiHand, HesiVisor, MascotBadgeIcon } from "./HesiCoreParts";
import type { ThemeMode } from "./HesiThemeCurtainTransition";
import type { MascotId } from "../data/mascots";
import { getMascotById, LESSON_MODULES } from "../data/lessons";
import { playSweepWhoosh, stopSweepWhoosh } from "../utils/sweepSound";

export interface LessonNavigationTransitionState {
  /** Monotonically increasing ID for each user-initiated navigation */
  transitionId: number;
  /** Target lesson ID, or null when navigating back to the main dashboard */
  targetLessonId: MascotId | null;
  /** Sweep direction: "enter" (left-to-right into a lesson) or "return" (right-to-left back to dashboard) */
  direction: "enter" | "return";
}

export interface HesiLessonCurtainTransitionProps {
  transition: LessonNavigationTransitionState | null;
  /** Current application theme (preserved without modification) */
  theme: ThemeMode;
  /** Whether reduced motion / calm static mode is enabled */
  reducedMotion: boolean;
  /** Called when the curtain covers the viewport so the route change happens underneath */
  onCommitNavigation: (targetLessonId: MascotId | null) => void;
  /** Called when the transition completes and the temporary overlay should unmount */
  onComplete: () => void;
}

// Timing constants (ms)
const ENTRANCE_DURATION_MS = 120;
const SWEEP_DURATION_MS = 520;
const SWEEP_COMPLETE_MS = ENTRANCE_DURATION_MS + SWEEP_DURATION_MS; // 640 ms
export const READING_PAUSE_DURATION_MS = 2000; // Exact 2000 ms stationary reading hold after sweep settles
const REVEAL_DURATION_MS = 220;

// Smooth C2-continuous quintic S-curve for soft, intentional, tactile sweep
function smoothSweepCurve(u: number): number {
  const x = Math.max(0, Math.min(1, u));
  return x * x * x * (x * (x * 6 - 15) + 10);
}

export default function HesiLessonCurtainTransition({
  transition,
  theme,
  reducedMotion,
  onCommitNavigation,
  onComplete,
}: HesiLessonCurtainTransitionProps) {
  const curtainRef = useRef<HTMLDivElement>(null);
  const mascotMoverRef = useRef<HTMLDivElement>(null);
  const mascotPoseRef = useRef<SVGGElement>(null);
  const upperArmRef = useRef<SVGGElement>(null);
  const lowerArmRef = useRef<SVGGElement>(null);
  const contactGlowRef = useRef<SVGGElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);

  const [completedPush, setCompletedPush] = useState(false);
  const [phase, setPhase] = useState<"entrance" | "sweep" | "hold" | "reveal">("entrance");
  const committedRef = useRef(false);
  const completedRef = useRef(false);
  const soundTriggeredRef = useRef(false);
  const destinationReadyRef = useRef(false);

  const commitCbRef = useRef(onCommitNavigation);
  const completeCbRef = useRef(onComplete);
  useEffect(() => {
    commitCbRef.current = onCommitNavigation;
    completeCbRef.current = onComplete;
  }, [onCommitNavigation, onComplete]);

  useEffect(() => {
    if (!transition) return;

    committedRef.current = false;
    completedRef.current = false;
    soundTriggeredRef.current = false;
    destinationReadyRef.current = false;
    setCompletedPush(false);
    setPhase(reducedMotion ? "hold" : "entrance");

    const { transitionId, targetLessonId, direction } = transition;
    const isForward = direction === "enter";

    const commitRouteOnce = () => {
      if (committedRef.current) return;
      committedRef.current = true;
      try {
        commitCbRef.current(targetLessonId);
      } catch {
        // Ensure navigation errors never trap the user behind the overlay
      }
      // Verify that the destination view DOM has mounted underneath
      requestAnimationFrame(() => {
        const expectedSelector = targetLessonId
          ? `[data-lesson-ready="${targetLessonId}"]`
          : `[data-dashboard-ready="true"]`;
        if (document.querySelector(expectedSelector)) {
          destinationReadyRef.current = true;
        } else {
          requestAnimationFrame(() => {
            destinationReadyRef.current = true;
          });
        }
      });
    };

    const finishSafely = () => {
      commitRouteOnce();
      if (!completedRef.current) {
        completedRef.current = true;
        completeCbRef.current();
      }
    };

    // 1. Reduced-Motion Path: immediately show settled centered text, hold stationary for 2000ms, then gently reveal
    if (reducedMotion) {
      commitRouteOnce();
      setCompletedPush(true);
      const holdTimer = window.setTimeout(() => {
        setPhase("reveal");
        if (overlayRef.current) {
          overlayRef.current.style.transition = `opacity ${REVEAL_DURATION_MS}ms ease-out`;
          overlayRef.current.style.opacity = "0";
        }
      }, READING_PAUSE_DURATION_MS);

      const finishTimer = window.setTimeout(
        finishSafely,
        READING_PAUSE_DURATION_MS + REVEAL_DURATION_MS
      );

      return () => {
        window.clearTimeout(holdTimer);
        window.clearTimeout(finishTimer);
      };
    }

    // 2. Full 60fps Mascot-Driven Lesson Sweep + Exact 2000ms Stationary Reading Hold + Reveal
    const startTime = performance.now();
    let holdStartTime: number | null = null;
    let revealStartTime: number | null = null;
    let rafId: number | null = null;
    let settledTriggered = false;
    let currentPhaseTag: "entrance" | "sweep" | "hold" | "reveal" = "entrance";

    // Failsafe timeout accounts for entrance + sweep + 2000ms reading pause + reveal + buffer
    const totalExpectedMs =
      SWEEP_COMPLETE_MS + READING_PAUSE_DURATION_MS + REVEAL_DURATION_MS;
    const failsafeTimer = window.setTimeout(finishSafely, totalExpectedMs + 500);

    const step = (now: number) => {
      const elapsed = now - startTime;
      const vw = window.innerWidth;

      // Settled curtain leading-edge position places the 108vw curtain symmetrically from -4vw to +104vw,
      // so its center (54vw from curtain left) sits at exactly 50vw (dead-center of the viewport).
      const startEdge = isForward ? vw * 0.04 : vw * 0.96;
      const settledEdge = isForward ? vw * 1.04 : -vw * 0.04;
      const handContactOffset = isForward ? -92 : -128;
      const dirSign = isForward ? 1 : -1;

      let edgeX = settledEdge;
      let mascotOffsetX = 0;
      let mascotOffsetY = 0;
      let bodyRotate = 0;
      let scaleX = 1;
      let scaleY = 1;
      let armPushExtend = 8;
      let upperArmRot = dirSign * -16;
      let lowerArmRot = dirSign * -10;
      let upperArmY = -8;
      let lowerArmY = -5;
      let contactBurst = 0.35;
      let overlayOpacity = 1;

      if (elapsed < ENTRANCE_DURATION_MS) {
        // =====================================================================
        // PHASE 1: Smooth Entrance & Subtle Anticipation Crouch (0 .. 120 ms)
        // =====================================================================
        const p = elapsed / ENTRANCE_DURATION_MS; // 0..1
        const easeOut = 1 - Math.pow(1 - p, 3);
        edgeX = isForward ? easeOut * startEdge : vw - easeOut * (vw - startEdge);

        const entrySlide = (1 - easeOut) * (isForward ? -110 : 110);
        const crouch = Math.sin(p * Math.PI);
        mascotOffsetX = entrySlide;
        mascotOffsetY = crouch * 8;
        scaleX = 1 + crouch * 0.05;
        scaleY = 1 - crouch * 0.05;
        bodyRotate = (isForward ? -5 : 5) * crouch + (isForward ? 9 : -9) * easeOut;
        armPushExtend = easeOut * 9;
        upperArmRot = dirSign * -5;
        lowerArmRot = dirSign * 4;
        upperArmY = 0;
        lowerArmY = 0;
        contactBurst = easeOut * 0.65;
      } else if (elapsed < SWEEP_COMPLETE_MS) {
        // =====================================================================
        // PHASE 2: Physical Contact & Full-Viewport Sweep (120 .. 640 ms)
        // =====================================================================
        if (currentPhaseTag !== "sweep") {
          currentPhaseTag = "sweep";
          setPhase("sweep");
        }

        // Trigger the subtle 340ms airy whoosh once right as the sweep begins
        if (!soundTriggeredRef.current) {
          soundTriggeredRef.current = true;
          playSweepWhoosh(transitionId, reducedMotion);
        }

        const u = (elapsed - ENTRANCE_DURATION_MS) / SWEEP_DURATION_MS; // 0..1
        const wipe = smoothSweepCurve(u);
        edgeX = startEdge + (settledEdge - startEdge) * wipe;

        // Commit route navigation once the curtain covers >= 66% of the viewport
        if (wipe >= 0.66 && !committedRef.current) {
          commitRouteOnce();
        }

        // Smoothly damp out push lean & effort envelope as u -> 1.0 so Hesi lands in its exact settled pose at u = 1.0
        const glideWave = Math.sin(u * Math.PI * 2);
        const effortEnvelope = Math.sin(u * Math.PI); // 0 at u=0, 1 at u=0.5, 0 at u=1.0
        const settleBlend = u > 0.82 ? (u - 0.82) / 0.18 : 0; // 0..1 over final 18% of sweep
        const settleEase = settleBlend * settleBlend * (3 - 2 * settleBlend);

        mascotOffsetY = (Math.abs(glideWave) * -8 + effortEnvelope * 4) * (1 - settleEase);
        bodyRotate =
          ((isForward ? 13.5 : -13.5) + glideWave * (isForward ? 2.2 : -2.2)) *
          (1 - settleEase);
        scaleX = 1 - effortEnvelope * 0.038;
        scaleY = 1 + effortEnvelope * 0.038;

        armPushExtend = (10 + glideWave * 5 + effortEnvelope * 4) * (1 - settleEase) + 8 * settleEase;
        upperArmRot = (dirSign * -5) * (1 - settleEase) + (dirSign * -16) * settleEase;
        lowerArmRot = (dirSign * 4) * (1 - settleEase) + (dirSign * -10) * settleEase;
        upperArmY = -8 * settleEase;
        lowerArmY = -5 * settleEase;
        contactBurst = (0.7 + 0.25 * effortEnvelope) * (1 - settleEase) + 0.35 * settleEase;
      } else {
        // =====================================================================
        // SWEEP COMPLETED -> START & HOLD EXACT 2000 MS READING PAUSE
        // =====================================================================
        commitRouteOnce();

        if (holdStartTime === null) {
          // Record the exact timestamp when the sweep animation finished and settled
          holdStartTime = now;
        }

        if (!settledTriggered) {
          settledTriggered = true;
          setCompletedPush(true);
        }

        const holdElapsed = now - holdStartTime;

        if (holdElapsed < READING_PAUSE_DURATION_MS || (!destinationReadyRef.current && holdElapsed < READING_PAUSE_DURATION_MS + 150)) {
          // ===================================================================
          // PHASE 3: Exact 2000 ms Stationary Reading Hold
          // Curtain, centered text, background, and mascot remain completely stationary
          // ===================================================================
          if (currentPhaseTag !== "hold") {
            currentPhaseTag = "hold";
            setPhase("hold");
          }

          edgeX = settledEdge;
          mascotOffsetX = 0;
          mascotOffsetY = 0;
          bodyRotate = 0;
          scaleX = 1;
          scaleY = 1;
          armPushExtend = 8;
          upperArmRot = dirSign * -16;
          lowerArmRot = dirSign * -10;
          upperArmY = -8;
          lowerArmY = -5;
          contactBurst = 0.35;
          overlayOpacity = 1;
        } else {
          // ===================================================================
          // PHASE 4: Post-Hold Continuation & Clean Reveal (220 ms)
          // Begins only after the full 2000 ms reading hold has completed
          // ===================================================================
          if (revealStartTime === null) {
            revealStartTime = now;
          }
          if (currentPhaseTag !== "reveal") {
            currentPhaseTag = "reveal";
            setPhase("reveal");
          }

          const revealElapsed = now - revealStartTime;
          const f = Math.min(1, Math.max(0, revealElapsed / REVEAL_DURATION_MS)); // 0..1

          edgeX = settledEdge;
          const releaseArc = Math.sin(f * Math.PI);
          mascotOffsetX = dirSign * (f * 115);
          mascotOffsetY = -releaseArc * 16;
          bodyRotate = (isForward ? -6 : 6) * releaseArc;
          scaleX = 1 - releaseArc * 0.025;
          scaleY = 1 + releaseArc * 0.035;
          armPushExtend = 8 * (1 - f);
          upperArmRot = dirSign * -16;
          lowerArmRot = dirSign * -10;
          upperArmY = -8;
          lowerArmY = -5;
          contactBurst = Math.max(0, 0.35 * (1 - f * 2));

          // Smoothly reveal the rendered destination page underneath
          overlayOpacity = 1 - Math.pow(f, 1.5);

          if (f >= 1) {
            finishSafely();
            return;
          }
        }
      }

      // Apply GPU-composited transforms. During the 2000ms hold, edgeX = settledEdge,
      // which snaps to an exact integer pixel so the centered text is razor-sharp and completely stationary.
      if (overlayRef.current) {
        overlayRef.current.style.opacity = overlayOpacity.toFixed(3);
      }

      if (curtainRef.current) {
        const rawCurtainX = isForward ? edgeX - vw * 1.08 : edgeX;
        const alignedCurtainX =
          currentPhaseTag === "hold" || currentPhaseTag === "reveal"
            ? Math.round(rawCurtainX)
            : Number(rawCurtainX.toFixed(1));
        curtainRef.current.style.transform = `translate3d(${alignedCurtainX}px, 0, 0)`;
      }

      if (mascotMoverRef.current) {
        const rawMx = edgeX + handContactOffset + mascotOffsetX;
        const alignedMx =
          currentPhaseTag === "hold" ? Math.round(rawMx) : Number(rawMx.toFixed(1));
        const alignedMy =
          currentPhaseTag === "hold" ? 0 : Number(mascotOffsetY.toFixed(1));
        mascotMoverRef.current.style.transform = `translate3d(${alignedMx}px, ${alignedMy}px, 0)`;
      }

      if (mascotPoseRef.current) {
        mascotPoseRef.current.style.transform = `rotate(${bodyRotate.toFixed(2)}deg) scale3d(${scaleX.toFixed(3)}, ${scaleY.toFixed(3)}, 1)`;
      }

      if (upperArmRef.current) {
        upperArmRef.current.style.transform = `translate3d(${(dirSign * armPushExtend).toFixed(1)}px, ${upperArmY.toFixed(1)}px, 0) rotate(${upperArmRot.toFixed(1)}deg)`;
      }

      if (lowerArmRef.current) {
        lowerArmRef.current.style.transform = `translate3d(${(dirSign * armPushExtend * 1.06).toFixed(1)}px, ${lowerArmY.toFixed(1)}px, 0) rotate(${lowerArmRot.toFixed(1)}deg)`;
      }

      if (contactGlowRef.current) {
        contactGlowRef.current.style.opacity = contactBurst.toFixed(3);
        const gs = 0.88 + contactBurst * 0.28;
        contactGlowRef.current.style.transform = `scale3d(${gs.toFixed(3)}, ${gs.toFixed(3)}, 1)`;
      }

      rafId = requestAnimationFrame(step);
    };

    rafId = requestAnimationFrame(step);

    return () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      window.clearTimeout(failsafeTimer);
      stopSweepWhoosh();
    };
  }, [transition, reducedMotion]);

  if (!transition) return null;

  const isDark = theme === "dark";
  const isForward = transition.direction === "enter";
  const mascotItem = transition.targetLessonId
    ? getMascotById(transition.targetLessonId)
    : getMascotById("focused");
  const lessonModule = transition.targetLessonId
    ? LESSON_MODULES[transition.targetLessonId]
    : null;

  // Reduced-motion path: stationary curtain with sharp centered text held for the full 2000ms reading pause
  if (reducedMotion) {
    return (
      <div
        ref={overlayRef}
        data-transition-phase={phase}
        aria-hidden="true"
        className={`pointer-events-none fixed inset-0 z-[100] flex items-center justify-center overflow-hidden select-none ${
          isDark
            ? "bg-gradient-to-r from-[#061224] via-[#0B1D36] to-[#0E2B2A]"
            : "bg-gradient-to-r from-[#F4FBF7] via-[#E8F8EF] to-[#D8F3E5]"
        }`}
      >
        <div
          data-transition-text="true"
          className={`flex items-center gap-3.5 rounded-full border px-5 py-3 shadow-lg ${
            isDark
              ? "border-[#22C55E]/40 bg-[#0B172E] text-white"
              : "border-[#9CE0B9] bg-white text-[#0F1D3A]"
          }`}
        >
          <MascotBadgeIcon
            type={mascotItem.iconType}
            accentColor={mascotItem.accentColor}
          />
          <div className="text-left leading-tight">
            <p className="text-[11px] font-bold uppercase tracking-wider text-[#22C55E]">
              {lessonModule ? lessonModule.unitCode : "HESI PLATFORM"}
            </p>
            <p className="font-display text-base font-extrabold">
              {lessonModule ? lessonModule.titleEn : "Hesi Learning Dashboard"}
            </p>
            <p className="font-arabic text-xs font-semibold opacity-85" dir="rtl">
              {lessonModule ? lessonModule.titleAr : "العودة إلى لوحة تعبيرات هيسي"}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={overlayRef}
      data-transition-phase={phase}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[100] overflow-hidden select-none"
    >
      {/* =====================================================================
          1. FULL-VIEWPORT LESSON CURTAIN SURFACE PUSHED BY HESI
             (Preserves current Day/Night theme while showcasing lesson identity)
          ===================================================================== */}
      <div
        ref={curtainRef}
        style={{ width: "108vw", height: "100dvh", willChange: "transform" }}
        className={`absolute top-0 left-0 ${
          isDark
            ? isForward
              ? "bg-gradient-to-r from-[#061224] via-[#0B1D36] to-[#0E2B2A] shadow-[24px_0_60px_rgba(2,6,23,0.7)]"
              : "bg-gradient-to-l from-[#061224] via-[#0B1D36] to-[#0E2B2A] shadow-[-24px_0_60px_rgba(2,6,23,0.7)]"
            : isForward
            ? "bg-gradient-to-r from-[#F4FBF7] via-[#E8F8EF] to-[#D8F3E5] shadow-[24px_0_60px_rgba(15,29,58,0.16)]"
            : "bg-gradient-to-l from-[#F4FBF7] via-[#E8F8EF] to-[#D8F3E5] shadow-[-24px_0_60px_rgba(15,29,58,0.16)]"
        }`}
      >
        <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
          {/* Soft Ambient Learning Aura matching the lesson's Hesi palette */}
          <div
            className="pointer-events-none absolute h-[30rem] w-[30rem] rounded-full opacity-35 blur-3xl"
            style={{
              background: `radial-gradient(circle, ${mascotItem.accentColor}, transparent 70%)`,
            }}
          />

          {/* Subtle Hesi Study Rhombus Motifs */}
          <svg
            viewBox="0 0 40 40"
            className="absolute top-[20%] left-[22%] h-8 w-8 opacity-45"
          >
            <rect
              x="8"
              y="8"
              width="24"
              height="24"
              rx="5"
              transform="rotate(-22 20 20)"
              fill="#22C55E"
            />
          </svg>
          <svg
            viewBox="0 0 40 40"
            className="absolute right-[24%] bottom-[22%] h-9 w-9 opacity-45"
          >
            <rect
              x="8"
              y="8"
              width="24"
              height="24"
              rx="5"
              transform="rotate(26 20 20)"
              fill={mascotItem.accentColor}
            />
          </svg>

          {/* Center Lesson / Destination Badge Pill on the Curtain (Stationary & Sharp during 2000ms hold) */}
          <div
            data-transition-text="true"
            className={`flex items-center gap-3.5 rounded-full border px-5 py-3 shadow-lg ${
              isDark
                ? "border-[#22C55E]/40 bg-[#0B172E] text-white"
                : "border-[#9CE0B9] bg-white text-[#0F1D3A]"
            }`}
          >
            <MascotBadgeIcon
              type={mascotItem.iconType}
              accentColor={mascotItem.accentColor}
            />
            <div className="text-left leading-tight">
              <p className="text-[11px] font-bold uppercase tracking-wider text-[#22C55E]">
                {lessonModule ? lessonModule.unitCode : "HESI PLATFORM"}
              </p>
              <p className="font-display text-base font-extrabold">
                {lessonModule ? lessonModule.titleEn : "Hesi Learning Dashboard"}
              </p>
              <p className="font-arabic text-xs font-semibold opacity-85" dir="rtl">
                {lessonModule ? lessonModule.titleAr : "العودة إلى لوحة تعبيرات هيسي"}
              </p>
            </div>
          </div>

          {/* Glowing Leading-Edge Seam where Hesi's Hands Push */}
          {isForward ? (
            <>
              <div className="absolute inset-y-0 right-0 w-2.5 bg-gradient-to-b from-[#86EFAC] via-[#22C55E] to-[#FACC15] shadow-[0_0_26px_#22C55E]" />
              <div className="absolute inset-y-0 right-2.5 w-8 bg-gradient-to-l from-[#22C55E]/25 to-transparent" />
            </>
          ) : (
            <>
              <div className="absolute inset-y-0 left-0 w-2.5 bg-gradient-to-b from-[#FACC15] via-[#22C55E] to-[#86EFAC] shadow-[0_0_26px_#22C55E]" />
              <div className="absolute inset-y-0 left-2.5 w-8 bg-gradient-to-r from-[#22C55E]/25 to-transparent" />
            </>
          )}
        </div>
      </div>

      {/* =====================================================================
          2. HESI MASCOT PHYSICALLY PUSHING THE LESSON CURTAIN EDGE
          ===================================================================== */}
      <div
        ref={mascotMoverRef}
        style={{
          top: "calc(50dvh - 110px)",
          left: 0,
          width: "220px",
          height: "220px",
          willChange: "transform",
        }}
        className="absolute"
      >
        <svg
          viewBox="0 0 260 260"
          className="h-full w-full overflow-visible drop-shadow-[0_18px_32px_rgba(15,29,58,0.32)]"
        >
          {/* Glowing Contact Ripple right where Hesi's hands push the curtain seam */}
          <g
            ref={contactGlowRef}
            transform={isForward ? "translate(112, 128)" : "translate(148, 128)"}
            style={{ transformBox: "fill-box", transformOrigin: "center" }}
          >
            <ellipse cx="0" cy="0" rx="20" ry="68" fill="#4ADE80" opacity="0.42" />
            <ellipse cx="0" cy="0" rx="9" ry="44" fill="#FFFFFF" opacity="0.72" />
          </g>

          {/* Hesi Character Group with Push Lean, Effort Compression & Settled Hold */}
          <g transform="translate(130, 134)">
            <g
              ref={mascotPoseRef}
              style={{ transformBox: "fill-box", transformOrigin: "center bottom" }}
            >
              {/* Subtle Air-Sweep Lines behind Hesi (hidden once settled in hold phase) */}
              <g opacity={completedPush ? "0" : "0.78"}>
                {isForward ? (
                  <>
                    <path
                      d="M -76 -20 H -112"
                      stroke="#4ADE80"
                      strokeWidth="4.5"
                      strokeLinecap="round"
                    />
                    <path
                      d="M -82 18 H -126"
                      stroke="#86EFAC"
                      strokeWidth="5.5"
                      strokeLinecap="round"
                    />
                  </>
                ) : (
                  <>
                    <path
                      d="M 76 -20 H 112"
                      stroke="#4ADE80"
                      strokeWidth="4.5"
                      strokeLinecap="round"
                    />
                    <path
                      d="M 82 18 H 126"
                      stroke="#86EFAC"
                      strokeWidth="5.5"
                      strokeLinecap="round"
                    />
                  </>
                )}
              </g>

              {/* Authentic 3D Faceted Emerald Hesi Body */}
              <HesiBody
                angle={isForward ? "right" : "left"}
                showTipGem
                transform="scale(0.84)"
              />

              {/* Authentic Hesi Visor & Optical Sensor looking toward the curtain wall */}
              <HesiVisor
                variant={completedPush ? "happy" : "default"}
                lookX={isForward ? 11 : -11}
                lookY={completedPush ? -2 : 1}
                transform={
                  isForward
                    ? "translate(10, -16) scale(0.84)"
                    : "translate(-10, -16) scale(0.84)"
                }
              />

              {/* Upper Pushing Arm & Glossy Spherical Hand planted on the curtain edge */}
              <g
                ref={upperArmRef}
                style={{ transformBox: "fill-box", transformOrigin: "center" }}
              >
                {isForward ? (
                  <g transform="translate(-38, -22)">
                    <path
                      d="M -22 8 C -8 0 8 -4 20 0 C 26 4 22 16 8 16 C -6 16 -18 14 -22 8 Z"
                      fill="#16A34A"
                    />
                    <HesiHand cx={18} cy={6} r={16} />
                  </g>
                ) : (
                  <g transform="translate(38, -22)">
                    <path
                      d="M 22 8 C 8 0 -8 -4 -20 0 C -26 4 -22 16 -8 16 C 6 16 18 14 22 8 Z"
                      fill="#16A34A"
                    />
                    <HesiHand cx={-18} cy={6} r={16} />
                  </g>
                )}
              </g>

              {/* Lower Pushing Arm & Glossy Spherical Hand planted on the curtain edge */}
              <g
                ref={lowerArmRef}
                style={{ transformBox: "fill-box", transformOrigin: "center" }}
              >
                {isForward ? (
                  <g transform="translate(-34, 18)">
                    <path
                      d="M -26 6 C -10 -2 8 -4 22 2 C 28 8 22 20 6 18 C -8 18 -20 12 -26 6 Z"
                      fill="#22C55E"
                    />
                    <HesiHand cx={18} cy={8} r={17} />
                  </g>
                ) : (
                  <g transform="translate(34, 18)">
                    <path
                      d="M 26 6 C 10 -2 -8 -4 -22 2 C -28 8 -22 20 -6 18 C 8 18 20 12 26 6 Z"
                      fill="#22C55E"
                    />
                    <HesiHand cx={-18} cy={8} r={17} />
                  </g>
                )}
              </g>
            </g>
          </g>
        </svg>
      </div>
    </div>
  );
}
