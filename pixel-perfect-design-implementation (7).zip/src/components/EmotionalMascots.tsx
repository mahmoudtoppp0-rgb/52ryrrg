import {
  DEFAULT_LAYERS,
  HesiBody,
  HesiHand,
  HesiVisor,
} from "./HesiCoreParts";
import type { MascotArtworkProps } from "./SubscriptionMascots";

/* ============================================================================
   5. FOCUSED MASCOT (مركز — وقت الدرس / Lesson Time — Full Eye Scan & Page-Turning Arms)
   ============================================================================ */
export function FocusedMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 370"
      className={`mascot-focused h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Focused emotional state mascot wearing headphones and reading an open book surrounded by a study lamp, laptop, clock, and stacked books"
    >
      {/* Soft desk surface shadow (scales inversely with breathing height) */}
      <g transform="translate(200, 318)">
        <g data-rig="ground-shadow" data-origin="center">
          <ellipse cx="0" cy="0" rx="164" ry="24" fill="#D8ECF8" opacity="0.7" />
        </g>
      </g>

      {/* Layer 1: Study Desk Environment (Lamp, Laptop, Stacked Books) */}
      {vis.pedestal && (
        <g>
          {/* Teal Desk Lamp on Left */}
          <g transform="translate(64, 188)">
            {/* Warm lamp light beam (60fps breathing illumination) */}
            <g data-rig="lamp-beam" data-origin="top left">
              <polygon
                points="34,12 104,56 36,92"
                fill="#D9F99D"
                opacity="0.54"
              />
            </g>
            {/* Curved gooseneck arm */}
            <path
              d="M 10 86 C -4 52 6 18 26 8"
              stroke="#60A5FA"
              strokeWidth="5"
              fill="none"
              strokeLinecap="round"
            />
            {/* Teal lamp shade */}
            <path
              d="M 18 -2 C 30 -8 44 0 46 14 L 22 24 C 14 14 12 4 18 -2 Z"
              fill="#10B981"
            />
            <ellipse cx="34" cy="19" rx="13" ry="5" transform="rotate(-24 34 19)" fill="#FEF08A" />
          </g>

          {/* Stacked Books on Bottom-Right (Yellow bottom book, Blue top book) */}
          <g transform="translate(306, 286)">
            <path d="M -42 2 L 18 -10 L 48 6 L -12 20 Z" fill="#F59E0B" />
            <path d="M -42 2 L -12 20 L -12 34 L -42 16 Z" fill="#D97706" />
            <path
              d="M -12 20 L 48 6 L 48 18 L -12 32 Z"
              fill="#FEF3C7"
              stroke="#D97706"
              strokeWidth="2"
            />
            <g transform="translate(2, -16)">
              <path d="M -38 0 L 16 -10 L 44 4 L -10 16 Z" fill="#3B82F6" />
              <path d="M -38 0 L -10 16 L -10 28 L -38 12 Z" fill="#1D4ED8" />
              <path
                d="M -10 16 L 44 4 L 44 15 L -10 27 Z"
                fill="#F8FAFC"
                stroke="#2563EB"
                strokeWidth="2"
              />
            </g>
          </g>
        </g>
      )}

      {/* Layer 2: Floating Wall Clock, Chat Note & Checklist UI */}
      {vis.particles && (
        <g>
          {/* Top-Left Green Note Bubble */}
          <g transform="translate(106, 122) rotate(-10)">
            <g data-rig="particle" data-origin="center">
              <rect x="-26" y="-22" width="52" height="42" rx="10" fill="#34D399" />
              <line x1="-14" y1="-8" x2="14" y2="-8" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
              <line x1="-14" y1="1" x2="14" y2="1" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
              <line x1="-14" y1="10" x2="4" y2="10" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" />
            </g>
          </g>

          {/* Top-Right Teal Wall Clock with 60fps sweeping minute hand */}
          <g transform="translate(298, 110)">
            <g data-rig="particle" data-origin="center">
              <circle cx="0" cy="0" r="29" fill="#10B981" />
              <circle cx="0" cy="0" r="23" fill="#059669" />
              {/* Hour hand */}
              <line x1="0" y1="2" x2="11" y2="6" stroke="#FFFFFF" strokeWidth="4" strokeLinecap="round" />
              {/* Sweeping minute hand */}
              <g data-rig="wall-clock-hand" data-origin="center">
                <line x1="0" y1="2" x2="0" y2="-13" stroke="#FFFFFF" strokeWidth="3.8" strokeLinecap="round" />
              </g>
              <circle cx="0" cy="2" r="2.5" fill="#FFFFFF" />
            </g>
          </g>

          {/* Right Floating Checklist Card */}
          <g transform="translate(306, 198) rotate(10)">
            <g data-rig="particle" data-origin="center">
              <rect x="-30" y="-28" width="60" height="56" rx="9" fill="#DBEAFE" />
              <rect x="-30" y="-28" width="60" height="14" rx="6" fill="#93C5FD" />
              <circle cx="-18" cy="-4" r="3" fill="#60A5FA" />
              <line x1="-9" y1="-4" x2="18" y2="-4" stroke="#93C5FD" strokeWidth="3.5" strokeLinecap="round" />
              <circle cx="-18" cy="8" r="3" fill="#60A5FA" />
              <line x1="-9" y1="8" x2="18" y2="8" stroke="#93C5FD" strokeWidth="3.5" strokeLinecap="round" />
              <circle cx="-18" cy="20" r="3" fill="#60A5FA" />
              <line x1="-9" y1="20" x2="12" y2="20" stroke="#93C5FD" strokeWidth="3.5" strokeLinecap="round" />
            </g>
          </g>
        </g>
      )}

      {/* Layer 3, 4, 5: Mascot Body, Headphones, Full-Range Reading Visor & Open Book */}
      <g data-rig="main-float" data-origin="center bottom">
        {vis.props && (
          /* Over-ear Headphones Headband (behind top peak) */
          <g transform="translate(194, 178)">
            <path
              d="M -78 4 C -82 -68 -36 -102 4 -102 C 44 -102 82 -66 78 4"
              stroke="#1E3A8A"
              strokeWidth="12"
              fill="none"
              strokeLinecap="round"
            />
            <path
              d="M -74 -2 C -78 -64 -34 -94 4 -94 C 42 -94 76 -62 74 -2"
              stroke="#3B82F6"
              strokeWidth="5"
              fill="none"
              strokeLinecap="round"
            />
          </g>
        )}

        {vis.body && (
          <HesiBody angle="right" showTipGem={false} transform="translate(194, 186) scale(0.98)" />
        )}

        {vis.face && (
          <HesiVisor
            variant="default"
            lookX={0}
            lookY={3}
            transform="translate(202, 166) scale(0.98)"
          />
        )}

        {vis.props && (
          <g>
            {/* Left & Right Headphone Ear Cups with subtle sound-wave pulse */}
            <g transform="translate(194, 178)">
              <g data-rig="headphone-cup" data-origin="center">
                <ellipse cx="-78" cy="4" rx="15" ry="26" fill="#172554" />
                <ellipse cx="-73" cy="4" rx="12" ry="22" fill="#2563EB" />
                <ellipse cx="-70" cy="4" rx="7" ry="15" fill="#1E3A8A" />
                <ellipse cx="76" cy="2" rx="11" ry="23" fill="#1D4ED8" />
                <ellipse cx="79" cy="2" rx="7" ry="16" fill="#172554" />
              </g>
            </g>

            {/* Open Blue Textbook + Flipping Page + Articulated Left & Right Hands */}
            <g transform="translate(204, 248)">
              <g data-rig="focused-book" data-origin="center">
                <g data-rig="book-pages" data-origin="center bottom">
                  <path
                    d="M -66 -32 Q -32 -22 0 -10 Q 32 -24 66 -34 L 60 22 Q 30 12 0 26 Q -30 12 -60 22 Z"
                    fill="#F8FAFC"
                    stroke="#CBD5E1"
                    strokeWidth="1.5"
                  />
                </g>
                {/* Animated turning page leaf */}
                <g data-rig="flipping-page" data-origin="bottom left">
                  <path
                    d="M 0 -9 Q 30 -24 62 -32 L 56 14 Q 28 8 0 22 Z"
                    fill="#FFFFFF"
                    stroke="#94A3B8"
                    strokeWidth="1.2"
                  />
                </g>
                {/* Left blue cover */}
                <path d="M -70 -26 L -8 -8 L -8 46 L -62 28 Z" fill="#1E3A8A" />
                {/* Right blue cover */}
                <path d="M 70 -28 L 8 -8 L 8 46 L 62 26 Z" fill="#1D4ED8" />
                {/* Center spine */}
                <rect x="-9" y="-9" width="18" height="56" rx="3" fill="#2563EB" />

                {/* Left Articulated Hand steadying the left cover */}
                <g transform="translate(-58, 8)">
                  <g data-rig="arm-left" data-origin="center">
                    <HesiHand cx={0} cy={0} r={19} />
                  </g>
                </g>

                {/* Right Articulated Hand lifting & tracing/turning the right page */}
                <g transform="translate(62, 6)">
                  <g data-rig="arm-right" data-origin="center">
                    <HesiHand cx={0} cy={0} r={18} />
                  </g>
                </g>
              </g>
            </g>
          </g>
        )}
      </g>

      {/* Foreground Left: Sleek Dark-Navy Laptop resting on desk */}
      {vis.pedestal && (
        <g transform="translate(96, 272)">
          <path d="M -36 30 L 66 20 L 82 26 L -24 38 Z" fill="#334155" />
          <path
            d="M -52 -32 L 32 -32 L 46 32 L -38 32 Z"
            fill="#1E293B"
            stroke="#475569"
            strokeWidth="2"
            strokeLinejoin="round"
          />
          <g transform="translate(-3, 0) rotate(45)">
            <rect x="-6.5" y="-6.5" width="13" height="13" rx="2" fill="#93C5FD" />
            <rect x="-2.5" y="-2.5" width="5" height="5" rx="1" fill="#1E293B" />
          </g>
        </g>
      )}
    </svg>
  );
}

/* ============================================================================
   6. HAPPY MASCOT (فرحان — إجابة صح / Correct Answer — Anime Victory Leap & Both Arms Cheering)
   ============================================================================ */
export function HappyMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 370"
      className={`mascot-happy h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Happy emotional state mascot celebrating a correct answer with happy curved eyes, a green checkmark badge, and confetti"
    >
      {/* Layer 2: Celebratory Stars, Confetti & Anime Action Swooshes */}
      {vis.particles && (
        <g>
          {/* Left green celebratory motion arcs */}
          <g transform="translate(76, 224)">
            <g data-rig="wind-arc-l" data-origin="center">
              <path
                d="M -2 -36 C -20 -14 -12 24 16 38 C -2 18 -6 -12 8 -32 Z"
                fill="#34D399"
              />
            </g>
          </g>
          <g transform="translate(62, 232)">
            <g data-rig="wind-arc-l" data-origin="center">
              <path
                d="M -2 -26 C -12 -10 -8 12 8 24 C -2 8 -4 -10 4 -22 Z"
                fill="#A7F3D0"
              />
            </g>
          </g>
          {/* Right green leaf swoosh */}
          <g transform="translate(320, 256)">
            <g data-rig="wind-arc-r" data-origin="center">
              <path
                d="M -2 -28 C 14 -18 12 12 -10 26 C 0 8 0 -12 -8 -22 Z"
                fill="#4ADE80"
              />
            </g>
          </g>
          {/* Gold 5-point star on left */}
          <g transform="translate(84, 152)">
            <g data-rig="particle" data-origin="center">
              <polygon
                points="0,-16 5,-5 17,-3 8,5 10,17 0,11 -10,17 -8,5 -17,-3 -5,-5"
                fill="#FACC15"
              />
            </g>
          </g>
          {/* Top-center gold 4-point sparkle */}
          <g transform="translate(186, 77)">
            <g data-rig="particle" data-origin="center">
              <polygon
                points="0,-15 4,-4 15,0 4,4 0,15 -4,4 -15,0 -4,-4"
                fill="#FACC15"
              />
            </g>
          </g>
          {/* Right gold diamond */}
          <g transform="translate(316, 187)">
            <g data-rig="particle" data-origin="center">
              <polygon points="0,-9 9,0 0,9 -9,0" fill="#FBBF24" />
            </g>
          </g>
          {/* Bottom-left gold sparkle */}
          <g transform="translate(104, 304)">
            <g data-rig="particle" data-origin="center">
              <polygon points="0,-8 8,0 0,8 -8,0" fill="#FACC15" />
            </g>
          </g>
          {/* Blue & teal confetti ribbons */}
          <g transform="translate(123, 92)">
            <g data-rig="particle" data-origin="center">
              <path d="M -11 -4 L 5 -12 L 11 4 L -1 12 Z" fill="#38BDF8" />
            </g>
          </g>
          <g transform="translate(222, 96) rotate(24)">
            <g data-rig="particle" data-origin="center">
              <ellipse cx="0" cy="0" rx="5" ry="11" fill="#06B6D4" />
            </g>
          </g>
        </g>
      )}

      {/* Glossy 3D Green Checkmark Badge (Top-Right, independently bobbing & popping) */}
      {vis.props && (
        <g transform="translate(296, 116)">
          <g data-rig="check-badge" data-origin="center">
            <circle cx="0" cy="0" r="34" fill="#22C55E" />
            <circle cx="-4" cy="-4" r="29" fill="#4ADE80" opacity="0.35" />
            <polyline
              points="-14,1 -4,12 16,-10"
              stroke="#FFFFFF"
              strokeWidth="7.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
          </g>
        </g>
      )}

      {/* Layer 3 & 4: Joyfully Bouncing Mascot Body, Squinting Happy Eyes & Both Articulated Cheering Arms */}
      <g transform="translate(172, 192) rotate(-8)">
        <g data-rig="main-float" data-origin="center">
          {vis.body && <HesiBody angle="right" showTipGem />}
          {vis.face && <HesiVisor variant="happy" transform="translate(10, -20)" />}

          {vis.props && (
            <g>
              {/* Left Arm (viewer's left) pumping & swinging in joyful rhythm */}
              <g transform="translate(-56, 38)">
                <g data-rig="arm-left" data-origin="top right">
                  <path
                    d="M 16 -14 C 4 -4 -8 4 -12 12 C -14 20 2 22 14 10 Z"
                    fill="#16A34A"
                  />
                  <HesiHand cx={0} cy={0} r={21} />
                </g>
              </g>

              {/* Right Arm (viewer's right) raised high in sweeping anime celebration arc */}
              <g transform="translate(72, -16)">
                <g data-rig="wave-hand" data-origin="bottom left">
                  <path
                    d="M -18 22 C -6 6 8 -14 22 -18 C 34 -20 38 -2 24 14 C 12 28 -4 36 -18 22 Z"
                    fill="#22C55E"
                  />
                  <HesiHand cx={18} cy={-8} r={19} />
                </g>
              </g>
            </g>
          )}
        </g>
      </g>

      {/* Layer 1: Foreground Quiz UI Card with Green Correct Answer Row */}
      {vis.pedestal && (
        <g transform="translate(248, 256) rotate(-7)">
          <g data-rig="quiz-card" data-origin="center">
            <rect x="-66" y="-44" width="136" height="94" rx="12" fill="#BAE6FD" opacity="0.45" />
            <rect
              x="-70"
              y="-48"
              width="136"
              height="94"
              rx="12"
              fill="#FFFFFF"
              stroke="#E2E8F0"
              strokeWidth="2"
            />
            <rect x="-70" y="-48" width="136" height="16" rx="8" fill="#DBEAFE" />
            {/* Option 1: Highlighted Green Correct Answer */}
            <circle cx="-48" cy="-14" r="6" fill="#22C55E" />
            <rect x="-34" y="-20" width="76" height="12" rx="6" fill="#22C55E" />
            <circle cx="44" cy="-14" r="7" fill="#16A34A" />
            <polyline
              points="40,-14 43,-11 49,-17"
              stroke="#FFFFFF"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
            {/* Option 2 */}
            <circle cx="-48" cy="6" r="6" fill="#93C5FD" />
            <rect x="-34" y="0" width="64" height="10" rx="5" fill="#DBEAFE" />
            {/* Option 3 */}
            <circle cx="-48" cy="24" r="6" fill="#93C5FD" />
            <rect x="-34" y="18" width="52" height="10" rx="5" fill="#DBEAFE" />
          </g>
        </g>
      )}
    </svg>
  );
}

/* ============================================================================
   7. PROUD MASCOT (فخور — إنهاء وعاء / نتيجة — Billowing Cape + Grand Trophy Hoist)
   ============================================================================ */
export function ProudMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 370"
      className={`mascot-proud h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Proud emotional state mascot wearing a navy cape on a star pedestal and holding a golden trophy"
    >
      {/* Layer 2: Rising Golden Anime Action Arrows & Achievement Sparkles */}
      {vis.particles && (
        <g>
          {/* Bottom-left upward golden arrow */}
          <g transform="translate(88, 258)">
            <g data-rig="rising-arrow" data-origin="center">
              <path
                d="M 0 -38 L 24 -12 L 10 -12 L 16 36 L -6 36 L -10 -12 L -24 -12 Z"
                fill="#FDE047"
                opacity="0.8"
              />
            </g>
          </g>
          {/* Bottom-right upward golden arrow */}
          <g transform="translate(322, 280)">
            <g data-rig="rising-arrow" data-origin="center">
              <path
                d="M 4 -36 L 22 -8 L 10 -8 L -2 36 L -24 30 L -10 -12 L -22 -16 Z"
                fill="#FACC15"
                opacity="0.86"
              />
            </g>
          </g>
          {/* 4-point golden stars */}
          <g transform="translate(104, 152)">
            <g data-rig="particle" data-origin="center">
              <polygon points="0,-20 6,-6 20,0 6,6 0,20 -6,6 -20,0 -6,-6" fill="#FACC15" />
            </g>
          </g>
          <g transform="translate(282, 96)">
            <g data-rig="particle" data-origin="center">
              <polygon points="0,-22 6,-6 22,0 6,6 0,22 -6,6 -22,0 -6,-6" fill="#FACC15" />
            </g>
          </g>
          <g transform="translate(348, 135)">
            <g data-rig="particle" data-origin="center">
              <polygon points="0,-17 5,-5 17,0 5,5 0,17 -5,5 -17,0 -5,-5" fill="#FACC15" />
            </g>
          </g>
          <g transform="translate(338, 210)">
            <g data-rig="particle" data-origin="center">
              <polygon points="0,-14 4,-4 14,0 4,4 0,14 -4,4 -14,0 -4,-4" fill="#FBBF24" />
            </g>
          </g>
        </g>
      )}

      {/* Layer 1: Tiered Emerald Achievement Pedestal with Golden Star */}
      {vis.pedestal && (
        <g transform="translate(216, 310)">
          <ellipse cx="0" cy="20" rx="118" ry="18" fill="#BAE6FD" opacity="0.55" />
          <path d="M -78 2 L -50 -6 L -44 22 L -84 22 Z" fill="#15803D" />
          <path d="M 78 2 L 50 -6 L 44 22 L 84 22 Z" fill="#0F766E" />
          <path d="M -52 -16 L 52 -16 L 62 24 L -62 24 Z" fill="#16A34A" />
          <polygon points="-46,-26 46,-26 52,-16 -52,-16" fill="#4ADE80" />
          <polygon
            points="0,-12 5,-1 17,1 8,9 10,21 0,15 -10,21 -8,9 -17,1 -5,-1"
            fill="#FACC15"
          />
        </g>
      )}

      {/* Layer 3, 4, 5: Heroic Mascot, Billowing Navy Cape & Grand Golden Trophy Hoist */}
      <g data-rig="main-float" data-origin="center">
        {/* Flowing Dark-Navy Hero Cape (behind body, lush 60fps wind waves) */}
        {vis.props && (
          <g transform="translate(182, 206)">
            <g data-rig="cape" data-origin="top right">
              <path
                d="M -24 -12 C -52 18 -78 48 -108 62 C -82 72 -58 68 -36 80 C -12 68 8 42 18 14 Z"
                fill="#1E3A8A"
              />
              <path
                d="M -18 -8 C -40 22 -60 50 -82 68 C -60 72 -44 74 -30 80 C -8 64 10 38 18 12 Z"
                fill="#172554"
              />
            </g>
          </g>
        )}

        {/* Proud Hesi Body */}
        <g transform="translate(206, 174) rotate(-4)">
          {vis.body && <HesiBody angle="right" showTipGem />}
          {vis.face && <HesiVisor variant="default" lookX={4} lookY={-2} transform="translate(8, -20)" />}

          {vis.props && (
            <g>
              {/* Navy cape collar clasp around neck/chest */}
              <path
                d="M -58 26 Q 6 42 54 22 Q 20 50 -52 44 Z"
                fill="#2563EB"
              />
              {/* Articulated Left Hero Arm poised proudly on chest/hip */}
              <g transform="translate(-26, 52)">
                <g data-rig="arm-left" data-origin="top left">
                  <path
                    d="M -28 -16 C -16 -12 -4 -6 2 0 C 6 8 -6 14 -22 6 Z"
                    fill="#16A34A"
                  />
                  <HesiHand cx={0} cy={0} r={20} />
                </g>
              </g>
            </g>
          )}
        </g>

        {/* Gleaming Golden Trophy & Right Arm held aloft (grand sweeping 60fps hoist + rotating star gleam) */}
        {vis.props && (
          <g transform="translate(298, 174) rotate(6)">
            <g data-rig="trophy" data-origin="bottom left">
              {/* Green Arm Bridge connecting body to trophy */}
              <path
                d="M -38 28 C -20 26 -2 24 14 22 C 20 28 8 38 -16 36 Z"
                fill="#16A34A"
              />
              {/* Trophy Handles */}
              <path
                d="M -28 -26 C -48 -26 -46 6 -22 10 M 28 -26 C 48 -26 46 6 22 10"
                stroke="#F59E0B"
                strokeWidth="6"
                fill="none"
                strokeLinecap="round"
              />
              {/* Trophy Cup Body */}
              <path
                d="M -32 -36 H 32 L 26 4 C 24 22 12 32 0 32 C -12 32 -24 22 -26 4 Z"
                fill="#FACC15"
              />
              {/* Trophy stem & base */}
              <rect x="-6" y="30" width="12" height="16" fill="#D97706" />
              <rect x="-22" y="44" width="44" height="12" rx="3" fill="#1E293B" />
              <rect x="-26" y="54" width="52" height="6" rx="2" fill="#FACC15" />
              {/* Star on trophy cup */}
              <polygon
                points="0,-22 4,-12 15,-11 7,-4 9,7 0,1 -9,7 -7,-4 -15,-11 -4,-12"
                fill="#FEF9C3"
              />
              {/* Rotating anime star-gleam on upper rim of trophy */}
              <g transform="translate(-16, -32)">
                <g data-rig="trophy-gleam" data-origin="center">
                  <polygon
                    points="0,-11 2.5,-2.5 11,0 2.5,2.5 0,11 -2.5,2.5 -11,0 -2.5,-2.5"
                    fill="#FFFFFF"
                  />
                </g>
              </g>
              {/* Mascot's right green hand gripping trophy */}
              <HesiHand cx={18} cy={22} r={18} />
            </g>
          </g>
        )}
      </g>
    </svg>
  );
}

/* ============================================================================
   8. SLEEPY MASCOT (نايم — كسر السلسلة / Serene Slumber, Curling Hands & Rising Zs)
   ============================================================================ */
export function SleepyMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 370"
      className={`mascot-sleepy h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Sleepy emotional state mascot resting peacefully on a blue pillow under a blanket with a crescent moon and floating Z symbols"
    >
      {/* Soft dreamy background aura & floor shadow */}
      <ellipse cx="196" cy="240" rx="148" ry="88" fill="#DBEAFE" opacity="0.45" />
      <ellipse cx="200" cy="316" rx="156" ry="22" fill="#BFDBFE" opacity="0.6" />

      {/* Layer 1: Plush Periwinkle Pillow (compresses gently in sync with breathing) */}
      {vis.pedestal && (
        <g transform="translate(108, 250) rotate(-14)">
          <g data-rig="pillow" data-origin="center">
            <path
              d="M -64 -42 C -32 -54 32 -54 64 -42 C 74 -12 74 24 64 46 C 28 56 -28 56 -64 46 C -76 20 -76 -12 -64 -42 Z"
              fill="#60A5FA"
            />
            <path
              d="M -56 -36 C -26 -46 26 -46 56 -36 C 64 -10 64 20 54 38 C 22 46 -22 46 -56 38 C -66 16 -66 -10 -56 -36 Z"
              fill="#93C5FD"
            />
          </g>
        </g>
      )}

      {/* Layer 3, 4: Reclining Mascot Body, Peaceful Sleeping Eye, Blanket & Articulated Tucked Hands */}
      <g data-rig="main-float" data-origin="center">
        <g transform="translate(174, 212) rotate(-28) scale(0.95)">
          {vis.body && <HesiBody angle="front" showTipGem={false} />}
          {vis.face && <HesiVisor variant="sleepy" transform="translate(4, -14)" />}
        </g>

        {/* Cozy Navy Blanket draped over right side (rises and falls smoothly with chest breath) */}
        {vis.pedestal && (
          <g data-rig="blanket" data-origin="bottom center">
            <path
              d="M 216 196 C 258 188 304 218 326 276 L 236 300 C 216 264 204 226 216 196 Z"
              fill="#1E3A8A"
            />
          </g>
        )}

        {/* Two Independently Articulated Green Hands tucked cozily on the pillow */}
        {vis.props && (
          <g>
            <g transform="translate(162, 278)">
              <g data-rig="arm-left" data-origin="center">
                <HesiHand cx={0} cy={0} r={20} />
              </g>
            </g>
            <g transform="translate(204, 266)">
              <g data-rig="arm-right" data-origin="center">
                <HesiHand cx={0} cy={0} r={24} />
              </g>
            </g>
          </g>
        )}
      </g>

      {/* Resting Smartphone in foreground bottom-right */}
      {vis.pedestal && (
        <g transform="translate(262, 318) rotate(-20)">
          <rect x="-26" y="-12" width="52" height="26" rx="5" fill="#1E3A8A" />
          <rect x="-21" y="-9" width="42" height="20" rx="3" fill="#3B82F6" />
          <circle cx="17" cy="1" r="1.8" fill="#93C5FD" />
        </g>
      )}

      {/* Layer 2: Crescent Moon Badge & Continuous 60fps Drifting Z Particles */}
      {vis.particles && (
        <g>
          {/* Top-Left Moon Badge (gentle cradle rock) */}
          <g transform="translate(88, 134)">
            <g data-rig="moon-badge" data-origin="center">
              <circle cx="0" cy="0" r="24" fill="#1D4ED8" />
              <path
                d="M 4 -11 C -4 -10 -9 -3 -8 5 C -7 12 0 17 8 15 C 2 19 -7 16 -11 10 C -15 3 -12 -6 -5 -10 C -2 -12 1 -12 4 -11 Z"
                fill="#FFFFFF"
              />
              <circle cx="7" cy="-3" r="2.2" fill="#FFFFFF" />
            </g>
          </g>

          {/* Soft dreamy rounded square */}
          <g transform="translate(287, 171)">
            <g data-rig="particle" data-origin="center">
              <rect x="-19" y="-19" width="38" height="38" rx="10" fill="#DBEAFE" opacity="0.8" />
            </g>
          </g>

          {/* Floating Z 1 (continuous 60fps rising stream) */}
          <g transform="translate(226, 146) rotate(-8)">
            <g data-rig="z-particle" data-origin="center">
              <path
                d="M -10 -12 H 10 L -10 12 H 10"
                stroke="#2563EB"
                strokeWidth="6"
                strokeLinecap="round"
                strokeLinejoin="round"
                fill="none"
              />
            </g>
          </g>

          {/* Floating Z 2 (continuous 60fps rising stream, phase-shifted) */}
          <g transform="translate(248, 114) rotate(6)">
            <g data-rig="z-particle" data-origin="center">
              <path
                d="M -12 -14 H 12 L -12 14 H 12"
                stroke="#1D4ED8"
                strokeWidth="6.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                fill="none"
              />
            </g>
          </g>
        </g>
      )}
    </svg>
  );
}

/* ============================================================================
   9. ANXIOUS MASCOT (قلقان — قرب الامتحان / Expressive Arms + Eye Dart -> Serene Calm Aura)
   ============================================================================ */
export function AnxiousMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 370"
      className={`mascot-anxious h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Anxious emotional state mascot with an EXAM paper, pencil, and alarm clock, supported by a soothing mint calming aura"
    >
      {/* Layer 1: Calming Visual Cue (Soothing mint-emerald reassurance ring behind mascot) */}
      {vis.pedestal && (
        <g transform="translate(196, 192)">
          <g data-rig="calm-aura" data-origin="center">
            <circle cx="0" cy="0" r="128" fill="#BBF7D0" opacity="0.45" />
            <circle
              cx="0"
              cy="0"
              r="108"
              fill="none"
              stroke="#34D399"
              strokeWidth="2.5"
              strokeDasharray="8 8"
              opacity="0.7"
            />
          </g>
        </g>
      )}

      {/* Soft floor shadow */}
      <ellipse cx="200" cy="318" rx="154" ry="20" fill="#DBEAFE" opacity="0.65" />

      {/* Layer 2: Alert Exclamation Ticks & Droplets */}
      {vis.particles && (
        <g>
          <g transform="translate(96, 128)">
            <g data-rig="particle" data-origin="center">
              <path d="M 0 -6 C -6 0 -2 8 6 4 Z" fill="#60A5FA" />
            </g>
          </g>
          <g transform="translate(78, 154)">
            <g data-rig="particle" data-origin="center">
              <path d="M 0 -6 C -6 0 -2 8 6 4 Z" fill="#93C5FD" />
            </g>
          </g>
          {/* Top-right exclamation marks (! !) */}
          <g transform="translate(258, 96) rotate(12)">
            <g data-rig="particle" data-origin="center" fill="#2563EB">
              <rect x="-4" y="-22" width="8" height="28" rx="4" />
              <circle cx="0" cy="14" r="4.2" />
            </g>
          </g>
          <g transform="translate(282, 108) rotate(24)">
            <g data-rig="particle" data-origin="center" fill="#3B82F6">
              <rect x="-4" y="-20" width="8" height="26" rx="4" />
              <circle cx="0" cy="14" r="4.2" />
            </g>
          </g>
        </g>
      )}

      {/* Layer 3, 4: Mascot Body, Articulated Brows/Eye & Full-Range Expressive Hands */}
      <g transform="translate(194, 188) rotate(-5)">
        <g data-rig="main-float" data-origin="center">
          {vis.body && <HesiBody angle="right" showTipGem />}
          {vis.face && <HesiVisor variant="anxious" lookX={0} lookY={-1} transform="translate(6, -18)" />}
          {vis.props && (
            <g>
              {/* Left Articulated Hand (rises toward cheek in worry, lowers smoothly in calm breath) */}
              <g transform="translate(-60, 26)">
                <g data-rig="arm-left" data-origin="center">
                  <HesiHand cx={0} cy={0} r={19} />
                </g>
              </g>
              {/* Right Articulated Hand (rises toward temple in worry, lowers smoothly in calm breath) */}
              <g transform="translate(66, 18)">
                <g data-rig="arm-right" data-origin="center">
                  <HesiHand cx={0} cy={0} r={19} />
                </g>
              </g>
            </g>
          )}
        </g>
      </g>

      {/* Layer 5: Foreground Props — EXAM Sheet, Yellow Pencil & Twin-Bell Alarm Clock */}
      {vis.props && (
        <g>
          {/* Tilted White EXAM Paper (Bottom-Left) */}
          <g transform="translate(132, 276) rotate(-12)">
            <g data-rig="exam-sheet" data-origin="center">
              <rect
                x="-44"
                y="-48"
                width="88"
                height="96"
                rx="8"
                fill="#FFFFFF"
                stroke="#BFDBFE"
                strokeWidth="2.5"
              />
              <text
                x="0"
                y="-18"
                textAnchor="middle"
                fill="#60A5FA"
                fontSize="19"
                fontWeight="800"
                fontFamily="Plus Jakarta Sans, Inter, sans-serif"
                letterSpacing="0.5"
              >
                EXAM
              </text>
              <line x1="-28" y1="-2" x2="28" y2="-2" stroke="#CBD5E1" strokeWidth="4" strokeLinecap="round" />
              <line x1="-28" y1="12" x2="28" y2="12" stroke="#CBD5E1" strokeWidth="4" strokeLinecap="round" />
              <line x1="-28" y1="26" x2="16" y2="26" stroke="#CBD5E1" strokeWidth="4" strokeLinecap="round" />
            </g>
          </g>

          {/* Yellow Pencil with Pink Eraser (Bottom-Center) */}
          <g transform="translate(236, 294) rotate(38)">
            <g data-rig="pencil" data-origin="center">
              <rect x="-6" y="-36" width="12" height="10" rx="3" fill="#F472B6" />
              <rect x="-6" y="-27" width="12" height="5" fill="#CBD5E1" />
              <rect x="-6" y="-22" width="12" height="42" fill="#FACC15" />
              <polygon points="-6,20 6,20 0,34" fill="#FDE68A" />
              <polygon points="-2.5,28 2.5,28 0,34" fill="#0F172A" />
            </g>
          </g>

          {/* Blue Twin-Bell Alarm Clock (Right, with 60fps ringing vibration & sweeping hand) */}
          <g transform="translate(300, 232) rotate(-10)">
            <g data-rig="alarm-clock" data-origin="center">
              {/* Clock feet */}
              <line x1="-20" y1="34" x2="-28" y2="46" stroke="#1E3A8A" strokeWidth="5" strokeLinecap="round" />
              <line x1="20" y1="34" x2="28" y2="46" stroke="#1E3A8A" strokeWidth="5" strokeLinecap="round" />
              {/* Top Twin Bells & Hammer */}
              <path d="M -36 -30 C -44 -46 -20 -58 -8 -42 Z" fill="#3B82F6" />
              <path d="M 36 -30 C 44 -46 20 -58 8 -42 Z" fill="#3B82F6" />
              <line x1="0" y1="-38" x2="0" y2="-50" stroke="#1E3A8A" strokeWidth="4" strokeLinecap="round" />
              {/* Clock outer casing */}
              <circle cx="0" cy="0" r="40" fill="#2563EB" />
              <circle cx="-3" cy="0" r="36" fill="#60A5FA" />
              {/* White clock dial */}
              <circle cx="-3" cy="0" r="29" fill="#FFFFFF" />
              {/* Clock hour hand */}
              <line x1="-3" y1="0" x2="-12" y2="-14" stroke="#1E3A8A" strokeWidth="3.8" strokeLinecap="round" />
              {/* 60fps sweeping minute hand */}
              <g transform="translate(-3, 0)">
                <g data-rig="clock-minute-hand" data-origin="center">
                  <line x1="0" y1="0" x2="16" y2="-4" stroke="#1E3A8A" strokeWidth="3.5" strokeLinecap="round" />
                </g>
              </g>
              <circle cx="-3" cy="0" r="3.5" fill="#1E3A8A" />
            </g>
          </g>
        </g>
      )}
    </svg>
  );
}

/* ============================================================================
   10. WELCOME BACK MASCOT (مستنيك — غياب ورجوع / Sweeping Anime Wave & Sunlit Doorway)
   ============================================================================ */
export function WelcomeBackMascot({ layers = DEFAULT_LAYERS, className = "" }: MascotArtworkProps) {
  const vis = { ...DEFAULT_LAYERS, ...layers };

  return (
    <svg
      viewBox="0 0 400 370"
      className={`mascot-welcome-back h-full w-full select-none ${className}`}
      role="img"
      aria-label="Hesi Welcome Back emotional state mascot waving beside a sunlit open doorway, potted plant, and heart notification bubble"
    >
      {/* Layer 1: Sunlit Open Doorway Portal & Potted Plant */}
      {vis.pedestal && (
        <g>
          {/* Soft floor base hills */}
          <path
            d="M 74 316 C 90 286 154 282 190 316 Z"
            fill="#86EFAC"
            opacity="0.55"
          />
          <path
            d="M 190 316 C 212 272 288 268 314 316 Z"
            fill="#86EFAC"
            opacity="0.7"
          />

          {/* 3D Sky-Blue Open Doorframe / Portal on Right */}
          <g transform="translate(306, 206)">
            <rect x="-46" y="-92" width="88" height="196" rx="16" fill="#60A5FA" />
            <rect x="-54" y="-92" width="78" height="196" rx="14" fill="#DBEAFE" />
            {/* Warm sunlit doorway interior (60fps breathing light) */}
            <rect
              data-rig="door-glow"
              x="-44"
              y="-80"
              width="58"
              height="182"
              rx="8"
              fill="#FEF9C3"
            />
            {/* Potted green plant standing at doorway threshold (leaves sway in breeze) */}
            <g transform="translate(18, 76)">
              <g data-rig="plant-leaves" data-origin="bottom center">
                <path d="M 0 0 C -12 -16 -8 -34 2 -40 C 10 -28 8 -12 0 0 Z" fill="#22C55E" />
                <path d="M 2 -4 C 14 -18 22 -14 18 0 C 14 8 6 6 2 -4 Z" fill="#4ADE80" />
                <path d="M -2 -6 C -16 -16 -22 -10 -14 2 C -8 8 -2 4 -2 -6 Z" fill="#16A34A" />
              </g>
              {/* Blue pot */}
              <polygon points="-12,0 12,0 9,22 -9,22" fill="#3B82F6" />
              <rect x="-14" y="-3" width="28" height="5" rx="2" fill="#60A5FA" />
            </g>
          </g>
        </g>
      )}

      {/* Layer 2: Heart Notification Bubble & Greeting Rays */}
      {vis.particles && (
        <g>
          {/* Soft floating message card on top-left */}
          <g transform="translate(141, 115)">
            <g data-rig="particle" data-origin="center">
              <rect x="-27" y="-19" width="54" height="38" rx="10" fill="#DBEAFE" opacity="0.78" />
            </g>
          </g>
          {/* Left green greeting rays */}
          <g transform="translate(88, 148)">
            <g data-rig="particle" data-origin="center">
              <line
                x1="8"
                y1="10"
                x2="-8"
                y2="-10"
                stroke="#34D399"
                strokeWidth="7"
                strokeLinecap="round"
              />
            </g>
          </g>
          <g transform="translate(77, 172)">
            <g data-rig="particle" data-origin="center">
              <line
                x1="11"
                y1="4"
                x2="-11"
                y2="-4"
                stroke="#6EE7B7"
                strokeWidth="7"
                strokeLinecap="round"
              />
            </g>
          </g>

          {/* Pulsing Green Heart Speech Bubble (Top-Right) */}
          <g transform="translate(258, 96)">
            <g data-rig="heart-bubble" data-origin="center">
              <rect x="-28" y="-22" width="56" height="44" rx="12" fill="#22C55E" />
              <polygon points="-10,20 2,20 -8,31" fill="#22C55E" />
              <path
                d="M 0 11 C 0 11 -13 2 -13 -6 C -13 -11 -8 -15 -3 -12 C 0 -10 0 -7 0 -7 C 0 -7 0 -10 3 -12 C 8 -15 13 -11 13 -6 C 13 2 0 11 0 11 Z"
                fill="#FFFFFF"
              />
            </g>
          </g>
        </g>
      )}

      {/* Layer 3, 4, 5: Welcoming Mascot Body, Full-Range Visor & Both Articulated Greeting Arms */}
      <g transform="translate(186, 200) rotate(-7)">
        <g data-rig="main-float" data-origin="center">
          {vis.body && <HesiBody angle="right" showTipGem />}
          {vis.face && <HesiVisor variant="default" lookX={3} lookY={-1} transform="translate(8, -18)" />}

          {vis.props && (
            <g>
              {/* Left Arm (viewer's left) opening warmly in an inviting gesture */}
              <g transform="translate(-60, 38)">
                <g data-rig="arm-left" data-origin="top right">
                  <path
                    d="M 14 -12 C 4 -4 -6 2 -10 10 C -12 18 2 20 12 8 Z"
                    fill="#16A34A"
                  />
                  <HesiHand cx={0} cy={0} r={20} />
                </g>
              </g>

              {/* Right Arm (viewer's right) raised & waving in a wide, sweeping anime greeting arc */}
              <g transform="translate(70, -10)">
                <g data-rig="wave-hand" data-origin="bottom left">
                  <path
                    d="M -16 20 C -4 4 10 -14 24 -18 C 36 -20 40 -2 26 14 C 14 28 -2 34 -16 20 Z"
                    fill="#22C55E"
                  />
                  <HesiHand cx={20} cy={-8} r={19} />
                </g>
              </g>
            </g>
          )}
        </g>
      </g>
    </svg>
  );
}
