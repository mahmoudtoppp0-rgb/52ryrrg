import { useEffect, useRef, useState } from "react";
import { HesiBody, HesiHand, HesiVisor } from "./HesiCoreParts";

export type ThemeMode = "light" | "dark";

export interface HesiThemeCurtainTransitionProps {
  /** Active transition target theme, or null when idle */
  targetTheme: ThemeMode | null;
  /** Whether reduced motion / calm static mode is enabled */
  reducedMotion: boolean;
  /** Called during the wipe when the screen is covered so the real DOM theme updates seamlessly */
  onCommitTheme: (theme: ThemeMode) => void;
  /** Called when the transition completes and the overlay should unmount */
  onComplete: () => void;
}

// Weighted S-curve with subtle physical push effort
function pushProgressCurve(u: number): number {
  const clamped = Math.max(0, Math.min(1, u));
  // Smooth cubic ease-in-out base
  const base =
    clamped < 0.5
      ? 4 * clamped * clamped * clamped
      : 1 - Math.pow(-2 * clamped + 2, 3) / 2;
  // Subtle physical push-stride modulation (zero at 0 and 1)
  const stride = Math.sin(clamped * Math.PI) * Math.sin(clamped * Math.PI * 3) * 0.018;
  return Math.max(0, Math.min(1, base + stride));
}

const NIGHT_STARS = [
  { x: "14%", y: "18%", size: 14, delay: 0 },
  { x: "28%", y: "12%", size: 10, delay: 0.4 },
  { x: "44%", y: "22%", size: 16, delay: 0.8 },
  { x: "62%", y: "15%", size: 12, delay: 1.2 },
  { x: "78%", y: "26%", size: 15, delay: 0.3 },
  { x: "88%", y: "14%", size: 11, delay: 0.9 },
  { x: "22%", y: "68%", size: 12, delay: 0.6 },
  { x: "54%", y: "74%", size: 14, delay: 1.1 },
  { x: "82%", y: "64%", size: 11, delay: 0.2 },
];

export default function HesiThemeCurtainTransition({
  targetTheme,
  reducedMotion,
  onCommitTheme,
  onComplete,
}: HesiThemeCurtainTransitionProps) {
  const curtainRef = useRef<HTMLDivElement>(null);
  const mascotMoverRef = useRef<HTMLDivElement>(null);
  const mascotPoseRef = useRef<SVGGElement>(null);
  const upperArmRef = useRef<SVGGElement>(null);
  const lowerArmRef = useRef<SVGGElement>(null);
  const contactGlowRef = useRef<SVGGElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);

  const [celebrating, setCelebrating] = useState(false);
  const committedRef = useRef(false);
  const completedRef = useRef(false);

  // Store latest callbacks in refs to avoid restarting the rAF loop if parent re-renders
  const commitCbRef = useRef(onCommitTheme);
  const completeCbRef = useRef(onComplete);
  useEffect(() => {
    commitCbRef.current = onCommitTheme;
    completeCbRef.current = onComplete;
  }, [onCommitTheme, onComplete]);

  useEffect(() => {
    if (!targetTheme) return;

    committedRef.current = false;
    completedRef.current = false;
    setCelebrating(false);

    const isToDark = targetTheme === "dark";

    // 1. Reduced-Motion Path: gentle, brief cross-dissolve without full-screen physical push
    if (reducedMotion) {
      commitCbRef.current(targetTheme);
      committedRef.current = true;
      const timer = window.setTimeout(() => {
        if (!completedRef.current) {
          completedRef.current = true;
          completeCbRef.current();
        }
      }, 240);
      return () => window.clearTimeout(timer);
    }

    // 2. Full 60fps Choreographed Curtain Push Sequence (~1180 ms total)
    const TOTAL_DURATION = 1180; // ms
    const startTime = performance.now();
    let rafId: number | null = null;
    let celebTriggered = false;

    const finishSafely = () => {
      if (!committedRef.current) {
        committedRef.current = true;
        commitCbRef.current(targetTheme);
      }
      if (!completedRef.current) {
        completedRef.current = true;
        completeCbRef.current();
      }
    };

    // Failsafe timer in case tab is backgrounded during animation
    const failsafeTimer = window.setTimeout(finishSafely, TOTAL_DURATION + 350);

    const step = (now: number) => {
      const elapsed = now - startTime;
      const tNorm = Math.min(1, Math.max(0, elapsed / TOTAL_DURATION));
      const vw = window.innerWidth;

      // Timeline phases:
      // [0.00 .. 0.16]: Entrance & Preparatory Crouch at starting edge
      // [0.16 .. 0.80]: Physical Contact & Full-Screen Curtain Push across viewport
      // [0.80 .. 1.00]: Celebratory Follow-Through Hop, Curtain Settle & Clean Exit

      let edgeX = 0; // Curtain leading edge X in viewport pixels
      let mascotOffsetX = 0;
      let mascotOffsetY = 0;
      let bodyRotate = 0;
      let scaleX = 1;
      let scaleY = 1;
      let armPushExtend = 0;
      let contactBurst = 0;
      let overlayOpacity = 1;

      if (tNorm < 0.16) {
        // PHASE 1: Entrance & Anticipation Crouch
        const p = tNorm / 0.16; // 0..1
        const easeOut = 1 - Math.pow(1 - p, 3);
        edgeX = isToDark ? easeOut * (vw * 0.04) : vw - easeOut * (vw * 0.04);

        // Hesi bounds in from off-screen edge and crouches in anticipation
        const entrySlide = (1 - easeOut) * (isToDark ? -130 : 130);
        const crouch = Math.sin(p * Math.PI); // peaks mid-entrance
        mascotOffsetX = entrySlide;
        mascotOffsetY = crouch * 12;
        scaleX = 1 + crouch * 0.08;
        scaleY = 1 - crouch * 0.08;
        bodyRotate = (isToDark ? -8 : 8) * crouch + (isToDark ? 10 : -10) * easeOut;
        armPushExtend = easeOut * 10;
        contactBurst = easeOut * 0.7;
      } else if (tNorm < 0.80) {
        // PHASE 2: Contact & Full-Screen Push across the viewport
        const u = (tNorm - 0.16) / 0.64; // 0..1
        const wipe = pushProgressCurve(u);

        const startEdge = isToDark ? vw * 0.04 : vw * 0.96;
        const endEdge = isToDark ? vw * 1.02 : -vw * 0.02;
        edgeX = startEdge + (endEdge - startEdge) * wipe;

        // Commit the underlying application theme once the curtain covers >= 72% of the screen
        if (wipe >= 0.72 && !committedRef.current) {
          committedRef.current = true;
          commitCbRef.current(targetTheme);
        }

        // Physical push effort cadence (3 energetic push strides across the screen)
        const strideWave = Math.sin(u * Math.PI * 3);
        const effortEnvelope = Math.sin(u * Math.PI); // strongest in the middle of the screen

        mascotOffsetY = Math.abs(strideWave) * -14 + effortEnvelope * 6;
        // Lean forward into the curtain wall (+16deg when pushing right, -16deg when pushing left)
        bodyRotate = (isToDark ? 16.5 : -16.5) + strideWave * (isToDark ? 3.5 : -3.5);
        // Subtle muscular effort compression
        scaleX = 1 - effortEnvelope * 0.055 + strideWave * 0.02;
        scaleY = 1 + effortEnvelope * 0.055 - strideWave * 0.02;

        // Arms push and extend rhythmically against the curtain seam
        armPushExtend = 12 + strideWave * 7 + effortEnvelope * 5;
        contactBurst = 0.75 + 0.25 * Math.abs(strideWave);
      } else {
        // PHASE 3: Commit guarantee, Follow-Through Celebration Hop & Clean Exit
        if (!committedRef.current) {
          committedRef.current = true;
          commitCbRef.current(targetTheme);
        }
        if (!celebTriggered) {
          celebTriggered = true;
          setCelebrating(true);
        }

        const f = (tNorm - 0.80) / 0.20; // 0..1
        edgeX = isToDark ? vw * 1.02 : -vw * 0.02;

        // Joyful release hop and glide off the far edge
        const hop = Math.sin(f * Math.PI);
        mascotOffsetX = (isToDark ? 1 : -1) * (f * 135 - 20);
        mascotOffsetY = -hop * 34;
        bodyRotate = (isToDark ? -10 : 10) * hop;
        scaleX = 1 - hop * 0.04;
        scaleY = 1 + hop * 0.06;
        armPushExtend = (1 - f) * 8;
        contactBurst = Math.max(0, 1 - f * 2);

        // Smoothly dissolve the curtain overlay once the real page underneath is already in targetTheme
        overlayOpacity = 1 - Math.pow(f, 1.6);
      }

      // Apply GPU-composited transforms to Curtain, Mascot, Arms & Contact Seam
      if (overlayRef.current) {
        overlayRef.current.style.opacity = overlayOpacity.toFixed(3);
      }

      if (curtainRef.current) {
        // Curtain panel is 108vw wide.
        // For to-dark (left -> right): curtain's right edge sits at `edgeX`
        // For to-light (right -> left): curtain's left edge sits at `edgeX`
        const curtainTranslateX = isToDark ? edgeX - vw * 1.08 : edgeX;
        curtainRef.current.style.transform = `translate3d(${curtainTranslateX.toFixed(1)}px, 0, 0)`;
      }

      if (mascotMoverRef.current) {
        // Position Hesi right behind the leading edge of the curtain so Hesi's hands touch edgeX
        const handContactOffset = isToDark ? -92 : -128;
        const mx = edgeX + handContactOffset + mascotOffsetX;
        mascotMoverRef.current.style.transform = `translate3d(${mx.toFixed(1)}px, ${mascotOffsetY.toFixed(1)}px, 0)`;
      }

      if (mascotPoseRef.current) {
        mascotPoseRef.current.style.transform = `rotate(${bodyRotate.toFixed(2)}deg) scale3d(${scaleX.toFixed(3)}, ${scaleY.toFixed(3)}, 1)`;
      }

      const dirSign = isToDark ? 1 : -1;
      if (upperArmRef.current) {
        const rot = celebrating ? dirSign * -28 : dirSign * -6;
        upperArmRef.current.style.transform = `translate3d(${(dirSign * armPushExtend).toFixed(1)}px, ${celebrating ? "-14px" : "0px"}, 0) rotate(${rot.toFixed(1)}deg)`;
      }

      if (lowerArmRef.current) {
        const rot = celebrating ? dirSign * -18 : dirSign * 5;
        lowerArmRef.current.style.transform = `translate3d(${(dirSign * armPushExtend * 1.08).toFixed(1)}px, ${celebrating ? "-8px" : "0px"}, 0) rotate(${rot.toFixed(1)}deg)`;
      }

      if (contactGlowRef.current) {
        contactGlowRef.current.style.opacity = contactBurst.toFixed(3);
        const gs = 0.85 + contactBurst * 0.35;
        contactGlowRef.current.style.transform = `scale3d(${gs.toFixed(3)}, ${gs.toFixed(3)}, 1)`;
      }

      if (tNorm < 1) {
        rafId = requestAnimationFrame(step);
      } else {
        finishSafely();
      }
    };

    rafId = requestAnimationFrame(step);

    return () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      window.clearTimeout(failsafeTimer);
    };
  }, [targetTheme, reducedMotion]);

  if (!targetTheme) return null;

  const isToDark = targetTheme === "dark";

  // Reduced-motion gentle cross-dissolve veil
  if (reducedMotion) {
    return (
      <div
        aria-hidden="true"
        className={`pointer-events-none fixed inset-0 z-[100] transition-opacity duration-200 ${
          isToDark ? "bg-[#071022]/40" : "bg-[#F7FCF9]/40"
        }`}
      />
    );
  }

  return (
    <div
      ref={overlayRef}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[100] overflow-hidden select-none"
    >
      {/* =====================================================================
          1. FULL-SCREEN WORLD CURTAIN BEING PUSHED BY HESI
          ===================================================================== */}
      <div
        ref={curtainRef}
        style={{ width: "108vw", height: "100dvh", willChange: "transform" }}
        className={`absolute top-0 left-0 ${
          isToDark
            ? "bg-gradient-to-r from-[#050C1A] via-[#09152B] to-[#0E2244] shadow-[24px_0_60px_rgba(2,6,23,0.65)]"
            : "bg-gradient-to-l from-[#FFFFFF] via-[#F4FBF7] to-[#E3F7EC] shadow-[-24px_0_60px_rgba(22,163,74,0.28)]"
        }`}
      >
        {isToDark ? (
          /* NIGHT ENVIRONMENT DETAILS (Crescent Moon, Twinkling Stars & Cool Nebula Glows) */
          <div className="relative h-full w-full overflow-hidden">
            {/* Subtle Night Nebula Glows */}
            <div
              className="absolute top-[15%] left-[20%] h-96 w-96 rounded-full opacity-25 blur-3xl"
              style={{ background: "radial-gradient(circle, #38BDF8, transparent 70%)" }}
            />
            <div
              className="absolute right-[18%] bottom-[12%] h-[28rem] w-[28rem] rounded-full opacity-25 blur-3xl"
              style={{ background: "radial-gradient(circle, #22C55E, transparent 70%)" }}
            />

            {/* Signature Hesi Crescent Moon Badge in Night Sky */}
            <svg
              viewBox="0 0 120 120"
              className="absolute top-[14%] right-[16%] h-24 w-24 drop-shadow-[0_0_28px_rgba(56,189,248,0.45)] sm:h-32 sm:w-32"
            >
              <circle cx="60" cy="60" r="46" fill="#1E3A8A" opacity="0.65" />
              <path
                d="M 68 32 C 50 34 38 50 41 68 C 44 84 60 95 78 90 C 64 99 44 93 35 78 C 26 63 32 42 48 34 C 54 30 61 30 68 32 Z"
                fill="#FEF08A"
              />
              <polygon
                points="80,38 83,45 90,48 83,51 80,58 77,51 70,48 77,45"
                fill="#FACC15"
              />
            </svg>

            {/* Restrained Twinkling 4-Point Night Stars */}
            {NIGHT_STARS.map((s, idx) => (
              <svg
                key={idx}
                viewBox="0 0 24 24"
                style={{
                  left: s.x,
                  top: s.y,
                  width: s.size,
                  height: s.size,
                }}
                className="absolute opacity-80"
              >
                <polygon
                  points="12,0 15,9 24,12 15,15 12,24 9,15 0,12 9,9"
                  fill={idx % 2 === 0 ? "#FDE047" : "#BAE6FD"}
                />
              </svg>
            ))}

            {/* Glowing Right Leading-Edge Seam where Hesi's Hands Push */}
            <div className="absolute inset-y-0 right-0 w-3 bg-gradient-to-b from-[#38BDF8] via-[#4ADE80] to-[#FACC15] shadow-[0_0_30px_#4ADE80]" />
            <div className="absolute inset-y-0 right-3 w-10 bg-gradient-to-l from-[#4ADE80]/30 to-transparent" />
          </div>
        ) : (
          /* DAY ENVIRONMENT DETAILS (Warm Sun, Soft Clouds & Mint-Emerald Rays) */
          <div className="relative h-full w-full overflow-hidden">
            {/* Warm Morning Glows */}
            <div
              className="absolute top-[14%] left-[18%] h-96 w-96 rounded-full opacity-45 blur-3xl"
              style={{ background: "radial-gradient(circle, #FDE68A, transparent 70%)" }}
            />
            <div
              className="absolute right-[20%] bottom-[14%] h-[28rem] w-[28rem] rounded-full opacity-40 blur-3xl"
              style={{ background: "radial-gradient(circle, #86EFAC, transparent 70%)" }}
            />

            {/* Radiant Daytime Sun & Soft Clouds */}
            <svg
              viewBox="0 0 140 140"
              className="absolute top-[14%] left-[16%] h-24 w-24 drop-shadow-[0_8px_24px_rgba(250,204,21,0.45)] sm:h-32 sm:w-32"
            >
              <circle cx="70" cy="70" r="44" fill="#FEF08A" opacity="0.55" />
              <circle cx="70" cy="70" r="32" fill="#FACC15" />
              {/* Soft White Morning Cloud */}
              <path
                d="M 52 96 H 106 C 115 96 122 89 122 80 C 122 72 116 66 108 65 C 106 53 95 44 82 44 C 70 44 60 52 57 63 C 48 64 42 71 42 80 C 42 89 46 96 52 96 Z"
                fill="#FFFFFF"
                opacity="0.92"
              />
            </svg>

            {/* Floating Daytime Mint Rhombus Particles */}
            <svg viewBox="0 0 40 40" className="absolute top-[24%] right-[28%] h-8 w-8">
              <rect
                x="8"
                y="8"
                width="24"
                height="24"
                rx="5"
                transform="rotate(22 20 20)"
                fill="#4ADE80"
                opacity="0.6"
              />
            </svg>
            <svg viewBox="0 0 40 40" className="absolute bottom-[26%] left-[32%] h-7 w-7">
              <rect
                x="8"
                y="8"
                width="24"
                height="24"
                rx="5"
                transform="rotate(-18 20 20)"
                fill="#34D399"
                opacity="0.55"
              />
            </svg>

            {/* Glowing Left Leading-Edge Seam where Hesi's Hands Push */}
            <div className="absolute inset-y-0 left-0 w-3 bg-gradient-to-b from-[#FACC15] via-[#22C55E] to-[#38BDF8] shadow-[0_0_30px_#22C55E]" />
            <div className="absolute inset-y-0 left-3 w-10 bg-gradient-to-r from-[#22C55E]/30 to-transparent" />
          </div>
        )}
      </div>

      {/* =====================================================================
          2. HESI MASCOT PHYSICALLY PUSHING THE CURTAIN EDGE
          ===================================================================== */}
      <div
        ref={mascotMoverRef}
        style={{
          top: "calc(50dvh - 110px)",
          left: 0,
          width: "220px",
          height: "220px",
          willChange: "transform",
        }}
        className="absolute"
      >
        <svg
          viewBox="0 0 260 260"
          className="h-full w-full overflow-visible drop-shadow-[0_20px_35px_rgba(15,29,58,0.38)]"
        >
          {/* Glowing Contact Ripple right where Hesi's hands push the curtain seam */}
          <g
            ref={contactGlowRef}
            transform={isToDark ? "translate(112, 128)" : "translate(148, 128)"}
            style={{ transformBox: "fill-box", transformOrigin: "center" }}
          >
            <ellipse
              cx="0"
              cy="0"
              rx="22"
              ry="74"
              fill={isToDark ? "#4ADE80" : "#FACC15"}
              opacity="0.45"
            />
            <ellipse
              cx="0"
              cy="0"
              rx="10"
              ry="48"
              fill="#FFFFFF"
              opacity="0.75"
            />
          </g>

          {/* Hesi Character Group with Push Lean, Effort Compression & Release Hop */}
          <g transform="translate(130, 134)">
            <g
              ref={mascotPoseRef}
              style={{ transformBox: "fill-box", transformOrigin: "center bottom" }}
            >
              {/* Trailing Speed / Effort Swooshes behind Hesi */}
              <g opacity="0.85">
                {isToDark ? (
                  <>
                    <path
                      d="M -78 -24 H -118"
                      stroke="#4ADE80"
                      strokeWidth="5"
                      strokeLinecap="round"
                    />
                    <path
                      d="M -84 18 H -134"
                      stroke="#86EFAC"
                      strokeWidth="6"
                      strokeLinecap="round"
                    />
                  </>
                ) : (
                  <>
                    <path
                      d="M 78 -24 H 118"
                      stroke="#4ADE80"
                      strokeWidth="5"
                      strokeLinecap="round"
                    />
                    <path
                      d="M 84 18 H 134"
                      stroke="#FACC15"
                      strokeWidth="6"
                      strokeLinecap="round"
                    />
                  </>
                )}
              </g>

              {/* Authentic 3D Faceted Emerald Hesi Body */}
              <HesiBody
                angle={isToDark ? "right" : "left"}
                showTipGem
                transform="scale(0.84)"
              />

              {/* Authentic Hesi Visor & Optical Sensor looking toward the curtain wall */}
              <HesiVisor
                variant={celebrating ? "happy" : "default"}
                lookX={isToDark ? 11 : -11}
                lookY={celebrating ? -2 : 1}
                transform={
                  isToDark
                    ? "translate(10, -16) scale(0.84)"
                    : "translate(-10, -16) scale(0.84)"
                }
              />

              {/* Upper Pushing Arm & Glossy Spherical Hand planted on the curtain edge */}
              <g
                ref={upperArmRef}
                style={{ transformBox: "fill-box", transformOrigin: "center" }}
              >
                {isToDark ? (
                  <g transform="translate(-38, -22)">
                    <path
                      d="M -22 8 C -8 0 8 -4 20 0 C 26 4 22 16 8 16 C -6 16 -18 14 -22 8 Z"
                      fill="#16A34A"
                    />
                    <HesiHand cx={18} cy={6} r={16} />
                  </g>
                ) : (
                  <g transform="translate(38, -22)">
                    <path
                      d="M 22 8 C 8 0 -8 -4 -20 0 C -26 4 -22 16 -8 16 C 6 16 18 14 22 8 Z"
                      fill="#16A34A"
                    />
                    <HesiHand cx={-18} cy={6} r={16} />
                  </g>
                )}
              </g>

              {/* Lower Pushing Arm & Glossy Spherical Hand planted on the curtain edge */}
              <g
                ref={lowerArmRef}
                style={{ transformBox: "fill-box", transformOrigin: "center" }}
              >
                {isToDark ? (
                  <g transform="translate(-34, 18)">
                    <path
                      d="M -26 6 C -10 -2 8 -4 22 2 C 28 8 22 20 6 18 C -8 18 -20 12 -26 6 Z"
                      fill="#22C55E"
                    />
                    <HesiHand cx={18} cy={8} r={17} />
                  </g>
                ) : (
                  <g transform="translate(34, 18)">
                    <path
                      d="M 26 6 C 10 -2 -8 -4 -22 2 C -28 8 -22 20 -6 18 C 8 18 20 12 26 6 Z"
                      fill="#22C55E"
                    />
                    <HesiHand cx={-18} cy={8} r={17} />
                  </g>
                )}
              </g>
            </g>
          </g>
        </svg>
      </div>
    </div>
  );
}
