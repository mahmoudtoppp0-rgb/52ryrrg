import { useCallback, useEffect, useRef, useState } from "react";
import {
  ALL_MASCOTS,
  EMOTIONAL_MASCOTS,
  SUBSCRIPTION_MASCOTS,
  type MascotId,
  type MascotItem,
} from "./data/mascots";
import {
  buildLessonUrl,
  parseLessonRouteFromLocation,
} from "./data/lessons";
import { DEFAULT_LAYERS, MascotBadgeIcon, type LayerVisibility } from "./components/HesiCoreParts";
import HesiHeaderLockup, { HesiBrandMark } from "./components/HesiHeaderLockup";
import HesiLessonCurtainTransition, {
  type LessonNavigationTransitionState,
} from "./components/HesiLessonCurtainTransition";
import HesiLessonView from "./components/HesiLessonView";
import HesiThemeCurtainTransition, {
  type ThemeMode,
} from "./components/HesiThemeCurtainTransition";
import LivePlaygroundModal from "./components/LivePlaygroundModal";
import MascotCard, { type LanguageMode } from "./components/MascotCard";
import MascotRenderer from "./components/MascotRenderer";
import { animationEngine60fps } from "./utils/animationEngine60fps";
import {
  getSweepSoundEnabled,
  setSweepSoundEnabled,
} from "./utils/sweepSound";

const THEME_STORAGE_KEY = "hesi-theme";

function getInitialTheme(): ThemeMode {
  try {
    const saved = window.localStorage.getItem(THEME_STORAGE_KEY);
    if (saved === "dark" || saved === "light") return saved;
  } catch {
    // Ignore storage access errors
  }
  return "light";
}

function applyThemeToDocument(theme: ThemeMode) {
  document.documentElement.dataset.theme = theme;
  document.documentElement.classList.toggle("dark", theme === "dark");
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) {
    metaTheme.setAttribute("content", theme === "dark" ? "#071022" : "#F7FCF9");
  }
  try {
    window.localStorage.setItem(THEME_STORAGE_KEY, theme);
  } catch {
    // Ignore storage errors
  }
}

export default function App() {
  const [lang, setLang] = useState<LanguageMode>("bilingual");
  const [reducedMotion, setReducedMotion] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [soundEnabled, setSoundEnabledState] = useState<boolean>(getSweepSoundEnabled);
  const [inspectedMascot, setInspectedMascot] = useState<MascotItem | null>(null);

  // Theme State & Curtain Transition State (independent of lesson navigation)
  const [theme, setTheme] = useState<ThemeMode>(getInitialTheme);
  const [transitionTargetTheme, setTransitionTargetTheme] = useState<ThemeMode | null>(null);

  // Lesson Route State (initialized from current URL without playing transition on load/refresh)
  const [activeLessonId, setActiveLessonId] = useState<MascotId | null>(
    parseLessonRouteFromLocation
  );
  const [lessonTransition, setLessonTransition] =
    useState<LessonNavigationTransitionState | null>(null);
  const navTransitionCounterRef = useRef(0);

  // Interactive Simulator State
  const [simMascotId, setSimMascotId] = useState<MascotId>("focused");
  const [simLayers, setSimLayers] = useState<Required<LayerVisibility>>(DEFAULT_LAYERS);
  const [simReactionCount, setSimReactionCount] = useState(0);

  // Ensure document theme attribute is synced on initial mount
  useEffect(() => {
    applyThemeToDocument(theme);
  }, [theme]);

  // Listen to browser Back/Forward navigation (popstate & hashchange)
  useEffect(() => {
    const syncRouteFromLocation = () => {
      const parsed = parseLessonRouteFromLocation();
      setActiveLessonId(parsed);
      setLessonTransition(null);
    };
    window.addEventListener("popstate", syncRouteFromLocation);
    window.addEventListener("hashchange", syncRouteFromLocation);
    return () => {
      window.removeEventListener("popstate", syncRouteFromLocation);
      window.removeEventListener("hashchange", syncRouteFromLocation);
    };
  }, []);

  // Sync system prefers-reduced-motion on mount
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);
    animationEngine60fps.setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => {
      setReducedMotion(e.matches);
      animationEngine60fps.setReducedMotion(e.matches);
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  const handleToggleReducedMotion = () => {
    setReducedMotion((prev) => {
      const next = !prev;
      animationEngine60fps.setReducedMotion(next);
      return next;
    });
  };

  const handleChangeSpeed = (nextSpeed: number) => {
    setSpeed(nextSpeed);
    animationEngine60fps.setSpeedMultiplier(nextSpeed);
  };

  const handleToggleSound = () => {
    setSoundEnabledState((prev) => {
      const next = !prev;
      setSweepSoundEnabled(next);
      return next;
    });
  };

  // Trigger the Hesi Curtain Push Theme Transition (preventing duplicate triggers while running)
  const handleToggleTheme = useCallback(() => {
    if (transitionTargetTheme !== null || lessonTransition !== null) return;
    const nextTheme: ThemeMode = theme === "light" ? "dark" : "light";
    setTransitionTargetTheme(nextTheme);
  }, [theme, transitionTargetTheme, lessonTransition]);

  const handleCommitTheme = useCallback((committedTheme: ThemeMode) => {
    setTheme(committedTheme);
    applyThemeToDocument(committedTheme);
  }, []);

  const handleCompleteThemeTransition = useCallback(() => {
    setTransitionTargetTheme(null);
  }, []);

  // Trigger the Hesi Lesson Entry Sweep Transition (preventing duplicate clicks)
  const handleEnterLesson = useCallback(
    (targetLessonId: MascotId) => {
      if (lessonTransition !== null || transitionTargetTheme !== null) return;
      if (activeLessonId === targetLessonId) return;

      navTransitionCounterRef.current += 1;
      setLessonTransition({
        transitionId: navTransitionCounterRef.current,
        targetLessonId,
        direction: "enter",
      });
    },
    [activeLessonId, lessonTransition, transitionTargetTheme]
  );

  // Trigger the Hesi Return-to-Dashboard Sweep Transition
  const handleReturnToDashboard = useCallback(() => {
    if (lessonTransition !== null || transitionTargetTheme !== null) return;
    if (activeLessonId === null) return;

    navTransitionCounterRef.current += 1;
    setLessonTransition({
      transitionId: navTransitionCounterRef.current,
      targetLessonId: null,
      direction: "return",
    });
  }, [activeLessonId, lessonTransition, transitionTargetTheme]);

  // Commit the route change underneath the lesson curtain once the screen is covered
  const handleCommitLessonNavigation = useCallback((targetLessonId: MascotId | null) => {
    try {
      const nextUrl = buildLessonUrl(targetLessonId);
      window.history.pushState({ lessonId: targetLessonId }, "", nextUrl);
    } catch {
      // Fallback if history.pushState is restricted in a sandboxed iframe
    }
    setActiveLessonId(targetLessonId);
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, []);

  const handleCompleteLessonTransition = useCallback(() => {
    setLessonTransition(null);
  }, []);

  const simItem =
    ALL_MASCOTS.find((m) => m.id === simMascotId) || EMOTIONAL_MASCOTS[0];

  const triggerSimReaction = () => {
    setSimReactionCount((c) => c + 1);
  };

  const toggleSimLayer = (key: keyof LayerVisibility) => {
    setSimLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const isDark = theme === "dark";
  const isThemeTransitioning = transitionTargetTheme !== null;
  const isNavigating = lessonTransition !== null;

  return (
    <div
      id="top"
      className={`min-h-svh transition-colors duration-300 ${
        isDark ? "bg-[#071022] text-[#F1F5F9]" : "bg-[#F7FCF9] text-[#0F1D3A]"
      } ${reducedMotion ? "reduced-motion" : ""}`}
    >
      {/* 1. Full-Screen Hesi Curtain Push THEME Transition Overlay */}
      <HesiThemeCurtainTransition
        targetTheme={transitionTargetTheme}
        reducedMotion={reducedMotion}
        onCommitTheme={handleCommitTheme}
        onComplete={handleCompleteThemeTransition}
      />

      {/* 2. Full-Screen Hesi Curtain Sweep LESSON NAVIGATION Transition Overlay */}
      <HesiLessonCurtainTransition
        transition={lessonTransition}
        theme={theme}
        reducedMotion={reducedMotion}
        onCommitNavigation={handleCommitLessonNavigation}
        onComplete={handleCompleteLessonTransition}
      />

      {/* Sticky Header with Authentic Reference Image 2 Lockup + Lesson & Theme Controls */}
      <HesiHeaderLockup
        lang={lang}
        onChangeLang={setLang}
        reducedMotion={reducedMotion}
        onToggleReducedMotion={handleToggleReducedMotion}
        speed={speed}
        onChangeSpeed={handleChangeSpeed}
        theme={theme}
        isThemeTransitioning={isThemeTransitioning}
        onToggleTheme={handleToggleTheme}
        activeLessonId={activeLessonId}
        isNavigating={isNavigating}
        onEnterLesson={handleEnterLesson}
        onReturnToDashboard={handleReturnToDashboard}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
      />

      <main>
        {activeLessonId !== null ? (
          /* =================================================================
             ACTIVE LESSON EXPERIENCE PAGE (Rendered when navigated to a lesson)
             ================================================================= */
          <HesiLessonView
            lessonId={activeLessonId}
            lang={lang}
            theme={theme}
            isNavigating={isNavigating}
            onNavigateToLesson={handleEnterLesson}
            onReturnToDashboard={handleReturnToDashboard}
          />
        ) : (
          /* =================================================================
             MAIN HESI PLATFORM DASHBOARD
             ================================================================= */
          <div data-dashboard-ready="true">
            {/* HERO SECTION — Overview & Quick Interactive 60fps Switcher */}
            <section
              className={`relative overflow-hidden border-b py-12 transition-colors duration-300 sm:py-16 ${
                isDark
                  ? "border-[#1E3A5F] bg-gradient-to-b from-[#071022] via-[#0A1830] to-[#081C29]"
                  : "border-[#DCEEE3] bg-gradient-to-b from-white via-[#F6FCF8] to-[#ECF9F2]"
              }`}
            >
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="grid items-center gap-10 lg:grid-cols-12">
                  {/* Hero Copy */}
                  <div className="lg:col-span-7">
                    <div
                      className={`inline-flex flex-wrap items-center gap-2 rounded-full border px-3.5 py-1.5 text-xs font-semibold shadow-2xs ${
                        isDark
                          ? "border-[#22C55E]/40 bg-[#0D1E3A] text-[#86EFAC]"
                          : "border-[#BFE8D1] bg-white text-[#0D7A3E]"
                      }`}
                    >
                      <span className="h-2 w-2 rounded-full bg-[#22C55E]" />
                      <span>60 FPS Character Rigs • Lesson & Theme Curtain Transitions</span>
                      <span className="text-[#94A3B8]">•</span>
                      <span className="font-arabic" dir="rtl">
                        ٤ باقات اشتراك + ٦ تعبيرات شعورية
                      </span>
                    </div>

                    <h1
                      className={`mt-5 font-display text-3xl font-extrabold tracking-tight sm:text-5xl sm:leading-[1.12] ${
                        isDark ? "text-white" : "text-[#0F1D3A]"
                      }`}
                    >
                      Meet{" "}
                      <span className="bg-gradient-to-r from-[#22C55E] to-[#10B981] bg-clip-text text-transparent">
                        Hesi (هيسي)
                      </span>{" "}
                      — your interactive 60fps learning companion.
                    </h1>

                    <p
                      className={`mt-4 max-w-2xl text-base leading-relaxed ${
                        isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
                      }`}
                    >
                      Click <strong>Enter Lesson</strong> on any mascot below to watch Hesi physically
                      sweep the lesson curtain across the viewport (accompanied by a gentle airy whoosh)
                      and launch an interactive bilingual lesson underneath.
                    </p>

                    {/* Primary Lesson Entry & Theme Curtain Trigger Pills */}
                    <div className="mt-7 flex flex-wrap items-center gap-3">
                      <button
                        type="button"
                        onClick={() => handleEnterLesson(simItem.id)}
                        disabled={isNavigating || isThemeTransitioning}
                        className="inline-flex items-center gap-2 rounded-full bg-[#16A34A] px-5 py-2.5 text-sm font-bold text-white shadow-md shadow-[#16A34A]/25 transition-all hover:-translate-y-0.5 hover:bg-[#15803D] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none disabled:cursor-wait disabled:opacity-80"
                      >
                        <span>
                          {lang === "ar"
                            ? `ابدأ درس ${simItem.nameAr}`
                            : `Enter ${simItem.nameEn} Lesson`}
                        </span>
                        <span aria-hidden="true">→</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleToggleTheme}
                        disabled={isThemeTransitioning || isNavigating}
                        className={`inline-flex items-center gap-2.5 rounded-full border px-5 py-2.5 text-sm font-bold shadow-md transition-all hover:-translate-y-0.5 focus-visible:ring-2 focus-visible:ring-[#22C55E] focus-visible:outline-none disabled:cursor-wait disabled:opacity-80 ${
                          isDark
                            ? "border-[#FACC15]/50 bg-gradient-to-r from-[#1E3A8A] to-[#0F2347] text-[#FEF08A] shadow-[#38BDF8]/10 hover:border-[#FACC15]"
                            : "border-[#0F1D3A] bg-[#0F1D3A] text-white shadow-[#0F1D3A]/20 hover:bg-[#1E293B]"
                        }`}
                      >
                        <span aria-hidden="true">{isDark ? "☀️" : "🌙"}</span>
                        <span>
                          {isDark
                            ? "Watch Hesi Push Day Curtain"
                            : "Watch Hesi Push Night Curtain"}
                        </span>
                      </button>

                      <a
                        href="#emotional-mascots"
                        className={`inline-flex items-center gap-2 rounded-full border px-5 py-2.5 text-sm font-bold shadow-2xs transition-all hover:-translate-y-0.5 focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none ${
                          isDark
                            ? "border-[#1E3A5F] bg-[#0D1E3A] text-white hover:border-[#22C55E]"
                            : "border-[#BFE8D1] bg-white text-[#0F1D3A] hover:border-[#16A34A] hover:text-[#16A34A]"
                        }`}
                      >
                        <span>6 Emotional States</span>
                        <span className="font-arabic text-xs font-bold text-[#22C55E]" dir="rtl">
                          (تعبيرات هيسي)
                        </span>
                      </a>
                    </div>

                    {/* Key Highlights */}
                    <dl
                      className={`mt-8 grid grid-cols-2 gap-4 border-t pt-6 sm:grid-cols-4 ${
                        isDark ? "border-[#1E3A5F]" : "border-[#D8EFE2]"
                      }`}
                    >
                      <div>
                        <dt className={`text-xs font-semibold ${isDark ? "text-[#94A3B8]" : "text-[#475569]"}`}>
                          Frame Rate
                        </dt>
                        <dd className="mt-0.5 font-display text-lg font-extrabold text-[#22C55E]">
                          60 FPS rAF Loop
                        </dd>
                      </div>
                      <div>
                        <dt className={`text-xs font-semibold ${isDark ? "text-[#94A3B8]" : "text-[#475569]"}`}>
                          Lesson Sweep
                        </dt>
                        <dd
                          className={`mt-0.5 font-display text-lg font-extrabold ${
                            isDark ? "text-white" : "text-[#0F1D3A]"
                          }`}
                        >
                          10 Interactive Units
                        </dd>
                      </div>
                      <div>
                        <dt className={`text-xs font-semibold ${isDark ? "text-[#94A3B8]" : "text-[#475569]"}`}>
                          Theme Curtain
                        </dt>
                        <dd
                          className={`mt-0.5 font-display text-lg font-extrabold ${
                            isDark ? "text-[#FEF08A]" : "text-[#0F1D3A]"
                          }`}
                        >
                          {isDark ? "Night World 🌙" : "Day World ☀️"}
                        </dd>
                      </div>
                      <div>
                        <dt className={`text-xs font-semibold ${isDark ? "text-[#94A3B8]" : "text-[#475569]"}`}>
                          Sweep Audio
                        </dt>
                        <dd
                          className={`mt-0.5 font-display text-lg font-extrabold ${
                            isDark ? "text-white" : "text-[#0F1D3A]"
                          }`}
                        >
                          {soundEnabled ? "340ms Airy Whoosh" : "Muted"}
                        </dd>
                      </div>
                    </dl>
                  </div>

                  {/* Hero Right: Live Interactive 60fps Mascot Stage Preview */}
                  <div className="lg:col-span-5">
                    <div
                      className={`rounded-[30px] border p-5 transition-colors duration-300 ${
                        isDark
                          ? "border-[#1E3A5F] bg-[#0B172E] shadow-[0_20px_50px_-15px_rgba(2,6,23,0.75)]"
                          : "border-[#BFE8D1] bg-white shadow-[0_20px_50px_-15px_rgba(22,163,74,0.16)]"
                      }`}
                    >
                      <div
                        className={`flex items-center justify-between border-b pb-3 ${
                          isDark ? "border-[#1E3A5F]" : "border-[#E8F5EE]"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="h-2.5 w-2.5 rounded-full bg-[#22C55E]" />
                          <span
                            className={`text-xs font-bold uppercase tracking-wider ${
                              isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
                            }`}
                          >
                            Live 60 FPS Stage
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => handleEnterLesson(simItem.id)}
                            disabled={isNavigating}
                            className="text-xs font-bold text-[#22C55E] hover:underline"
                          >
                            Enter Lesson →
                          </button>
                          <button
                            type="button"
                            onClick={() => setInspectedMascot(simItem)}
                            className={`text-xs font-semibold hover:underline ${
                              isDark ? "text-[#94A3B8]" : "text-[#475569]"
                            }`}
                          >
                            Layers
                          </button>
                        </div>
                      </div>

                      <div
                        role="button"
                        tabIndex={0}
                        onClick={triggerSimReaction}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            triggerSimReaction();
                          }
                        }}
                        aria-label="Move pointer to track gaze or click to trigger 60fps spring reaction"
                        className="mx-auto my-2 flex aspect-[10/8.5] w-full max-w-[310px] cursor-pointer items-center justify-center rounded-2xl outline-none focus-visible:ring-2 focus-visible:ring-[#16A34A]"
                      >
                        <MascotRenderer
                          id={simItem.id}
                          reactionTrigger={simReactionCount}
                        />
                      </div>

                      {/* Pill Badge matching Reference Image 2 */}
                      <div
                        className={`mx-auto flex max-w-[290px] items-center justify-between gap-3 rounded-full border px-3.5 py-2 ${
                          isDark
                            ? "border-[#1E4638] bg-[#0F2926]"
                            : "border-[#BDE8D0] bg-[#EBF9F1]"
                        }`}
                      >
                        <MascotBadgeIcon type={simItem.iconType} accentColor={simItem.accentColor} />
                        <div className="text-center leading-tight">
                          <div className="flex items-center justify-center gap-1.5">
                            <span
                              className={`font-display text-sm font-bold ${
                                isDark ? "text-white" : "text-[#0F1D3A]"
                              }`}
                            >
                              {simItem.nameEn}
                            </span>
                            <span className="text-xs text-[#94A3B8]">•</span>
                            <span
                              className={`font-arabic text-sm font-bold ${
                                isDark ? "text-[#86EFAC]" : "text-[#0F1D3A]"
                              }`}
                              dir="rtl"
                            >
                              {simItem.nameAr}
                            </span>
                          </div>
                          <p
                            className={`text-[11px] font-medium ${
                              isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
                            }`}
                          >
                            {simItem.subtitleEn} /{" "}
                            <span className="font-arabic" dir="rtl">
                              {simItem.subtitleAr}
                            </span>
                          </p>
                        </div>
                        <div className="w-3" aria-hidden="true" />
                      </div>

                      {/* Mini 10-state selector strip */}
                      <div className="mt-4 flex flex-wrap justify-center gap-1.5">
                        {ALL_MASCOTS.map((m) => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setSimMascotId(m.id)}
                            className={`rounded-full px-2.5 py-1 text-[11px] font-semibold transition-all ${
                              simItem.id === m.id
                                ? "bg-[#16A34A] text-white shadow-2xs"
                                : isDark
                                ? "bg-[#132647] text-[#CBD5E1] hover:bg-[#1E3A5F]"
                                : "bg-[#F1F8F4] text-[#253858] hover:bg-[#DCFCE7]"
                            }`}
                          >
                            {lang === "ar" ? m.nameAr : m.nameEn}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* SECTION 1: SUBSCRIPTION-PLAN MASCOTS (Reference Image 1) */}
            <section
              id="subscription-mascots"
              className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8"
            >
              <div
                className={`flex flex-col justify-between gap-4 border-b pb-6 md:flex-row md:items-end ${
                  isDark ? "border-[#1E3A5F]" : "border-[#DCEEE3]"
                }`}
              >
                <div>
                  <span
                    className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider ${
                      isDark
                        ? "bg-[#112E28] text-[#86EFAC]"
                        : "bg-[#ECFDF3] text-[#16A34A]"
                    }`}
                  >
                    Reference Source 01 • Subscription Tiers
                  </span>
                  <h2
                    className={`mt-3 font-display text-2xl font-extrabold tracking-tight sm:text-3xl ${
                      isDark ? "text-white" : "text-[#0F1D3A]"
                    }`}
                  >
                    Subscription-Plan Mascots{" "}
                    <span className="font-arabic text-xl font-bold text-[#22C55E]" dir="rtl">
                      (باقات هيسي التعليمية)
                    </span>
                  </h2>
                  <p
                    className={`mt-2 max-w-2xl text-sm ${
                      isDark ? "text-[#94A3B8]" : "text-[#475569]"
                    }`}
                  >
                    Four distinct holographic pedestal mascots representing Individual, Pro, Family,
                    and Group learning plans. Click <strong>Enter Lesson</strong> on any card to
                    launch its interactive learning unit with Hesi’s screen-sweep transition.
                  </p>
                </div>

                <div
                  className={`flex flex-wrap items-center gap-2 text-xs font-semibold ${
                    isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
                  }`}
                >
                  <span
                    className={`rounded-lg border px-3 py-1.5 ${
                      isDark
                        ? "border-[#1E3A5F] bg-[#0B172E]"
                        : "border-[#DCEEE3] bg-white"
                    }`}
                  >
                    60 FPS Pointer Tracking & Lesson Sweep
                  </span>
                </div>
              </div>

              <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {SUBSCRIPTION_MASCOTS.map((item, idx) => (
                  <MascotCard
                    key={item.id}
                    item={item}
                    index={idx}
                    lang={lang}
                    theme={theme}
                    isNavigating={isNavigating}
                    onInspect={setInspectedMascot}
                    onEnterLesson={handleEnterLesson}
                  />
                ))}
              </div>
            </section>

            {/* SECTION 2: EMOTIONAL STATE MASCOTS (Reference Image 2) */}
            <section
              id="emotional-mascots"
              className={`scroll-mt-20 border-y py-16 transition-colors duration-300 ${
                isDark
                  ? "border-[#1E3A5F] bg-gradient-to-b from-[#081328] via-[#071022] to-[#081328]"
                  : "border-[#DCEEE3] bg-gradient-to-b from-white via-[#F8FCFA] to-white"
              }`}
            >
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                {/* Reference Image 2 Authentic Section Banner Header */}
                <div
                  className={`flex flex-wrap items-center justify-between gap-6 rounded-3xl border px-6 py-5 shadow-2xs ${
                    isDark
                      ? "border-[#1E3A5F] bg-[#0B172E]"
                      : "border-[#DCEEE3] bg-[#F7FCF9]"
                  }`}
                >
                  <div className="flex flex-wrap items-center gap-4">
                    <HesiBrandMark size={54} />
                    <span
                      className={`font-display text-4xl font-extrabold tracking-tight ${
                        isDark ? "text-white" : "text-[#0F1D3A]"
                      }`}
                    >
                      Hesi
                    </span>
                    <span
                      className={`h-11 w-px ${isDark ? "bg-[#334E68]" : "bg-[#CBD5E1]"}`}
                      aria-hidden="true"
                    />
                    <div dir="rtl" className="font-arabic">
                      <h2
                        className={`text-2xl font-extrabold ${
                          isDark ? "text-white" : "text-[#0F1D3A]"
                        }`}
                      >
                        تعبيرات هيسي
                      </h2>
                      <p
                        className={`text-sm font-semibold ${
                          isDark ? "text-[#86EFAC]" : "text-[#334E68]"
                        }`}
                      >
                        كل لحظة ... شعور مختلف
                      </p>
                    </div>
                  </div>

                  <div
                    className={`max-w-md text-xs leading-relaxed ${
                      isDark ? "text-[#94A3B8]" : "text-[#475569]"
                    }`}
                  >
                    <strong className={isDark ? "text-white" : "text-[#0F1D3A]"}>
                      Emotionally Intelligent 60 FPS Motion:
                    </strong>{" "}
                    Each emotional state runs a unique multi-joint rig and has its own dedicated
                    interactive lesson module.
                  </div>
                </div>

                {/* 3x2 Grid matching Reference Image 2 */}
                <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {EMOTIONAL_MASCOTS.map((item, idx) => (
                    <MascotCard
                      key={item.id}
                      item={item}
                      index={idx + 4}
                      lang={lang}
                      theme={theme}
                      isNavigating={isNavigating}
                      onInspect={setInspectedMascot}
                      onEnterLesson={handleEnterLesson}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* SECTION 3: INTERACTIVE LEARNER SCENARIO & 60FPS LAYER SIMULATOR */}
            <section
              id="scenario-simulator"
              className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8"
            >
              <div
                className={`rounded-[32px] border p-6 transition-colors duration-300 sm:p-10 ${
                  isDark
                    ? "border-[#1E3A5F] bg-[#0B172E] shadow-[0_18px_45px_-16px_rgba(2,6,23,0.75)]"
                    : "border-[#BFE8D1] bg-white shadow-[0_18px_45px_-16px_rgba(15,29,58,0.08)]"
                }`}
              >
                <div className="flex flex-wrap items-end justify-between gap-4">
                  <div className="max-w-3xl">
                    <span
                      className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wider ${
                        isDark
                          ? "bg-[#112E28] text-[#86EFAC]"
                          : "bg-[#ECFDF3] text-[#16A34A]"
                      }`}
                    >
                      Interactive Sandbox • 60 FPS Rig & Lesson Entry Testing
                    </span>
                    <h2
                      className={`mt-3 font-display text-2xl font-extrabold sm:text-3xl ${
                        isDark ? "text-white" : "text-[#0F1D3A]"
                      }`}
                    >
                      Simulate Real Learner Moments & Toggle Independent SVG Layers
                    </h2>
                    <p
                      className={`mt-2 text-sm ${
                        isDark ? "text-[#94A3B8]" : "text-[#475569]"
                      }`}
                    >
                      Select any of the 10 Hesi states below to preview how Hesi responds at 60fps,
                      toggle SVG layers, or enter that state’s interactive lesson.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleEnterLesson(simItem.id)}
                      disabled={isNavigating || isThemeTransitioning}
                      className="inline-flex items-center gap-2 rounded-full bg-[#16A34A] px-4 py-2 text-xs font-bold text-white shadow-xs transition-all hover:bg-[#15803D] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none disabled:cursor-wait disabled:opacity-75"
                    >
                      <span>
                        {lang === "ar"
                          ? `ابدأ درس ${simItem.nameAr}`
                          : `Enter ${simItem.nameEn} Lesson`}
                      </span>
                      <span aria-hidden="true">→</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleToggleTheme}
                      disabled={isThemeTransitioning || isNavigating}
                      className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-bold transition-all focus-visible:ring-2 focus-visible:ring-[#22C55E] focus-visible:outline-none disabled:cursor-wait disabled:opacity-75 ${
                        isDark
                          ? "border-[#38BDF8]/50 bg-[#0F2347] text-[#FEF08A] hover:border-[#38BDF8]"
                          : "border-[#BFE8D1] bg-[#F4FBF7] text-[#0F1D3A] hover:border-[#16A34A]"
                      }`}
                    >
                      <span aria-hidden="true">{isDark ? "☀️" : "🌙"}</span>
                      <span>{isDark ? "Push Day Curtain" : "Push Night Curtain"}</span>
                    </button>
                  </div>
                </div>

                {/* Scenario Buttons */}
                <div className="mt-6 flex flex-wrap gap-2">
                  {ALL_MASCOTS.map((m) => {
                    const active = m.id === simMascotId;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          setSimMascotId(m.id);
                          setSimLayers(DEFAULT_LAYERS);
                        }}
                        className={`inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-xs font-bold transition-all focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none ${
                          active
                            ? "border-[#16A34A] bg-[#16A34A] text-white shadow-sm"
                            : isDark
                            ? "border-[#1E3A5F] bg-[#0F213E] text-[#E2E8F0] hover:border-[#22C55E]"
                            : "border-[#DCEEE3] bg-[#F7FCF9] text-[#0F1D3A] hover:border-[#86EFAC]"
                        }`}
                      >
                        <span>{m.nameEn}</span>
                        <span className="font-arabic opacity-90" dir="rtl">
                          ({m.nameAr})
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Simulator Stage + Layer Controls */}
                <div className="mt-8 grid items-center gap-8 lg:grid-cols-12">
                  {/* Stage */}
                  <div
                    className={`flex flex-col items-center rounded-3xl border p-6 lg:col-span-5 ${
                      isDark
                        ? "border-[#1E3A5F] bg-gradient-to-b from-[#0E1E3A] via-[#0B1830] to-[#0A2229]"
                        : "border-[#D9EFE4] bg-gradient-to-b from-[#F4FAFC] via-[#F1F9FB] to-[#E8F7F0]"
                    }`}
                  >
                    <div
                      onClick={triggerSimReaction}
                      className="aspect-square w-full max-w-[290px] cursor-pointer"
                    >
                      <MascotRenderer
                        id={simItem.id}
                        layers={simLayers}
                        reactionTrigger={simReactionCount}
                      />
                    </div>

                    <div className="mt-2 flex w-full items-center justify-between gap-2">
                      <span
                        className={`text-xs font-semibold ${
                          isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
                        }`}
                      >
                        Motion: {simItem.reactionCue}
                      </span>
                      <button
                        type="button"
                        onClick={triggerSimReaction}
                        className="rounded-full bg-[#16A34A] px-3.5 py-1.5 text-xs font-bold text-white transition-colors hover:bg-[#15803D]"
                      >
                        ⚡ Play 60fps Impulse
                      </button>
                    </div>
                  </div>

                  {/* Layer Toggles & Simulated App Prompt */}
                  <div className="space-y-5 lg:col-span-7">
                    {/* Simulated In-App Coaching Card */}
                    <div
                      className={`rounded-2xl border p-5 ${
                        isDark
                          ? "border-[#1E3A5F] bg-[#081225]"
                          : "border-[#BFE8D1] bg-[#F4FBF7]"
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-3">
                          <MascotBadgeIcon
                            type={simItem.iconType}
                            accentColor={simItem.accentColor}
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <h3
                                className={`font-display text-lg font-extrabold ${
                                  isDark ? "text-white" : "text-[#0F1D3A]"
                                }`}
                              >
                                {simItem.nameEn} — {simItem.subtitleEn}
                              </h3>
                              <span
                                className="font-arabic text-base font-extrabold text-[#22C55E]"
                                dir="rtl"
                              >
                                {simItem.nameAr} ({simItem.subtitleAr})
                              </span>
                            </div>
                            <p className={`text-xs ${isDark ? "text-[#94A3B8]" : "text-[#475569]"}`}>
                              {simItem.motionProfile}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 grid gap-3 sm:grid-cols-2">
                        <div
                          className={`rounded-xl border p-3.5 ${
                            isDark
                              ? "border-[#1E3A5F] bg-[#0B172E]"
                              : "border-[#DCEEE3] bg-white"
                          }`}
                        >
                          <span className="text-[10px] font-bold uppercase tracking-wider text-[#22C55E]">
                            English Learner Prompt
                          </span>
                          <p
                            className={`mt-1 text-xs font-medium leading-relaxed ${
                              isDark ? "text-[#E2E8F0]" : "text-[#0F1D3A]"
                            }`}
                          >
                            “{simItem.learnerToastEn}”
                          </p>
                        </div>
                        <div
                          dir="rtl"
                          className={`rounded-xl border p-3.5 font-arabic ${
                            isDark
                              ? "border-[#1E3A5F] bg-[#0B172E]"
                              : "border-[#DCEEE3] bg-white"
                          }`}
                        >
                          <span className="text-[11px] font-bold text-[#22C55E]">
                            رسالة هيسي للمتعلم
                          </span>
                          <p
                            className={`mt-1 text-sm font-semibold leading-relaxed ${
                              isDark ? "text-[#E2E8F0]" : "text-[#0F1D3A]"
                            }`}
                          >
                            «{simItem.learnerToastAr}»
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Independent SVG Layer Toggles */}
                    <div>
                      <div className="flex items-center justify-between">
                        <h4
                          className={`text-xs font-bold uppercase tracking-wider ${
                            isDark ? "text-[#CBD5E1]" : "text-[#334E68]"
                          }`}
                        >
                          Toggle Independent SVG Layers ({simItem.nameEn})
                        </h4>
                        <button
                          type="button"
                          onClick={() => setSimLayers(DEFAULT_LAYERS)}
                          className="text-xs font-semibold text-[#22C55E] hover:underline"
                        >
                          Reset Layers
                        </button>
                      </div>

                      <div className="mt-2.5 grid gap-2 sm:grid-cols-2">
                        {simItem.layers.map((layer) => {
                          const on = simLayers[layer.id];
                          return (
                            <button
                              key={layer.id}
                              type="button"
                              onClick={() => toggleSimLayer(layer.id)}
                              className={`flex items-center justify-between rounded-xl border px-3.5 py-2.5 text-left text-xs transition-all ${
                                on
                                  ? isDark
                                    ? "border-[#22C55E]/60 bg-[#0F2928] font-semibold text-white shadow-2xs"
                                    : "border-[#86EFAC] bg-white font-semibold text-[#0F1D3A] shadow-2xs"
                                  : isDark
                                  ? "border-[#1E3A5F] bg-[#081225] text-[#64748B] opacity-65"
                                  : "border-[#E2E8F0] bg-[#F8FAFC] text-[#64748B] opacity-65"
                              }`}
                            >
                              <div>
                                <p className="font-bold">{layer.label}</p>
                                <p
                                  className={`text-[11px] font-normal ${
                                    isDark ? "text-[#94A3B8]" : "text-[#475569]"
                                  }`}
                                >
                                  {layer.description}
                                </p>
                              </div>
                              <span
                                className={`ml-2 shrink-0 rounded-md px-2 py-0.5 text-[10px] font-bold ${
                                  on
                                    ? "bg-[#16A34A] text-white"
                                    : isDark
                                    ? "bg-[#1E3A5F] text-[#94A3B8]"
                                    : "bg-[#E2E8F0] text-[#475569]"
                                }`}
                              >
                                {on ? "ON" : "OFF"}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* SECTION 4: ARCHITECTURAL TRANSPARENCY & 60 FPS MOTION SPEC */}
            <section
              id="layer-architecture"
              className={`border-t py-14 transition-colors duration-300 ${
                isDark
                  ? "border-[#1E3A5F] bg-[#081328]"
                  : "border-[#DCEEE3] bg-white"
              }`}
            >
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="grid gap-6 md:grid-cols-3">
                  <div
                    className={`rounded-2xl border p-5 ${
                      isDark
                        ? "border-[#1E3A5F] bg-[#0B172E]"
                        : "border-[#DCEEE3] bg-[#F7FCF9]"
                    }`}
                  >
                    <h3
                      className={`font-display text-base font-bold ${
                        isDark ? "text-white" : "text-[#0F1D3A]"
                      }`}
                    >
                      1. 60 FPS Procedural Character Rigging
                    </h3>
                    <p
                      className={`mt-2 text-xs leading-relaxed ${
                        isDark ? "text-[#94A3B8]" : "text-[#475569]"
                      }`}
                    >
                      A single shared{" "}
                      <code
                        className={`rounded px-1 py-0.5 ${
                          isDark
                            ? "bg-[#112E28] text-[#86EFAC]"
                            : "bg-[#E2F2EA] text-[#0D7A3E]"
                        }`}
                      >
                        requestAnimationFrame
                      </code>{" "}
                      loop drives every visible mascot’s{" "}
                      <code
                        className={`rounded px-1 py-0.5 ${
                          isDark
                            ? "bg-[#112E28] text-[#86EFAC]"
                            : "bg-[#E2F2EA] text-[#0D7A3E]"
                        }`}
                      >
                        [data-rig]
                      </code>{" "}
                      joints using GPU-composited transforms without triggering React re-renders.
                    </p>
                  </div>

                  <div
                    className={`rounded-2xl border p-5 ${
                      isDark
                        ? "border-[#1E3A5F] bg-[#0B172E]"
                        : "border-[#DCEEE3] bg-[#F7FCF9]"
                    }`}
                  >
                    <h3
                      className={`font-display text-base font-bold ${
                        isDark ? "text-white" : "text-[#0F1D3A]"
                      }`}
                    >
                      2. Mascot-Driven Lesson & Theme Sweeps
                    </h3>
                    <p
                      className={`mt-2 text-xs leading-relaxed ${
                        isDark ? "text-[#94A3B8]" : "text-[#475569]"
                      }`}
                    >
                      Clicking any lesson-entry button summons Hesi to push a full-viewport lesson
                      curtain synchronized with a 340 ms airy whoosh asset (
                      <code
                        className={`rounded px-1 py-0.5 ${
                          isDark
                            ? "bg-[#112E28] text-[#86EFAC]"
                            : "bg-[#E2F2EA] text-[#0D7A3E]"
                        }`}
                      >
                        hesi-sweep-whoosh.wav
                      </code>
                      ), holds the settled centered lesson title for a 2000 ms reading pause, and
                      reveals the destination lesson cleanly.
                    </p>
                  </div>

                  <div
                    className={`rounded-2xl border p-5 ${
                      isDark
                        ? "border-[#1E3A5F] bg-[#0B172E]"
                        : "border-[#DCEEE3] bg-[#F7FCF9]"
                      }`}
                    >
                    <h3
                      className={`font-display text-base font-bold ${
                        isDark ? "text-white" : "text-[#0F1D3A]"
                      }`}
                    >
                      3. Interactive Spring Physics & Accessibility
                    </h3>
                    <p
                      className={`mt-2 text-xs leading-relaxed ${
                        isDark ? "text-[#94A3B8]" : "text-[#475569]"
                      }`}
                    >
                      Supports History API navigation (Back/Forward & direct{" "}
                      <code
                        className={`rounded px-1 py-0.5 ${
                          isDark
                            ? "bg-[#112E28] text-[#86EFAC]"
                            : "bg-[#E2F2EA] text-[#0D7A3E]"
                        }`}
                      >
                        ?lesson=
                      </code>{" "}
                      URLs), mute preferences, and{" "}
                      <code
                        className={`rounded px-1 py-0.5 ${
                          isDark
                            ? "bg-[#112E28] text-[#86EFAC]"
                            : "bg-[#E2F2EA] text-[#0D7A3E]"
                        }`}
                      >
                        prefers-reduced-motion
                      </code>{" "}
                      without leaving blocking overlays.
                    </p>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1E3A5F] bg-[#050C1A] py-10 text-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <HesiBrandMark size={38} />
            <div>
              <span className="font-display text-lg font-extrabold tracking-tight text-white">
                Hesi
              </span>
              <span className="mx-2 text-white/30">|</span>
              <span className="font-arabic text-sm font-bold text-[#86EFAC]" dir="rtl">
                تعبيرات هيسي — كل لحظة ... شعور مختلف
              </span>
            </div>
          </div>
          <p className="text-xs text-[#94A3B8]">
            60 FPS Procedural Character Rig • Lesson & Day/Night Curtain Transitions • 10 Mascots
          </p>
        </div>
      </footer>

      {/* Interactive Layer & Motion Inspector Modal */}
      <LivePlaygroundModal
        item={inspectedMascot}
        lang={lang}
        theme={theme}
        onClose={() => setInspectedMascot(null)}
        onSelectMascot={(m) => setInspectedMascot(m)}
        onEnterLesson={handleEnterLesson}
      />
    </div>
  );
}
